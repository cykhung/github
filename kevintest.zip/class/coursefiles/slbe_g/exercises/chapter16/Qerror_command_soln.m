%% clear out the memory, close all models, and load the required model
clear all;
bdclose all;
load_system('Sigmadelta_command'); % Runs PreLoadFcn callback function

%% Do the simulation for number of bits going from 1 to 16
nbits = 1:16;
errorMax = zeros(length(nbits),1); % Pre-allocate an array
for indx = 1: length(nbits)
    Q_interval = 2^(-nbits(indx));
    output = sim('Sigmadelta_command','StopTime','0.025');
    Q_error = get(output,'yout');
    errorMax(indx) = max(abs(Q_error));
end

%% Plot results
plot(nbits, errorMax);
xlabel('Number of bits');
ylabel('Quantization error');
