function qError = adcquanterror(nbits)
%
% qError = adcquanterror(nbits)
%
% Compute the quantization noise power in dB for an
% ideal 'nbits' bit ADC.
%

lsb = 2^(-nbits);
qErrorVar = (lsb^2)/12;
qError = 10*log10(qErrorVar);
end
