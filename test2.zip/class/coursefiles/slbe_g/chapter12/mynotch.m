function Hd = mynotch
% Design a notch filter
%   Filter order = 2
%   Notch frequency = 7350 Hz
%   Notch bandwidth = 200 Hz
%   Sampling frequency = 22050 Hz
%
d = fdesign.notch('N,F0,BW',2,7350,200,22050);
Hd = design(d);
end