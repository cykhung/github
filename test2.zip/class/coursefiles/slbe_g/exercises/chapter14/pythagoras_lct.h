/*-----------------------------------------------------------------
 *
 *	pythagoras_lct.h
 *	2006_10_11
 *
 *  Implementation of a biquad filter.
 *    a, b - inputs
 *    c - output
 *
 *-----------------------------------------------------------------
 */

float pythagoras_lct(float *a, float *b);
