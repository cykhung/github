#ifndef __c2_ceval_testbench_1_h__
#define __c2_ceval_testbench_1_h__

/* Forward Declarations */

/* Type Definitions */
#ifndef typedef_SFc2_ceval_testbench_1InstanceStruct
#define typedef_SFc2_ceval_testbench_1InstanceStruct

typedef struct {
  boolean_T c2_doneDoubleBufferReInit;
  uint8_T c2_is_active_c2_ceval_testbench_1;
  uint8_T c2_JITStateAnimation[1];
  real32_T c2_coeffs[9];
  real_T c2_ntaps;
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c2_JITTransitionAnimation[1];
  int32_T c2_sfEvent;
  int32_T c2_IsDebuggerActive;
  int32_T c2_IsSequenceViewerPresent;
  int32_T c2_SequenceViewerOptimization;
  int32_T c2_IsHeatMapPresent;
  void *c2_RuntimeVar;
  uint32_T c2_mlFcnLineNumber;
  void *c2_fcnDataPtrs[4];
  char_T *c2_dataNames[4];
  uint32_T c2_numFcnVars;
  uint32_T c2_ssIds[4];
  uint32_T c2_statuses[4];
  void *c2_outMexFcns[4];
  void *c2_inMexFcns[4];
  CovrtStateflowInstance *c2_covrtInstance;
  void *c2_fEmlrtCtx;
  real32_T *c2_in;
  real32_T *c2_y;
} SFc2_ceval_testbench_1InstanceStruct;

#endif                                 /* typedef_SFc2_ceval_testbench_1InstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c2_ceval_testbench_1_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c2_ceval_testbench_1_get_check_sum(mxArray *plhs[]);
extern void c2_ceval_testbench_1_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
