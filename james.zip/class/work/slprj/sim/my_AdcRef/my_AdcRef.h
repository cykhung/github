#ifndef RTW_HEADER_my_AdcRef_h_
#define RTW_HEADER_my_AdcRef_h_
#ifndef my_AdcRef_COMMON_INCLUDES_
#define my_AdcRef_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "my_AdcRef_types.h"
#include <stddef.h>
#include <string.h>
#include "model_reference_types.h"
#include "rtw_modelmap_simtarget.h"
#include "rt_nonfinite.h"
typedef struct { real_T gce5n3p4xv ; real_T b0b0grph2q ; real_T j042m2ofjv ;
real_T dbirdvycjw ; } hyhhzloqby ; typedef struct { real_T bjdamj10uy ;
struct { real_T modelTStart ; real_T TUbufferArea [ 2048 ] ; } onqoblfqpp ;
struct { void * TUbufferPtrs [ 2 ] ; } mkohbmkbvc ; uint32_T gub1fqxar5 ;
struct { int_T Tail ; int_T Head ; int_T Last ; int_T CircularBufSize ; }
fa2uwge3aj ; } jmxh3fcoxr ; typedef struct { real_T j55ibddnvz [ 3 ] ; }
haxhbr00m1 ; typedef struct { real_T j55ibddnvz [ 3 ] ; } jy53cvkvuq ;
typedef struct { boolean_T j55ibddnvz [ 3 ] ; } kgdbsuwrmw ; typedef struct {
real_T j55ibddnvz [ 3 ] ; } d0yscc03is ; typedef struct { real_T j55ibddnvz [
3 ] ; } l12fvf03ll ; typedef struct { real_T j55ibddnvz [ 3 ] ; } hohkrpqpj3
; struct lmidk1555nk_ { real_T P_0 [ 5 ] ; real_T P_1 ; real_T P_2 ; real_T
P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T
P_9 ; real_T P_10 ; real_T P_11 ; uint32_T P_12 [ 5 ] ; uint32_T P_13 [ 4 ] ;
uint32_T P_14 ; uint32_T P_15 [ 2 ] ; uint32_T P_16 ; uint32_T P_17 [ 4 ] ; }
; struct lclsirv0ks { struct SimStruct_tag * _mdlRefSfcnS ; struct { real_T
mr_nonContSig0 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 1 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 2 ] ; int32_T * vardimsAddress [ 2
] ; RTWLoggingFcnPtr loggingPtrs [ 2 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 3 ]
; } Timing ; } ; typedef struct { hyhhzloqby rtb ; jmxh3fcoxr rtdw ;
izu2pbwlzy rtm ; } okzntuxvuz5 ; extern void ecehjp5zcb ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 ,
izu2pbwlzy * const bqydw0bvlo , hyhhzloqby * localB , jmxh3fcoxr * localDW ,
haxhbr00m1 * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_my_AdcRef_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_my_AdcRef_GetDWork ( const okzntuxvuz5
* mdlrefDW ) ; extern void mr_my_AdcRef_SetDWork ( okzntuxvuz5 * mdlrefDW ,
const mxArray * ssDW ) ; extern void mr_my_AdcRef_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_my_AdcRef_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * my_AdcRef_GetCAPIStaticMap
( void ) ; extern void j3sdwziugt ( jmxh3fcoxr * localDW , haxhbr00m1 *
localX ) ; extern void n2lidatqvx ( jmxh3fcoxr * localDW , haxhbr00m1 *
localX ) ; extern void bkyrjyoa13 ( izu2pbwlzy * const bqydw0bvlo ,
jmxh3fcoxr * localDW ) ; extern void bqieyj3vag ( hyhhzloqby * localB ,
haxhbr00m1 * localX , jy53cvkvuq * localXdot ) ; extern void bowik4vhll (
izu2pbwlzy * const bqydw0bvlo , const real_T * ccjsfcxzfc , jmxh3fcoxr *
localDW ) ; extern void my_AdcRef ( izu2pbwlzy * const bqydw0bvlo , const
real_T * ccjsfcxzfc , real_T * h2efvfnciz , real_T rtp_nonlingain ,
hyhhzloqby * localB , jmxh3fcoxr * localDW , haxhbr00m1 * localX ) ; extern
void mn5pphasnn ( izu2pbwlzy * const bqydw0bvlo ) ;
#endif
