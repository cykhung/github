#include "my_AdcRef.h"
#include "rtwtypes.h"
#include "my_AdcRef_private.h"
#include "mwmathutil.h"
#include "rt_urand_Upu32_Yd_f_pw_snf.h"
#include "rt_TDelayInterpolate.h"
#include "my_AdcRef_capi.h"
#include "rt_nonfinite.h"
static RegMdlInfo rtMdlInfo_my_AdcRef [ 49 ] = { { "okzntuxvuz5" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"lrrr5mzo51" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "hohkrpqpj3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "l12fvf03ll" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_AdcRef" } , { "d0yscc03is" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"kgdbsuwrmw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "jy53cvkvuq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "haxhbr00m1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_AdcRef" } , { "gkgi1ynoai" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"luflkdk01p" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "emd2q2zf5c" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "g0nw4kapka" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_AdcRef" } , { "jmxh3fcoxr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"hyhhzloqby" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "p4fv1yz442" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "mn5pphasnn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_AdcRef" } , { "lz2hjwpgzc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"f4wla4bugi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "bqieyj3vag" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "bowik4vhll" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_AdcRef" } , { "n2lidatqvx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"j3sdwziugt" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "ecehjp5zcb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "bkyrjyoa13" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_AdcRef" } , { "g5im4lxjwr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"my_AdcRef" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"ectutyr3vx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "fxlfk3zb02x" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "my_AdcRef" } , { "fxlfk3zb02" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"lclsirv0ks" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_AdcRef" } , { "izu2pbwlzy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_AdcRef" } , { "cuint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , -
1 , ( void * ) "uint64" } , { "uint64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "cint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void * )
"int64" } , { "int64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_my_AdcRef_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "my_AdcRef" } , { "mr_my_AdcRef_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "my_AdcRef" } , { "mr_my_AdcRef_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "my_AdcRef" } , { "mr_my_AdcRef_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_AdcRef" } , {
"mr_my_AdcRef_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"my_AdcRef" } , { "my_AdcRef.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL
) } , { "my_AdcRef.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"my_AdcRef" } } ; lmidk1555nk lmidk1555n = { { - 2.5132741228718344E+7 ,
2.5132741228718344E+7 , - 2.5132741228718333E+7 , 2.513274122871834E+7 , -
2.5132741228718344E+7 } , 2.5132741228718344E+7 , 1.0 , 0.0 , 3.0E-11 , 0.0 ,
0.00390625 , 0.5 , - 0.5 , 0.0 , 1.5E-11 , 1234.0 , { 0U , 1U , 1U , 2U , 1U
} , { 0U , 2U , 4U , 5U } , 0U , { 0U , 1U } , 0U , { 0U , 0U , 0U , 1U } } ;
void j3sdwziugt ( jmxh3fcoxr * localDW , haxhbr00m1 * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> j55ibddnvz [ 0 ] =
lmidk1555n . P_3 ; localX -> j55ibddnvz [ 1 ] = lmidk1555n . P_3 ; localX ->
j55ibddnvz [ 2 ] = lmidk1555n . P_3 ; tmp = muDoubleScalarFloor ( lmidk1555n
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> gub1fqxar5 = tseed ;
localDW -> bjdamj10uy = ( lmidk1555n . P_10 - lmidk1555n . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> gub1fqxar5 ) + lmidk1555n . P_9 ; }
void n2lidatqvx ( jmxh3fcoxr * localDW , haxhbr00m1 * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> j55ibddnvz [ 0 ] =
lmidk1555n . P_3 ; localX -> j55ibddnvz [ 1 ] = lmidk1555n . P_3 ; localX ->
j55ibddnvz [ 2 ] = lmidk1555n . P_3 ; tmp = muDoubleScalarFloor ( lmidk1555n
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> gub1fqxar5 = tseed ;
localDW -> bjdamj10uy = ( lmidk1555n . P_10 - lmidk1555n . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> gub1fqxar5 ) + lmidk1555n . P_9 ; }
void bkyrjyoa13 ( izu2pbwlzy * const bqydw0bvlo , jmxh3fcoxr * localDW ) { {
real_T * pBuffer = & localDW -> onqoblfqpp . TUbufferArea [ 0 ] ; int_T j ;
char ptrKey [ 1024 ] ; localDW -> fa2uwge3aj . Tail = 0 ; localDW ->
fa2uwge3aj . Head = 0 ; localDW -> fa2uwge3aj . Last = 0 ; localDW ->
fa2uwge3aj . CircularBufSize = 1024 ; for ( j = 0 ; j < 1024 ; j ++ ) {
pBuffer [ j ] = lmidk1555n . P_5 ; pBuffer [ 1024 + j ] = rtmGetTaskTime (
bqydw0bvlo , 0 ) ; } localDW -> mkohbmkbvc . TUbufferPtrs [ 0 ] = ( void * )
& pBuffer [ 0 ] ; sprintf ( ptrKey , "my_AdcRef/Variable\nDelay_TUbuffer%d" ,
0 ) ; slsaSaveRawMemoryForSimTargetOP ( bqydw0bvlo -> _mdlRefSfcnS , ptrKey ,
( void * * ) ( & localDW -> mkohbmkbvc . TUbufferPtrs [ 0 ] ) , 2 * 1024 *
sizeof ( real_T ) , ( NULL ) , ( NULL ) ) ; } } void my_AdcRef ( izu2pbwlzy *
const bqydw0bvlo , const real_T * ccjsfcxzfc , real_T * h2efvfnciz , real_T
rtp_nonlingain , hyhhzloqby * localB , jmxh3fcoxr * localDW , haxhbr00m1 *
localX ) { real_T cw35zzgiv2 ; real_T tmp ; uint32_T ri ; localB ->
gce5n3p4xv = 0.0 ; for ( ri = lmidk1555n . P_17 [ 0U ] ; ri < lmidk1555n .
P_17 [ 1U ] ; ri ++ ) { localB -> gce5n3p4xv += lmidk1555n . P_2 * localX ->
j55ibddnvz [ 0U ] ; } for ( ri = lmidk1555n . P_17 [ 1U ] ; ri < lmidk1555n .
P_17 [ 2U ] ; ri ++ ) { localB -> gce5n3p4xv += lmidk1555n . P_2 * localX ->
j55ibddnvz [ 1U ] ; } for ( ri = lmidk1555n . P_17 [ 2U ] ; ri < lmidk1555n .
P_17 [ 3U ] ; ri ++ ) { localB -> gce5n3p4xv += lmidk1555n . P_2 * localX ->
j55ibddnvz [ 2U ] ; } { real_T * * uBuffer = ( real_T * * ) & localDW ->
mkohbmkbvc . TUbufferPtrs [ 0 ] ; real_T simTime = rtmGetTaskTime (
bqydw0bvlo , 0 ) ; real_T appliedDelay ; appliedDelay = localB -> gce5n3p4xv
; if ( appliedDelay > lmidk1555n . P_4 ) { appliedDelay = lmidk1555n . P_4 ;
} if ( appliedDelay < 0.0 ) { appliedDelay = 0.0 ; } if ( appliedDelay == 0.0
) { localB -> b0b0grph2q = ( * ccjsfcxzfc ) ; } else { localB -> b0b0grph2q =
rt_TDelayInterpolate ( simTime - appliedDelay , 0.0 , * uBuffer , localDW ->
fa2uwge3aj . CircularBufSize , & localDW -> fa2uwge3aj . Last , localDW ->
fa2uwge3aj . Tail , localDW -> fa2uwge3aj . Head , lmidk1555n . P_5 , 0 , (
boolean_T ) ( rtmIsMinorTimeStep ( bqydw0bvlo ) && ( ( * uBuffer + localDW ->
fa2uwge3aj . CircularBufSize ) [ localDW -> fa2uwge3aj . Head ] ==
rtmGetTaskTime ( bqydw0bvlo , 0 ) ) ) ) ; } } if ( rtmIsMajorTimeStep (
bqydw0bvlo ) && rtmIsSampleHit ( bqydw0bvlo , 1 , 0 ) ) { localB ->
dbirdvycjw = localDW -> bjdamj10uy ; } if ( rtmIsMajorTimeStep ( bqydw0bvlo )
&& rtmIsSampleHit ( bqydw0bvlo , 2 , 0 ) ) { localB -> j042m2ofjv = localB ->
b0b0grph2q ; cw35zzgiv2 = rtp_nonlingain * localB -> j042m2ofjv ; tmp = 1.0 /
rtp_nonlingain ; cw35zzgiv2 = muDoubleScalarRound ( tmp * muDoubleScalarTanh
( cw35zzgiv2 ) / lmidk1555n . P_6 ) * lmidk1555n . P_6 ; if ( cw35zzgiv2 >
lmidk1555n . P_7 ) { * h2efvfnciz = lmidk1555n . P_7 ; } else if ( cw35zzgiv2
< lmidk1555n . P_8 ) { * h2efvfnciz = lmidk1555n . P_8 ; } else { *
h2efvfnciz = cw35zzgiv2 ; } } } void bowik4vhll ( izu2pbwlzy * const
bqydw0bvlo , const real_T * ccjsfcxzfc , jmxh3fcoxr * localDW ) { if (
rtmIsMajorTimeStep ( bqydw0bvlo ) ) { if ( memcmp ( bqydw0bvlo ->
nonContDerivSignal [ 0 ] . pCurrVal , bqydw0bvlo -> nonContDerivSignal [ 0 ]
. pPrevVal , bqydw0bvlo -> nonContDerivSignal [ 0 ] . sizeInBytes ) != 0 ) {
( void ) memcpy ( bqydw0bvlo -> nonContDerivSignal [ 0 ] . pPrevVal ,
bqydw0bvlo -> nonContDerivSignal [ 0 ] . pCurrVal , bqydw0bvlo ->
nonContDerivSignal [ 0 ] . sizeInBytes ) ; ssSetSolverNeedsReset ( bqydw0bvlo
-> _mdlRefSfcnS ) ; } } { real_T * * uBuffer = ( real_T * * ) & localDW ->
mkohbmkbvc . TUbufferPtrs [ 0 ] ; int numBuffers = 2 ; real_T simTime =
rtmGetTaskTime ( bqydw0bvlo , 0 ) ; boolean_T bufferisfull = false ; localDW
-> fa2uwge3aj . Head = ( ( localDW -> fa2uwge3aj . Head < ( localDW ->
fa2uwge3aj . CircularBufSize - 1 ) ) ? ( localDW -> fa2uwge3aj . Head + 1 ) :
0 ) ; if ( localDW -> fa2uwge3aj . Head == localDW -> fa2uwge3aj . Tail ) {
bufferisfull = true ; localDW -> fa2uwge3aj . Tail = ( ( localDW ->
fa2uwge3aj . Tail < ( localDW -> fa2uwge3aj . CircularBufSize - 1 ) ) ? (
localDW -> fa2uwge3aj . Tail + 1 ) : 0 ) ; } ( * uBuffer + localDW ->
fa2uwge3aj . CircularBufSize ) [ localDW -> fa2uwge3aj . Head ] = simTime ; (
* uBuffer ) [ localDW -> fa2uwge3aj . Head ] = ( * ccjsfcxzfc ) ; if (
bufferisfull ) { ssSetBlockStateForSolverChangedAtMajorStep ( bqydw0bvlo ->
_mdlRefSfcnS ) ; ssSetContTimeOutputInconsistentWithStateAtMajorStep (
bqydw0bvlo -> _mdlRefSfcnS ) ; } } if ( rtmIsMajorTimeStep ( bqydw0bvlo ) &&
rtmIsSampleHit ( bqydw0bvlo , 1 , 0 ) ) { localDW -> bjdamj10uy = (
lmidk1555n . P_10 - lmidk1555n . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( &
localDW -> gub1fqxar5 ) + lmidk1555n . P_9 ; } } void bqieyj3vag ( hyhhzloqby
* localB , haxhbr00m1 * localX , jy53cvkvuq * localXdot ) { uint32_T ri ;
localXdot -> j55ibddnvz [ 0 ] = 0.0 ; localXdot -> j55ibddnvz [ 1 ] = 0.0 ;
localXdot -> j55ibddnvz [ 2 ] = 0.0 ; for ( ri = lmidk1555n . P_13 [ 0U ] ;
ri < lmidk1555n . P_13 [ 1U ] ; ri ++ ) { localXdot -> j55ibddnvz [
lmidk1555n . P_12 [ ri ] ] += lmidk1555n . P_0 [ ri ] * localX -> j55ibddnvz
[ 0U ] ; } for ( ri = lmidk1555n . P_13 [ 1U ] ; ri < lmidk1555n . P_13 [ 2U
] ; ri ++ ) { localXdot -> j55ibddnvz [ lmidk1555n . P_12 [ ri ] ] +=
lmidk1555n . P_0 [ ri ] * localX -> j55ibddnvz [ 1U ] ; } for ( ri =
lmidk1555n . P_13 [ 2U ] ; ri < lmidk1555n . P_13 [ 3U ] ; ri ++ ) {
localXdot -> j55ibddnvz [ lmidk1555n . P_12 [ ri ] ] += lmidk1555n . P_0 [ ri
] * localX -> j55ibddnvz [ 2U ] ; } for ( ri = lmidk1555n . P_15 [ 0U ] ; ri
< lmidk1555n . P_15 [ 1U ] ; ri ++ ) { localXdot -> j55ibddnvz [ lmidk1555n .
P_14 ] += lmidk1555n . P_1 * localB -> dbirdvycjw ; } { } } void mn5pphasnn (
izu2pbwlzy * const bqydw0bvlo ) { if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( bqydw0bvlo -> _mdlRefSfcnS , "my_AdcRef" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void ecehjp5zcb (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , izu2pbwlzy * const bqydw0bvlo , hyhhzloqby * localB ,
jmxh3fcoxr * localDW , haxhbr00m1 * localX , void * sysRanPtr , int
contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; ( void ) memset ( ( void * ) bqydw0bvlo , 0 , sizeof
( izu2pbwlzy ) ) ; bqydw0bvlo -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; bqydw0bvlo -> Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ;
bqydw0bvlo -> Timing . mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; bqydw0bvlo ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( bqydw0bvlo -> _mdlRefSfcnS , "my_AdcRef" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> gce5n3p4xv = 0.0
; localB -> b0b0grph2q = 0.0 ; localB -> j042m2ofjv = 0.0 ; localB ->
dbirdvycjw = 0.0 ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof (
jmxh3fcoxr ) ) ; localDW -> bjdamj10uy = 0.0 ; localDW -> onqoblfqpp .
modelTStart = 0.0 ; { int32_T i ; for ( i = 0 ; i < 2048 ; i ++ ) { localDW
-> onqoblfqpp . TUbufferArea [ i ] = 0.0 ; } }
my_AdcRef_InitializeDataMapInfo ( bqydw0bvlo , localB , localDW , localX ,
sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && (
rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI ,
rt_ChildMMIIdx , & ( bqydw0bvlo -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath (
bqydw0bvlo -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( bqydw0bvlo -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } bqydw0bvlo -> nonContDerivSignal [ 0 ] . pPrevVal = (
char_T * ) bqydw0bvlo -> NonContDerivMemory . mr_nonContSig0 ; bqydw0bvlo ->
nonContDerivSignal [ 0 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
bqydw0bvlo -> nonContDerivSignal [ 0 ] . pCurrVal = ( char_T * ) ( & localB
-> dbirdvycjw ) ; ; } void mr_my_AdcRef_MdlInfoRegFcn ( SimStruct *
mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal = 0 ; {
boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } *
retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_my_AdcRef , 49 ) ; * retVal = 1 ; } static void
mr_my_AdcRef_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_my_AdcRef_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_my_AdcRef_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_my_AdcRef_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_my_AdcRef_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_my_AdcRef_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_my_AdcRef_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_my_AdcRef_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_my_AdcRef_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_my_AdcRef_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_my_AdcRef_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_my_AdcRef_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_my_AdcRef_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_my_AdcRef_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_my_AdcRef_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_my_AdcRef_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_my_AdcRef_GetDWork ( const okzntuxvuz5 * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_my_AdcRef_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 4 ] = { "mdlrefDW->rtdw.bjdamj10uy" ,
"mdlrefDW->rtdw.onqoblfqpp" , "mdlrefDW->rtdw.gub1fqxar5" ,
"mdlrefDW->rtdw.fa2uwge3aj" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 4 , rtdwDataFieldNames ) ; mr_my_AdcRef_cacheDataAsMxArray ( rtdwData
, 0 , 0 , ( const void * ) & ( mdlrefDW -> rtdw . bjdamj10uy ) , sizeof (
mdlrefDW -> rtdw . bjdamj10uy ) ) ; mr_my_AdcRef_cacheDataAsMxArray (
rtdwData , 0 , 1 , ( const void * ) & ( mdlrefDW -> rtdw . onqoblfqpp ) ,
sizeof ( mdlrefDW -> rtdw . onqoblfqpp ) ) ; mr_my_AdcRef_cacheDataAsMxArray
( rtdwData , 0 , 2 , ( const void * ) & ( mdlrefDW -> rtdw . gub1fqxar5 ) ,
sizeof ( mdlrefDW -> rtdw . gub1fqxar5 ) ) ; mr_my_AdcRef_cacheDataAsMxArray
( rtdwData , 0 , 3 , ( const void * ) & ( mdlrefDW -> rtdw . fa2uwge3aj ) ,
sizeof ( mdlrefDW -> rtdw . fa2uwge3aj ) ) ; mxSetFieldByNumber ( ssDW , 0 ,
1 , rtdwData ) ; } ( void ) mdlrefDW ; return ssDW ; } void
mr_my_AdcRef_SetDWork ( okzntuxvuz5 * mdlrefDW , const mxArray * ssDW ) { (
void ) ssDW ; ( void ) mdlrefDW ; mr_my_AdcRef_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) )
; { const mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_my_AdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
bjdamj10uy ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW -> rtdw . bjdamj10uy ) )
; mr_my_AdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
onqoblfqpp ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw . onqoblfqpp ) )
; mr_my_AdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
gub1fqxar5 ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . gub1fqxar5 ) )
; mr_my_AdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
fa2uwge3aj ) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . fa2uwge3aj ) )
; } } void mr_my_AdcRef_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 1130047178U , 1993902763U , 826566399U ,
2579013517U , } ; slmrModelRefRegisterSimStateChecksum ( S , "my_AdcRef" , &
chksum [ 0 ] ) ; } mxArray * mr_my_AdcRef_GetSimStateDisallowedBlocks ( ) {
return ( NULL ) ; }
#if defined(_MSC_VER)
#pragma warning(disable: 4505) //unreferenced local function has been removed
#endif
