#ifndef RTW_HEADER_adcRef2_capi_h_
#define RTW_HEADER_adcRef2_capi_h_
#include "adcRef2.h"
extern void adcRef2_InitializeDataMapInfo ( estj3w2p3r * const bcszd0h5ah ,
aqhwilkdpr * localB , erwcrwoqga * localDW , p0xt21di20 * localX , void *
sysRanPtr , int contextTid ) ;
#endif
