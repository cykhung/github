%% IIR Filter - Convert and Optimize Data Types

%% 1. Define Model and System Under Design (SUD)
model = 'iirfilter_fxpopt_prep';
sud = [model '/IIRSections']; % 
bdclose(model)
Simulink.sdi.clear; clc;
load_system(model);

%% 2. Define Model Paths and Defaults
SNR = 0; % to select the Variable Sink for SNR Measurments
NoisePower = false; % to select the Variable Sink for Noise Power Measurements
SourceSelectorPath = [model '/Source/Source Selector'];
SNRPath = [model '/SNR_RMS'];

%% 3. Define Simulation Scenarios

% Default scenario to be used after conversion
si_default = Simulink.SimulationInput(model);
si_default = si_default.setBlockParameter(SourceSelectorPath,'Value', '2'); % Chirp
si_default = si_default.setBlockParameter(SNRPath,'initSignalRMS', 'sqrt(1/2)');
si_default = si_default.setVariable('SNR', 0); % SNR not analyzed
si_default = si_default.setVariable('NoisePower', false); % Noise Power not analyzed

% Simulation scenarios to be used during conversion
si(1) = Simulink.SimulationInput(model);
si(1) = si(1).setBlockParameter(SourceSelectorPath,'Value', '1'); % White Noise
si(1) = si(1).setBlockParameter(SNRPath,'initSignalRMS', 'sqrt(0.1)');
si(1) = si(1).setVariable('SNR', 1); % SNR > 75 dB
si(1) = si(1).setVariable('NoisePower', true); % Noise Power in Range [-95 -85] dB

si(2) = Simulink.SimulationInput(model);
si(2) = si(2).setBlockParameter(SourceSelectorPath,'Value', '2'); % Chirp
si(2) = si(2).setBlockParameter(SNRPath,'initSignalRMS', 'sqrt(1/2)');
si(2) = si(2).setVariable('SNR', 0); % SNR not analyzed
si(2) = si(2).setVariable('NoisePower', true); % Noise Power in Range [-95 -85] dB

si(3) = Simulink.SimulationInput(model);
si(3) = si(3).setBlockParameter(SourceSelectorPath,'Value', '3'); % Sine Low
si(3) = si(3).setBlockParameter(SNRPath,'initSignalRMS', 'sqrt(1/2)');
si(3) = si(3).setVariable('SNR', 2); % SNR > 85 dB
si(3) = si(3).setVariable('NoisePower', true); % Noise Power in Range [-95 -85] dB

si(4) = Simulink.SimulationInput(model);
si(4) = si(4).setBlockParameter(SourceSelectorPath,'Value', '4'); % Sine High
si(4) = si(4).setBlockParameter(SNRPath,'initSignalRMS', 'sqrt(2e-5)');
si(4) = si(4).setVariable('SNR', 3); % SNR > 45 dB
si(4) = si(4).setVariable('NoisePower', true); % Noise Power in Range [-95 -85] dB

%% 4. Define Fixed-Point Optimization Options
options = fxpOptimizationOptions();

% Advanced Options 
options.AdvancedOptions.SimulationScenarios = si;
options.AdvancedOptions.PerformNeighborhoodSearch = false;
options.AdvancedOptions.SafetyMargin = 20;

% Stopping Criteria
options.MaxTime = 60*60; % 60 min maximum 
options.MaxIterations = 300;

% Setting Tolerances (for all Simulation Scenarios)
addTolerance(options,sud,1,'AbsTol',1e-4)

%% 5. Run Fixed-Point Conversion and Optimization
tic;
result = fxpopt(model, sud, options);
elapsedTime = toc;
fprintf('The time for finding the best solution is: %d:%d\n',...
    fix(elapsedTime/60),fix(mod(elapsedTime,60)))


%% 6. See the applied solution for the white noise scenerio (1)
open_system(model)
solutionScenario(1) = explore(result,1,1);

%% 7. See the applied solution for the chirp scenerio (2)
solutionScenario(2) = explore(result,1,2);

%% 8. See the applied solution for the sine low scenerio (3)
solutionScenario(3) = explore(result,1,3);

%% 9. See the applied solution for the sine high scenerio (4)
solutionScenario(4) = explore(result,1,4);

%% 10. Show the modified Model and Block Parameters, and Variables for the Scenario Solution
contents(solutionScenario(1))
%% 11. Finalize the conversion and save the model

if all([solutionScenario.Pass])
    
    % Changing Simulation Mode and some Diagnostics
    set_param(model, 'SimulationMode', 'normal')
    set_param(model, 'IntegerSaturationMsg', 'warning')
    set_param(model, 'IntegerOverflowMsg', 'warning')
    set_param(model, 'SignalRangeChecking', 'warning')

    % Changing Logging Mode back to default
    mi = Simulink.SimulationData.ModelLoggingInfo.createFromModel(model);
    mi.LoggingMode = 'LogAllAsSpecifiedInModel';
    set_param(model,'DataLoggingOverride', mi);

    % Uncommenting (enabling) Scope and Check blocks after conversion
    set_param([model '/Scope'],'Commented',"off")
    set_param([model '/Spectrum' 10 'Analyzer'],'Commented',"off")
    set_param([model '/Check' 10 'Difference'],'Commented',"off")

    % Applying the default scenario (Chirp, without SNR or Noise Power checks)
    applyToModel(si_default)
    
    % Save model with new name
    if options.AdvancedOptions.PerformNeighborhoodSearch
        save_system(model, 'iirfilter_fxpopt_ns2')
    else
        save_system(model, 'iirfilter_fxpopt2')
    end
end