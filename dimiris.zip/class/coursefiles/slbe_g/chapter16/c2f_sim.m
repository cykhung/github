%% Simulating the model from command line
bdclose all;  % Make sure the model is NOT already loaded in memory

%% Changing the Stop Time, method 1
load_system('c2f_cmd'); % This will trigger Preloadfcn calback
simOut = sim('c2f_cmd','StopTime','20');
plot( C(1:21), simOut.yout );xlabel('Celsius'); ylabel('Fahrenheit');
close_system('c2f_cmd'); % Unload model from memory

%% Changing the input and the stop time, method 2
load_system('c2f_cmd');  % This will trigger Preloadfcn calback
t = linspace(0,100,101)'; % Modify t variable
C = linspace(-40,100,101)';% Modify C variable
paramOverrides.StopTime = '100';
simOut = sim('c2f_cmd',paramOverrides);
plot( C, simOut.yout );xlabel('Celsius'); ylabel('Fahrenheit');
close_system('c2f_cmd'); % Unload model from memory

%% Changing the stop time, method 3
load_system('c2f_cmd');
configSetOrig = getActiveConfigSet('c2f_cmd')
configSetNew = configSetOrig.copy
set_param(configSetNew,'StopTime','40')
simOut = sim('c2f_cmd',configSetNew)
plot( C(1:41), simOut.yout );xlabel('Celsius'); ylabel('Fahrenheit');
close_system('c2f_cmd'); % Unload model from memory