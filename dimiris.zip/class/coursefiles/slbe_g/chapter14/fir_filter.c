#include <stdlib.h>
#include "fir_filter.h"
#include "filter_types.h"

/**********************************************************/
/* FIR filtering                                          */
/**********************************************************/

mytype fir_filt(mytype in, int ntaps, mytype coeffs[])       
{
    
    int i;
    mytype sum;
    static int first_time = 1;
    static mytype *z;
    
      
    if (first_time == 1){
        z = (mytype*) malloc((ntaps)*sizeof(mytype));
        for (i = 0; i < ntaps; i++) {
            z[i] = 0;
        }
        first_time--;
    }
           
    z[0] = in;

    sum = 0;
    for (i = 0; i < ntaps; i++) {
        sum += coeffs[i] * z[i];
    }

    for (i = ntaps - 1; i > 0; i--) {
        z[i] = z[i-1];
    }

    return sum;
}
