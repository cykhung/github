function bins = fftbin(f, fs, nfft)
bins = f./(fs/nfft);
