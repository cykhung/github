#include "adcRef2.h"
#include "rtwtypes.h"
#include "adcRef2_private.h"
#include "mwmathutil.h"
#include "rt_urand_Upu32_Yd_f_pw_snf.h"
#include "rt_TDelayInterpolate.h"
#include "adcRef2_capi.h"
#include "rt_nonfinite.h"
static RegMdlInfo rtMdlInfo_adcRef2 [ 48 ] = { { "hkcgqaaszhy" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "adcRef2" } , {
"om43rgsfn2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "cec1vaf0po" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "ehvyhtqejv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "k5nyjkwwmo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"mywjid1o3l" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "ceqijwlkbi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "p0xt21di20" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "elb3maquzm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"m45reundhk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "p1svyeonkv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "hs1w5kivwb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "erwcrwoqga" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"aqhwilkdpr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "pwbllpfrpv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "efdrd5alw5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "lzrqonnekz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"nu0hpmbqkd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "pznyn1a4is" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "bw2iziwjm4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "jf5srk2pfv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"nkhqhltizm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "brtvyumc4y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "jd3yxptzid" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "adcRef2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "oc3zv1se3k" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"kyr4tuhcufw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"adcRef2" } , { "kyr4tuhcuf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "adcRef2" } , { "duop1owunb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "adcRef2" } , { "estj3w2p3r" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "adcRef2" } , {
"cuint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void * ) "uint64" } , {
"uint64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "cint64" ,
MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void * ) "int64" } , { "int64" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_adcRef2_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_cacheBitFieldToCellArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "adcRef2" } , { "mr_adcRef2_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "adcRef2" } , { "mr_adcRef2_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "adcRef2" } , { "mr_adcRef2_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "adcRef2" } , {
"mr_adcRef2_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"adcRef2" } , { "mr_adcRef2_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "adcRef2" } , { "adcRef2.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1
, ( NULL ) } , { "adcRef2.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"adcRef2" } } ; bgth3rll15z bgth3rll15 = { { - 2.5132741228718344E+7 ,
2.5132741228718344E+7 , - 2.5132741228718333E+7 , 2.513274122871834E+7 , -
2.5132741228718344E+7 } , 2.5132741228718344E+7 , 1.0 , 0.0 , 3.0E-11 , 0.0 ,
0.00390625 , 0.5 , - 0.5 , 0.0 , 1.5E-11 , 1234.0 , { 0U , 1U , 1U , 2U , 1U
} , { 0U , 2U , 4U , 5U } , 0U , { 0U , 1U } , 0U , { 0U , 0U , 0U , 1U } } ;
void jf5srk2pfv ( erwcrwoqga * localDW , p0xt21di20 * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> awfrz2klqr [ 0 ] =
bgth3rll15 . P_3 ; localX -> awfrz2klqr [ 1 ] = bgth3rll15 . P_3 ; localX ->
awfrz2klqr [ 2 ] = bgth3rll15 . P_3 ; tmp = muDoubleScalarFloor ( bgth3rll15
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> fs4e1xgjld = tseed ;
localDW -> oxtt4ezvyj = ( bgth3rll15 . P_10 - bgth3rll15 . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> fs4e1xgjld ) + bgth3rll15 . P_9 ; }
void bw2iziwjm4 ( erwcrwoqga * localDW , p0xt21di20 * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> awfrz2klqr [ 0 ] =
bgth3rll15 . P_3 ; localX -> awfrz2klqr [ 1 ] = bgth3rll15 . P_3 ; localX ->
awfrz2klqr [ 2 ] = bgth3rll15 . P_3 ; tmp = muDoubleScalarFloor ( bgth3rll15
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> fs4e1xgjld = tseed ;
localDW -> oxtt4ezvyj = ( bgth3rll15 . P_10 - bgth3rll15 . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> fs4e1xgjld ) + bgth3rll15 . P_9 ; }
void brtvyumc4y ( estj3w2p3r * const bcszd0h5ah , erwcrwoqga * localDW ) { {
real_T * pBuffer = & localDW -> o0kqxv2uqs . TUbufferArea [ 0 ] ; int_T j ;
char ptrKey [ 1024 ] ; localDW -> nfl1qdj5jx . Tail = 0 ; localDW ->
nfl1qdj5jx . Head = 0 ; localDW -> nfl1qdj5jx . Last = 0 ; localDW ->
nfl1qdj5jx . CircularBufSize = 1024 ; for ( j = 0 ; j < 1024 ; j ++ ) {
pBuffer [ j ] = bgth3rll15 . P_5 ; pBuffer [ 1024 + j ] = rtmGetTaskTime (
bcszd0h5ah , 0 ) ; } localDW -> j5ferbg1nk . TUbufferPtrs [ 0 ] = ( void * )
& pBuffer [ 0 ] ; sprintf ( ptrKey , "adcRef2/Variable\nDelay_TUbuffer%d" , 0
) ; slsaSaveRawMemoryForSimTargetOP ( bcszd0h5ah -> _mdlRefSfcnS , ptrKey , (
void * * ) ( & localDW -> j5ferbg1nk . TUbufferPtrs [ 0 ] ) , 2 * 1024 *
sizeof ( real_T ) , ( NULL ) , ( NULL ) ) ; } } void adcRef2 ( estj3w2p3r *
const bcszd0h5ah , const real_T * or1edqrrlx , real_T * gp44vqrifb , real_T
rtp_nonlingain , aqhwilkdpr * localB , erwcrwoqga * localDW , p0xt21di20 *
localX ) { real_T hn3i21fwio ; real_T tmp ; uint32_T ri ; localB ->
nuflylbnoz = 0.0 ; for ( ri = bgth3rll15 . P_17 [ 0U ] ; ri < bgth3rll15 .
P_17 [ 1U ] ; ri ++ ) { localB -> nuflylbnoz += bgth3rll15 . P_2 * localX ->
awfrz2klqr [ 0U ] ; } for ( ri = bgth3rll15 . P_17 [ 1U ] ; ri < bgth3rll15 .
P_17 [ 2U ] ; ri ++ ) { localB -> nuflylbnoz += bgth3rll15 . P_2 * localX ->
awfrz2klqr [ 1U ] ; } for ( ri = bgth3rll15 . P_17 [ 2U ] ; ri < bgth3rll15 .
P_17 [ 3U ] ; ri ++ ) { localB -> nuflylbnoz += bgth3rll15 . P_2 * localX ->
awfrz2klqr [ 2U ] ; } { real_T * * uBuffer = ( real_T * * ) & localDW ->
j5ferbg1nk . TUbufferPtrs [ 0 ] ; real_T simTime = rtmGetTaskTime (
bcszd0h5ah , 0 ) ; real_T appliedDelay ; appliedDelay = localB -> nuflylbnoz
; if ( appliedDelay > bgth3rll15 . P_4 ) { appliedDelay = bgth3rll15 . P_4 ;
} if ( appliedDelay < 0.0 ) { appliedDelay = 0.0 ; } if ( appliedDelay == 0.0
) { localB -> h41i2tej22 = ( * or1edqrrlx ) ; } else { localB -> h41i2tej22 =
rt_TDelayInterpolate ( simTime - appliedDelay , 0.0 , * uBuffer , localDW ->
nfl1qdj5jx . CircularBufSize , & localDW -> nfl1qdj5jx . Last , localDW ->
nfl1qdj5jx . Tail , localDW -> nfl1qdj5jx . Head , bgth3rll15 . P_5 , 0 , (
boolean_T ) ( rtmIsMinorTimeStep ( bcszd0h5ah ) && ( ( * uBuffer + localDW ->
nfl1qdj5jx . CircularBufSize ) [ localDW -> nfl1qdj5jx . Head ] ==
rtmGetTaskTime ( bcszd0h5ah , 0 ) ) ) ) ; } } if ( rtmIsMajorTimeStep (
bcszd0h5ah ) && rtmIsSampleHit ( bcszd0h5ah , 2 , 0 ) ) { localB ->
a2wq3qn3kc = localB -> h41i2tej22 ; hn3i21fwio = rtp_nonlingain * localB ->
a2wq3qn3kc ; tmp = 1.0 / rtp_nonlingain ; localB -> dksgr5b4my =
muDoubleScalarRound ( tmp * muDoubleScalarTanh ( hn3i21fwio ) / bgth3rll15 .
P_6 ) * bgth3rll15 . P_6 ; if ( localB -> dksgr5b4my > bgth3rll15 . P_7 ) { *
gp44vqrifb = bgth3rll15 . P_7 ; } else if ( localB -> dksgr5b4my < bgth3rll15
. P_8 ) { * gp44vqrifb = bgth3rll15 . P_8 ; } else { * gp44vqrifb = localB ->
dksgr5b4my ; } } if ( rtmIsMajorTimeStep ( bcszd0h5ah ) && rtmIsSampleHit (
bcszd0h5ah , 1 , 0 ) ) { localB -> istv4rlpl2 = localDW -> oxtt4ezvyj ; } }
void pznyn1a4is ( estj3w2p3r * const bcszd0h5ah , const real_T * or1edqrrlx ,
erwcrwoqga * localDW ) { if ( rtmIsMajorTimeStep ( bcszd0h5ah ) ) { if (
memcmp ( bcszd0h5ah -> nonContDerivSignal [ 0 ] . pCurrVal , bcszd0h5ah ->
nonContDerivSignal [ 0 ] . pPrevVal , bcszd0h5ah -> nonContDerivSignal [ 0 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( bcszd0h5ah -> nonContDerivSignal [
0 ] . pPrevVal , bcszd0h5ah -> nonContDerivSignal [ 0 ] . pCurrVal ,
bcszd0h5ah -> nonContDerivSignal [ 0 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( bcszd0h5ah -> _mdlRefSfcnS ) ; } } { real_T * *
uBuffer = ( real_T * * ) & localDW -> j5ferbg1nk . TUbufferPtrs [ 0 ] ; int
numBuffers = 2 ; real_T simTime = rtmGetTaskTime ( bcszd0h5ah , 0 ) ;
boolean_T bufferisfull = false ; localDW -> nfl1qdj5jx . Head = ( ( localDW
-> nfl1qdj5jx . Head < ( localDW -> nfl1qdj5jx . CircularBufSize - 1 ) ) ? (
localDW -> nfl1qdj5jx . Head + 1 ) : 0 ) ; if ( localDW -> nfl1qdj5jx . Head
== localDW -> nfl1qdj5jx . Tail ) { bufferisfull = true ; localDW ->
nfl1qdj5jx . Tail = ( ( localDW -> nfl1qdj5jx . Tail < ( localDW ->
nfl1qdj5jx . CircularBufSize - 1 ) ) ? ( localDW -> nfl1qdj5jx . Tail + 1 ) :
0 ) ; } ( * uBuffer + localDW -> nfl1qdj5jx . CircularBufSize ) [ localDW ->
nfl1qdj5jx . Head ] = simTime ; ( * uBuffer ) [ localDW -> nfl1qdj5jx . Head
] = ( * or1edqrrlx ) ; if ( bufferisfull ) {
ssSetBlockStateForSolverChangedAtMajorStep ( bcszd0h5ah -> _mdlRefSfcnS ) ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( bcszd0h5ah ->
_mdlRefSfcnS ) ; } } if ( rtmIsMajorTimeStep ( bcszd0h5ah ) && rtmIsSampleHit
( bcszd0h5ah , 1 , 0 ) ) { localDW -> oxtt4ezvyj = ( bgth3rll15 . P_10 -
bgth3rll15 . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> fs4e1xgjld ) +
bgth3rll15 . P_9 ; } } void nu0hpmbqkd ( aqhwilkdpr * localB , p0xt21di20 *
localX , ceqijwlkbi * localXdot ) { uint32_T ri ; localXdot -> awfrz2klqr [ 0
] = 0.0 ; localXdot -> awfrz2klqr [ 1 ] = 0.0 ; localXdot -> awfrz2klqr [ 2 ]
= 0.0 ; for ( ri = bgth3rll15 . P_13 [ 0U ] ; ri < bgth3rll15 . P_13 [ 1U ] ;
ri ++ ) { localXdot -> awfrz2klqr [ bgth3rll15 . P_12 [ ri ] ] += bgth3rll15
. P_0 [ ri ] * localX -> awfrz2klqr [ 0U ] ; } for ( ri = bgth3rll15 . P_13 [
1U ] ; ri < bgth3rll15 . P_13 [ 2U ] ; ri ++ ) { localXdot -> awfrz2klqr [
bgth3rll15 . P_12 [ ri ] ] += bgth3rll15 . P_0 [ ri ] * localX -> awfrz2klqr
[ 1U ] ; } for ( ri = bgth3rll15 . P_13 [ 2U ] ; ri < bgth3rll15 . P_13 [ 3U
] ; ri ++ ) { localXdot -> awfrz2klqr [ bgth3rll15 . P_12 [ ri ] ] +=
bgth3rll15 . P_0 [ ri ] * localX -> awfrz2klqr [ 2U ] ; } for ( ri =
bgth3rll15 . P_15 [ 0U ] ; ri < bgth3rll15 . P_15 [ 1U ] ; ri ++ ) {
localXdot -> awfrz2klqr [ bgth3rll15 . P_14 ] += bgth3rll15 . P_1 * localB ->
istv4rlpl2 ; } { } } void efdrd5alw5 ( estj3w2p3r * const bcszd0h5ah ) { if (
! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( bcszd0h5ah ->
_mdlRefSfcnS , "adcRef2" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; }
} void nkhqhltizm ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , int_T mdlref_TID2 , estj3w2p3r * const bcszd0h5ah , aqhwilkdpr
* localB , erwcrwoqga * localDW , p0xt21di20 * localX , void * sysRanPtr ,
int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; ( void ) memset ( ( void * ) bcszd0h5ah , 0 , sizeof
( estj3w2p3r ) ) ; bcszd0h5ah -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; bcszd0h5ah -> Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ;
bcszd0h5ah -> Timing . mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; bcszd0h5ah ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( bcszd0h5ah -> _mdlRefSfcnS , "adcRef2" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> nuflylbnoz = 0.0
; localB -> h41i2tej22 = 0.0 ; localB -> a2wq3qn3kc = 0.0 ; localB ->
dksgr5b4my = 0.0 ; localB -> istv4rlpl2 = 0.0 ; } ( void ) memset ( ( void *
) localDW , 0 , sizeof ( erwcrwoqga ) ) ; localDW -> oxtt4ezvyj = 0.0 ;
localDW -> o0kqxv2uqs . modelTStart = 0.0 ; { int32_T i ; for ( i = 0 ; i <
2048 ; i ++ ) { localDW -> o0kqxv2uqs . TUbufferArea [ i ] = 0.0 ; } }
adcRef2_InitializeDataMapInfo ( bcszd0h5ah , localB , localDW , localX ,
sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && (
rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI ,
rt_ChildMMIIdx , & ( bcszd0h5ah -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath (
bcszd0h5ah -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( bcszd0h5ah -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } bcszd0h5ah -> nonContDerivSignal [ 0 ] . pPrevVal = (
char_T * ) bcszd0h5ah -> NonContDerivMemory . mr_nonContSig0 ; bcszd0h5ah ->
nonContDerivSignal [ 0 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
bcszd0h5ah -> nonContDerivSignal [ 0 ] . pCurrVal = ( char_T * ) ( & localB
-> istv4rlpl2 ) ; ; } void mr_adcRef2_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS
, char_T * modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T
regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , &
regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } * retVal = 0 ;
ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName , rtMdlInfo_adcRef2 , 48 ) ; *
retVal = 1 ; } static void mr_adcRef2_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_adcRef2_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_adcRef2_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_adcRef2_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_adcRef2_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_adcRef2_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j ,
uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_adcRef2_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) ; static uint_T
mr_adcRef2_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_adcRef2_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_adcRef2_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_adcRef2_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_adcRef2_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_adcRef2_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_adcRef2_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray , mwIndex
i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_adcRef2_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static uint_T
mr_adcRef2_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) { const uint_T
fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber ( srcArray
, i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u ) ; }
mxArray * mr_adcRef2_GetDWork ( const hkcgqaaszhy * mdlrefDW ) { static const
char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" , } ; mxArray
* ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_adcRef2_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & ( mdlrefDW
-> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 4 ] = { "mdlrefDW->rtdw.oxtt4ezvyj" ,
"mdlrefDW->rtdw.o0kqxv2uqs" , "mdlrefDW->rtdw.fs4e1xgjld" ,
"mdlrefDW->rtdw.nfl1qdj5jx" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 4 , rtdwDataFieldNames ) ; mr_adcRef2_cacheDataAsMxArray ( rtdwData ,
0 , 0 , ( const void * ) & ( mdlrefDW -> rtdw . oxtt4ezvyj ) , sizeof (
mdlrefDW -> rtdw . oxtt4ezvyj ) ) ; mr_adcRef2_cacheDataAsMxArray ( rtdwData
, 0 , 1 , ( const void * ) & ( mdlrefDW -> rtdw . o0kqxv2uqs ) , sizeof (
mdlrefDW -> rtdw . o0kqxv2uqs ) ) ; mr_adcRef2_cacheDataAsMxArray ( rtdwData
, 0 , 2 , ( const void * ) & ( mdlrefDW -> rtdw . fs4e1xgjld ) , sizeof (
mdlrefDW -> rtdw . fs4e1xgjld ) ) ; mr_adcRef2_cacheDataAsMxArray ( rtdwData
, 0 , 3 , ( const void * ) & ( mdlrefDW -> rtdw . nfl1qdj5jx ) , sizeof (
mdlrefDW -> rtdw . nfl1qdj5jx ) ) ; mxSetFieldByNumber ( ssDW , 0 , 1 ,
rtdwData ) ; } ( void ) mdlrefDW ; return ssDW ; } void mr_adcRef2_SetDWork (
hkcgqaaszhy * mdlrefDW , const mxArray * ssDW ) { ( void ) ssDW ; ( void )
mdlrefDW ; mr_adcRef2_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtb
) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData
= mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_adcRef2_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtdw . oxtt4ezvyj ) , rtdwData , 0 , 0 , sizeof (
mdlrefDW -> rtdw . oxtt4ezvyj ) ) ; mr_adcRef2_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtdw . o0kqxv2uqs ) , rtdwData , 0 , 1 , sizeof (
mdlrefDW -> rtdw . o0kqxv2uqs ) ) ; mr_adcRef2_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtdw . fs4e1xgjld ) , rtdwData , 0 , 2 , sizeof (
mdlrefDW -> rtdw . fs4e1xgjld ) ) ; mr_adcRef2_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtdw . nfl1qdj5jx ) , rtdwData , 0 , 3 , sizeof (
mdlrefDW -> rtdw . nfl1qdj5jx ) ) ; } } void
mr_adcRef2_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T chksum
[ 4 ] = { 3737317842U , 3870427067U , 2514331463U , 2126472772U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "adcRef2" , & chksum [ 0 ] ) ; }
mxArray * mr_adcRef2_GetSimStateDisallowedBlocks ( ) { return ( NULL ) ; }
#if defined(_MSC_VER)
#pragma warning(disable: 4505) //unreferenced local function has been removed
#endif
