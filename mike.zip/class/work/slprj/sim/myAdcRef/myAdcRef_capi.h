#ifndef RTW_HEADER_myAdcRef_capi_h_
#define RTW_HEADER_myAdcRef_capi_h_
#include "myAdcRef.h"
extern void myAdcRef_InitializeDataMapInfo ( neilaysvxs * const fghva1yhce ,
a1jtauijn3 * localDW , cuk0vnaths * localX , void * sysRanPtr , int
contextTid ) ;
#endif
