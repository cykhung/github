#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "myAdcRef_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
#else
#include "builtin_typeid_types.h"
#include "myAdcRef.h"
#include "myAdcRef_capi.h"
#include "myAdcRef_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , 0 ,
TARGET_STRING ( "myAdcRef/Shape the jitter\n noise spectrum. " ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 0 , - 1 , ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1
, 0 } } ; static int_T rt_LoggedStateIdxList [ ] = { 0 } ;
#ifndef HOST_CAPI_BUILD
static void myAdcRef_InitializeDataAddr ( void * dataAddr [ ] , a1jtauijn3 *
localDW , cuk0vnaths * localX ) { dataAddr [ 0 ] = ( void * ) ( & localX ->
j23rdm4haq [ 0 ] ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void myAdcRef_InitializeVarDimsAddr ( int32_T * vardimsAddr [ ] ) {
vardimsAddr [ 0 ] = ( NULL ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void myAdcRef_InitializeLoggingFunctions ( RTWLoggingFcnPtr
loggingPtrs [ ] ) { loggingPtrs [ 0 ] = ( NULL ) ; }
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , ( uint8_T ) SS_DOUBLE , 0 , 0 , 0 } }
;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_VECTOR , 0 , 2 , 0 } } ; static uint_T rtDimensionArray [ ] = { 3 , 1
} ; static const real_T rtcapiStoredFloats [ ] = { 0.0 } ; static
rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , ( boolean_T ) 0 } , } ; static
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , (
int8_T ) 0 , ( uint8_T ) 0 } } ; static int_T rtContextSystems [ 2 ] ; static
rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ] = { { 0 , 0 , "" , 0 } } ; static
rtwCAPI_ModelMapLoggingStaticInfo mmiStaticInfoLogging = { 2 ,
rtContextSystems , loggingMetaInfo , 0 , ( NULL ) , { 0 , ( NULL ) , ( NULL )
} , 0 , ( NULL ) } ; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { {
rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL ) , 0 , ( NULL
) , 0 } , { rtBlockStates , 1 } , { rtDataTypeMap , rtDimensionMap ,
rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float" ,
{ 89464369U , 1294341353U , 1134184212U , 3618104515U } , &
mmiStaticInfoLogging , 0 , ( boolean_T ) 0 , rt_LoggedStateIdxList } ; const
rtwCAPI_ModelMappingStaticInfo * myAdcRef_GetCAPIStaticMap ( void ) { return
& mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void myAdcRef_InitializeSystemRan ( neilaysvxs * const fghva1yhce ,
sysRanDType * systemRan [ ] , a1jtauijn3 * localDW , int_T systemTid [ ] ,
void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER ( fghva1yhce ) ;
UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType * )
rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemTid [ 1 ] = fghva1yhce ->
Timing . mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ;
rtContextSystems [ 0 ] = 0 ; rtContextSystems [ 1 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void myAdcRef_InitializeDataMapInfo ( neilaysvxs * const fghva1yhce ,
a1jtauijn3 * localDW , cuk0vnaths * localX , void * sysRanPtr , int
contextTid ) { rtwCAPI_SetVersion ( fghva1yhce -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( fghva1yhce -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( fghva1yhce -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; myAdcRef_InitializeDataAddr ( fghva1yhce ->
DataMapInfo . dataAddress , localDW , localX ) ; rtwCAPI_SetDataAddressMap (
fghva1yhce -> DataMapInfo . mmi , fghva1yhce -> DataMapInfo . dataAddress ) ;
myAdcRef_InitializeVarDimsAddr ( fghva1yhce -> DataMapInfo . vardimsAddress )
; rtwCAPI_SetVarDimsAddressMap ( fghva1yhce -> DataMapInfo . mmi , fghva1yhce
-> DataMapInfo . vardimsAddress ) ; rtwCAPI_SetPath ( fghva1yhce ->
DataMapInfo . mmi , ( NULL ) ) ; rtwCAPI_SetFullPath ( fghva1yhce ->
DataMapInfo . mmi , ( NULL ) ) ; myAdcRef_InitializeLoggingFunctions (
fghva1yhce -> DataMapInfo . loggingPtrs ) ; rtwCAPI_SetLoggingPtrs (
fghva1yhce -> DataMapInfo . mmi , fghva1yhce -> DataMapInfo . loggingPtrs ) ;
rtwCAPI_SetInstanceLoggingInfo ( fghva1yhce -> DataMapInfo . mmi , &
fghva1yhce -> DataMapInfo . mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray (
fghva1yhce -> DataMapInfo . mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArrayLen (
fghva1yhce -> DataMapInfo . mmi , 0 ) ; myAdcRef_InitializeSystemRan (
fghva1yhce , fghva1yhce -> DataMapInfo . systemRan , localDW , fghva1yhce ->
DataMapInfo . systemTid , sysRanPtr , contextTid ) ; rtwCAPI_SetSystemRan (
fghva1yhce -> DataMapInfo . mmi , fghva1yhce -> DataMapInfo . systemRan ) ;
rtwCAPI_SetSystemTid ( fghva1yhce -> DataMapInfo . mmi , fghva1yhce ->
DataMapInfo . systemTid ) ; rtwCAPI_SetGlobalTIDMap ( fghva1yhce ->
DataMapInfo . mmi , & fghva1yhce -> Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void myAdcRef_host_InitializeDataMapInfo ( myAdcRef_host_DataMapInfo_T *
dataMap , const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ; rtwCAPI_SetPath
( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
