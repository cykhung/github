function archref(action)
persistent hpop
% ARCHREF Reference GUI on filter architectures and DFILT constructions
produx = ver();
fdflag = any(strncmp('DSP System Toolbox',{produx.Name},18));
if nargin<1
    InitializeDemo;
elseif (action == 1)
    newsystem;
elseif (action == 2)
    bringupdoc;
end
% --------------------------------------------------------------------
    function InitializeDemo
        % Nested function to start GUI figure
        % If demo is already running, bring it to the foreground.
        hfig = findobj(allchild(0), 'tag', 'Filter Architecture Reference');
        if ~isempty(hfig)
            figure(hfig(1))
            return
        end
        % File names
        fnames = {'df1_a1equals1',...   %1
            'df1',...                   %2
            'df1t_a1equals1',...        %3
            'df1t',...                  %4
            'df2_a1equals1',...         %5
            'df2',...                   %6
            'df2t_a1equals1',...        %7
            'df2t',...                  %8
            'dffir',...                 %9
            'dffirt',...                %10
            'dfsymfiro',...             %11
            'dfsymfire',...             %12
            'dfasymfiro',...            %13
            'dfasymfire',...            %14
            'latticear',...             %15
            'latticeallpass',...        %16
            'latticemamin',...          %17
            'latticemamax',...          %18
            'latticearma',...           %19
            'statespace',...            %20
            'calattice',...             %21
            'calatticepc',...           %22
            };
        
        % Titles
        ttl = {'dfilt.df1(b,a);  % a(1)=1', ...
            'dfilt.df1(b,a);  % a(1)\neq1', ...
            'dfilt.df1t(b,a); % a(1)=1', ...
            'dfilt.df1t(b,a); % a(1)\neq1', ...
            'dfilt.df2(b,a);  % a(1)=1', ...
            'dfilt.df2(b,a);  % a(1)\neq1', ...
            'dfilt.df2t(b,a); % a(1)=1', ...
            'dfilt.df2t(b,a); % a(1)\neq1', ...
            'dfilt.dffir(b)', ...
            'dfilt.dffirt(b)', ...
            'dfilt.dfsymfir(b)', ...
            'dfilt.dfsymfir(b)', ...
            'dfilt.dfasymfir(b)', ...
            'dfilt.dfasymfir(b)', ...
            'dfilt.latticear(k)', ...
            'dfilt.latticeallpass(k)', ...
            'dfilt.latticemamin(k)', ...
            'dfilt.latticemamax(k)', ...
            'dfilt.latticearma(k,v)', ...
            'dfilt.statespace(A,B,C,D)', ...
            'dfilt.calattice(k1,k2,beta)', ...
            'dfilt.calatticepc(k1,k2,beta)', ...
            };
        
        % Popup display names
        popups = {...
            'Direct form I, a(1) = 1',...               % 'df1'
            'Direct form I, a(1) ~= 1',...               % 'df1'
            'Direct form I transposed, a(1) = 1',...    % 'df1t'
            'Direct form I transposed, a(1) ~= 1',...    % 'df1t'
            'Direct form II, a(1) = 1',...              % 'df2'
            'Direct form II, a(1) ~= 1',...              % 'df2'
            'Direct form II transposed, a(1) = 1',...   % 'df2t'
            'Direct form II transposed, a(1) ~= 1',...   % 'df2t'
            'Direct form FIR',...                       % 'dffir'
            'Direct form FIR transposed',...            % 'dffirt'
            'Direct form symmetric FIR (Type I)',...       % 'dfsimfir (odd)'
            'Direct form symmetric FIR (Type II)',...      % 'dfsimfir (even)'
            'Direct form antisymmetric FIR (Type III)',...  % 'dfasymfir (odd)'
            'Direct form antisymmetric FIR (Type IV)',...   % 'dfasymfir (even)'
            'Lattice AR',...                            % 'latticear'
            'Lattice allpass',...                       % 'latticeallpass'
            'Lattice MA min. phase',...                 % 'latticemamin'
            'Lattice MA max. phase', ...                % 'latticemamax'
            'Lattice ARMA',...                          % 'latticearma'
            'State-space',...                           % 'statespace'
            'Lattice coupled-allpass',...               % 'calattice'
            'Lattice coupled-allpass power-complementary',... % 'calatticepc'
            };
        if ~fdflag
            % If user does not have a license to DSP System Toolbox,
            % then only display the options that are part of Sig Proc TB
            fnames  = fnames(1:20);
            ttl     = ttl(1:20);
            popups  = popups(1:20);
        end
        [wmax,hmax] = imagesizes(fnames);
        screensize = get(0,'ScreenSize');
        hfig = figure( ...
            'Name','Filter Architecture Reference',...
            'NumberTitle','on',...
            'tag','Filter Architecture Reference',...
            'Visible','on','Resize','off',...
            'Units','pixels',...
            'DoubleBuffer','on',...
            'HandleVisibility','callback',...
            'Position',[50 screensize(4)-hmax-200 wmax+60 hmax+90],...
            'MenuBar','none');
        
        % Print option default : don't print uicontrols
        pt = printtemplate;
        pt.PrintUI = 0;
        set(hfig, 'PrintTemplate', pt);
        
        % Render menus using the Signal GUI standard.
        render_menus(hfig);
        
        ha = axes('parent',hfig,'Units','pixels',...
            'ydir','reverse','box','off',...
            'visible','off');
        
        set(get(ha,'title'),...
            'fontname','courier','interpreter','none','visible','on');
        
        % Create a popup with all the systems in it
        figpos = get(hfig, 'Position');
        bgc = get(hfig,'color');
        uicontrol(...
            'parent',hfig,...
            'style','text',...
            'string','Select filter structure:',...
            'backgroundcolor',bgc,...
            'horizontalalignment','left',...
            'position',[20 figpos(4)-20 125 20]);
        
        hpop = uicontrol(...
            'parent',hfig,...
            'style','popup',...
            'string', popups, ...
            'userdata', {fnames,ttl,ha}, ...
            'callback','archref(1)', ...
            'backgroundcolor','white', ...
            'foregroundcolor','k',...
            'position',[150 figpos(4)-20 300 20]);
        
        hbtn = uicontrol(...
            'parent',hfig,...
            'style','pushbutton',...
            'string', 'Help', ...
            'fontweight','bold',...
            'callback','archref(2)', ...
            'position',[455 figpos(4)-20 50 20]);
        
        % Display the first one
        newsystem();
    end
% --------------------------------------------------------------------
    function newsystem()
        % Nested function to bring up a new picture from popup menu choice
        val = get(hpop,'value');    % Get the value of the popup
        ud = get(hpop,'userdata');  % Get the userdata
        fnames = ud{1};             % The name of the file to display
        ttl = ud{2};                % The title
        ha = ud{3};                 % The handle to the axis
        fname = [fnames{val},'.png'];
        imf = imfinfo(fname);
        w = imf.Width;
        h = imf.Height;
        parent = get(hpop,'parent'); % Get handle to parent figure
        parentpos = get(parent,'position');
        xpos = ceil((parentpos(3)-w)/2);
        ypos = ceil((parentpos(4)-h)/2)-20;  % Give enough room for popup
        cdata = imread(fname,'png');
        set(ha,'Position',[xpos ypos w h],...
            'xlim',[.5 w+.5],'ylim',[.5 h+.5]);
        him = image('cdata',cdata,'parent',ha);
        set(get(ha,'title'),'string',ttl{val},'interpreter','tex');
    end
% --------------------------------------------------------------------
    function bringupdoc()
        % Nested function to open up Documentation from popup menu choice
        val = get(hpop,'value');    % Get the value of the popup
        % If user does not have a license to DSP System Toolbox, then
        % direct to Sig Proc TB Documentation instead
        if fdflag
            tb = '/dsp/ref/';
        else
            tb = '/signal/';
        end
        switch val
            case {1,2}
                doc dfilt.df1
            case {3,4}
                doc dfilt.df1t
            case {5,6}
                doc dfilt.df2
            case {7,8}
                doc dfilt.df2t
            case 9
                doc dfilt.dffir
            case 10
                doc dfilt.dffirt
            case {11, 12}
                doc dfilt.dfsymfir
            case {13, 14}
                doc dfilt.dfasymfir
            case 15
                doc dfilt.latticear
            case 16
                doc dfilt.latticeallpass
            case 17
                doc dfilt.latticemamin
            case 18
                doc dfilt.latticemamax
            case 19
                doc dfilt.latticearma
            case 20
                doc dfilt.statespace
            case 21
                doc dfilt.calattice
            case 22
                doc dfilt.calatticepc
            otherwise
                doc dfilt
        end
    end

end
% --------------------------------------------------------------------
function [w,h] = imagesizes(fnames)
%IMAGESIZES  Calculate width and height of portable network graphics files
%   [W,H] = IMAGESIZES(FNAMES) calculates the maximum width W and height H of
%   the portable network graphics (PNG) files in cell array FNAMES.
w = 0;
h = 0;
for k=1:length(fnames)
    imf = imfinfo([fnames{k},'.png']);
    w = max(w,imf.Width);
    h = max(h,imf.Height);
end
end
% --------------------------------------------------------------------
function render_menus(fig)
% Use the existing Signal Processing Toolbox render menu functions
% for the generic menu items.

% Render the "File" menu
hmenus.hfile = render_sptfilemenu(fig);
% Render the "Edit" menu
hmenus.hedit = render_spteditmenu(fig);
% Render the "Window" menu
hmenus.hwindow = render_sptwindowmenu(fig,3);
% Render a DSP System Toolbox specific "Help" menu
hmenus.hhelp = render_helpmenu(fig);
end
%-------------------------------------------------------------------
function hhelp = render_helpmenu(fig)

[hhelpmenu, hhelpmenuitems] = render_fdthelpmenu(fig,4);

strs  = 'Filter Architecture Reference Help';
cbs   = @help_Callback;
tags  = 'helpdemo';
sep   = 'off';
accel = '';
hwhatsthis = addmenu(fig,[4 1],strs,cbs,tags,sep,accel);

hhelp = [hhelpmenu, hhelpmenuitems(1), hwhatsthis, hhelpmenuitems(2:end)];
end
% --------------------------------------------------------------------
function varargout = help_Callback(h, eventdata, handles, varargin)
% Launch help for the demo
helpwin(mfilename);
end