function qError = sinequanterror(nbits)
%
% qError = sinequanterror(nbits)
%
% Computes ideal ADC signal-to-quantization-noise ratio (SQNR) in dB for a full
% scale sine input to an ADC of resolution 'nbits'.
%
qError = 1.76 + 6.02*nbits;
end
