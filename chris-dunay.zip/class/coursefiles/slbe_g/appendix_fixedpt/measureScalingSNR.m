% Open model
model = 'iirfilter_double_start';
load_system(model)
simSource = [model '/Source/Source Selector'];

% Set Source to Sine Wave at 0.313*Fs/2
set_param(simSource, 'Value', '3');

% Simulate with "sections in default order (none), no scaling"
SOS = round(SOS1,8);
G = round(G1',8);
setIIRCoeffs(model,SOS,G)
sim1 = sim(model);

% Simulate with "sections reordered (auto), scaled (L2) with power of 2 numerator"
SOS = round(SOS4,8);
G = round(G4',8);
setIIRCoeffs(model,SOS,G);
sim2 = sim(model);

sigVal = sim1.logsout{2}.Values.Data(:);
noiseVal = sigVal - sim2.logsout{2}.Values.Data(:);
scalingSNR = snr(sigVal,noiseVal);

fprintf('The scaling SNR is: %0.0f dB\n', scalingSNR)
