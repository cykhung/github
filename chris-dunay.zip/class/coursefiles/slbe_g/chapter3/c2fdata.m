load bangaloreTempsC;
t = (0:364)';
tempData = [t, TmaxC];