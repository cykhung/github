
function addSLBE_GtoPath

rootDir = fileparts(which('addSLBE_GtoPath'));

path2add{1} = rootDir;

path2add{2} = [rootDir,'\chapter2'];

path2add{3} = [rootDir,'\chapter3'];

path2add{4} = [rootDir,'\chapter4'];

path2add{5} = [rootDir,'\chapter5'];

path2add{6} = [rootDir,'\chapter6'];

path2add{7} = [rootDir,'\chapter7'];

path2add{8} = [rootDir,'\chapter8'];

path2add{9} = [rootDir,'\chapter9'];

path2add{10} = [rootDir,'\chapter10'];

path2add{11} = [rootDir,'\chapter11'];

path2add{12} = [rootDir,'\chapter12'];

path2add{13} = [rootDir,'\chapter13'];

path2add{14} = [rootDir,'\chapter14'];

path2add{15} = [rootDir,'\chapter15'];

path2add{16} = [rootDir,'\chapter16'];

path2add{17} = [rootDir,'\appendix_debug'];

path2add{18} = [rootDir,'\appendix_fixedpt'];

path2add{19} = [rootDir,'\exercises\chapter3'];

path2add{20} = [rootDir,'\exercises\chapter4'];

path2add{21} = [rootDir,'\exercises\chapter5'];

path2add{22} = [rootDir,'\exercises\chapter6'];

path2add{23} = [rootDir,'\exercises\chapter7'];

path2add{24} = [rootDir,'\exercises\chapter9'];

path2add{25} = [rootDir,'\exercises\chapter10'];

path2add{26} = [rootDir,'\exercises\chapter11'];

path2add{27} = [rootDir,'\exercises\chapter12'];

path2add{28} = [rootDir,'\exercises\chapter13'];

path2add{29} = [rootDir,'\exercises\chapter14'];

path2add{30} = [rootDir,'\exercises\chapter15'];


platform = computer;
if (~any(strcmp(platform,{'PCWIN','PCWIN64'})))
    for i = 1:length(path2add)
        path2add{i}(path2add{i} == '\') = '/';
    end
end

for i = 1:length(path2add)
    addpath(path2add{i},'-end');
end

