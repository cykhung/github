/* 
 * Legacy FIR Filter
 */

/* Custom data type definitions */

typedef  float  mytype;
