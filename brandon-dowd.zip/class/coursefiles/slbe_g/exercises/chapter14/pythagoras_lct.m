%% Initialization
specs = legacy_code('initialize');

%% Specify a name for the S-function
specs.SFunctionName = 'pythagoras_lct_sfcn';

%% Specify source and header files
specs.SourceFiles = {'pythagoras_lct.c'};
specs.HeaderFiles = {'pythagoras_lct.h'};
specs.IncPaths = {'C:\class\coursefiles\slbe_g\exercises'};
specs.SrcPaths = {'C:\class\coursefiles\slbe_g\exercises'};

%% Specify output function
specs.OutputFcnSpec = 'single y1 = pythagoras_lct(single u1[1] ,single u2[1])';

%% Generate S-function
legacy_code('sfcn_cmex_generate',specs);

%% Generate mex file
legacy_code('compile',specs)

%% Generate block
legacy_code('slblock_generate',specs)