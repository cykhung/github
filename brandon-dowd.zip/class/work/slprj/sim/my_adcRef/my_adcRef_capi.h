#ifndef RTW_HEADER_my_adcRef_capi_h_
#define RTW_HEADER_my_adcRef_capi_h_
#include "my_adcRef.h"
extern void my_adcRef_InitializeDataMapInfo ( bjlytd1xlg * const iisf1ii2ef ,
ajmlgktm1y * localDW , dxhrje1sel * localX , void * sysRanPtr , int
contextTid ) ;
#endif
