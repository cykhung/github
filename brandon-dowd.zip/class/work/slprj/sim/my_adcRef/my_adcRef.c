#include "my_adcRef.h"
#include "rtwtypes.h"
#include "my_adcRef_private.h"
#include "mwmathutil.h"
#include "rt_urand_Upu32_Yd_f_pw_snf.h"
#include "rt_TDelayInterpolate.h"
#include "my_adcRef_capi.h"
#include "rt_nonfinite.h"
static RegMdlInfo rtMdlInfo_my_adcRef [ 49 ] = { { "nbwd2lxlw1h" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "my_adcRef" } , {
"oadpwivgn3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "ldkkuytuw0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "pmnxfkyklv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcRef" } , { "mub4wh4g4h" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"n5zb3fbs4l" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "fu3fpyvhq4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "dxhrje1sel" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcRef" } , { "jpqh35kqcx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"l4vig3xxdq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "p2oeqzjbik" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "f1yimsr0bu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcRef" } , { "ajmlgktm1y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"fsent1wo35" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "by4eawkspl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "cihpeg4vcj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcRef" } , { "a5xhdic5mi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"nhmgymcu3k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "hyfqougvtg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "omytsg1epv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcRef" } , { "bumnuthb1a" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"nqancyxefq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "lrfxnug31f" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "iaigp1d3np" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcRef" } , { "aoom4mqvzv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"my_adcRef" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"dwtaf3b4xi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "fiekzpochtc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "my_adcRef" } , { "fiekzpocht" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcRef" } , {
"h1gikt1jue" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcRef" } , { "bjlytd1xlg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcRef" } , { "cuint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , -
1 , ( void * ) "uint64" } , { "uint64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "cint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void * )
"int64" } , { "int64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_my_adcRef_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "my_adcRef" } , { "mr_my_adcRef_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "my_adcRef" } , { "mr_my_adcRef_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "my_adcRef" } , { "mr_my_adcRef_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcRef" } , {
"mr_my_adcRef_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"my_adcRef" } , { "my_adcRef.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL
) } , { "my_adcRef.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"my_adcRef" } } ; opxziaa3t4j opxziaa3t4 = { { - 2.5132741228718344E+7 ,
2.5132741228718344E+7 , - 2.5132741228718333E+7 , 2.513274122871834E+7 , -
2.5132741228718344E+7 } , 2.5132741228718344E+7 , 1.0 , 0.0 , 3.0E-11 , 0.0 ,
0.00390625 , 0.5 , - 0.5 , 0.0 , 1.5E-11 , 1234.0 , { 0U , 1U , 1U , 2U , 1U
} , { 0U , 2U , 4U , 5U } , 0U , { 0U , 1U } , 0U , { 0U , 0U , 0U , 1U } } ;
void nqancyxefq ( ajmlgktm1y * localDW , dxhrje1sel * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> dguhk1fvsn [ 0 ] =
opxziaa3t4 . P_3 ; localX -> dguhk1fvsn [ 1 ] = opxziaa3t4 . P_3 ; localX ->
dguhk1fvsn [ 2 ] = opxziaa3t4 . P_3 ; tmp = muDoubleScalarFloor ( opxziaa3t4
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> k0kjwgalfx = tseed ;
localDW -> iszg30lazj = ( opxziaa3t4 . P_10 - opxziaa3t4 . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> k0kjwgalfx ) + opxziaa3t4 . P_9 ; }
void bumnuthb1a ( ajmlgktm1y * localDW , dxhrje1sel * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> dguhk1fvsn [ 0 ] =
opxziaa3t4 . P_3 ; localX -> dguhk1fvsn [ 1 ] = opxziaa3t4 . P_3 ; localX ->
dguhk1fvsn [ 2 ] = opxziaa3t4 . P_3 ; tmp = muDoubleScalarFloor ( opxziaa3t4
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> k0kjwgalfx = tseed ;
localDW -> iszg30lazj = ( opxziaa3t4 . P_10 - opxziaa3t4 . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> k0kjwgalfx ) + opxziaa3t4 . P_9 ; }
void iaigp1d3np ( bjlytd1xlg * const iisf1ii2ef , ajmlgktm1y * localDW ) { {
real_T * pBuffer = & localDW -> myjvzizrzy . TUbufferArea [ 0 ] ; int_T j ;
char ptrKey [ 1024 ] ; localDW -> j3lojak4ph . Tail = 0 ; localDW ->
j3lojak4ph . Head = 0 ; localDW -> j3lojak4ph . Last = 0 ; localDW ->
j3lojak4ph . CircularBufSize = 1024 ; for ( j = 0 ; j < 1024 ; j ++ ) {
pBuffer [ j ] = opxziaa3t4 . P_5 ; pBuffer [ 1024 + j ] = rtmGetTaskTime (
iisf1ii2ef , 0 ) ; } localDW -> kiv1fyua3z . TUbufferPtrs [ 0 ] = ( void * )
& pBuffer [ 0 ] ; sprintf ( ptrKey , "my_adcRef/Variable\nDelay_TUbuffer%d" ,
0 ) ; slsaSaveRawMemoryForSimTargetOP ( iisf1ii2ef -> _mdlRefSfcnS , ptrKey ,
( void * * ) ( & localDW -> kiv1fyua3z . TUbufferPtrs [ 0 ] ) , 2 * 1024 *
sizeof ( real_T ) , ( NULL ) , ( NULL ) ) ; } } void my_adcRef ( bjlytd1xlg *
const iisf1ii2ef , const real_T * loszxqm0uj , real_T * bbvg2h3gnt , real_T
rtp_nonlingain , fsent1wo35 * localB , ajmlgktm1y * localDW , dxhrje1sel *
localX ) { real_T jmhqrpuruu ; real_T tmp ; uint32_T ri ; localB ->
ddzqdtpiy3 = 0.0 ; for ( ri = opxziaa3t4 . P_17 [ 0U ] ; ri < opxziaa3t4 .
P_17 [ 1U ] ; ri ++ ) { localB -> ddzqdtpiy3 += opxziaa3t4 . P_2 * localX ->
dguhk1fvsn [ 0U ] ; } for ( ri = opxziaa3t4 . P_17 [ 1U ] ; ri < opxziaa3t4 .
P_17 [ 2U ] ; ri ++ ) { localB -> ddzqdtpiy3 += opxziaa3t4 . P_2 * localX ->
dguhk1fvsn [ 1U ] ; } for ( ri = opxziaa3t4 . P_17 [ 2U ] ; ri < opxziaa3t4 .
P_17 [ 3U ] ; ri ++ ) { localB -> ddzqdtpiy3 += opxziaa3t4 . P_2 * localX ->
dguhk1fvsn [ 2U ] ; } { real_T * * uBuffer = ( real_T * * ) & localDW ->
kiv1fyua3z . TUbufferPtrs [ 0 ] ; real_T simTime = rtmGetTaskTime (
iisf1ii2ef , 0 ) ; real_T appliedDelay ; appliedDelay = localB -> ddzqdtpiy3
; if ( appliedDelay > opxziaa3t4 . P_4 ) { appliedDelay = opxziaa3t4 . P_4 ;
} if ( appliedDelay < 0.0 ) { appliedDelay = 0.0 ; } if ( appliedDelay == 0.0
) { localB -> kaelrrneaa = ( * loszxqm0uj ) ; } else { localB -> kaelrrneaa =
rt_TDelayInterpolate ( simTime - appliedDelay , 0.0 , * uBuffer , localDW ->
j3lojak4ph . CircularBufSize , & localDW -> j3lojak4ph . Last , localDW ->
j3lojak4ph . Tail , localDW -> j3lojak4ph . Head , opxziaa3t4 . P_5 , 0 , (
boolean_T ) ( rtmIsMinorTimeStep ( iisf1ii2ef ) && ( ( * uBuffer + localDW ->
j3lojak4ph . CircularBufSize ) [ localDW -> j3lojak4ph . Head ] ==
rtmGetTaskTime ( iisf1ii2ef , 0 ) ) ) ) ; } } if ( rtmIsMajorTimeStep (
iisf1ii2ef ) && rtmIsSampleHit ( iisf1ii2ef , 1 , 0 ) ) { localB ->
bial3wtagd = localDW -> iszg30lazj ; } if ( rtmIsMajorTimeStep ( iisf1ii2ef )
&& rtmIsSampleHit ( iisf1ii2ef , 2 , 0 ) ) { jmhqrpuruu = rtp_nonlingain *
localB -> kaelrrneaa ; tmp = 1.0 / rtp_nonlingain ; jmhqrpuruu =
muDoubleScalarRound ( tmp * muDoubleScalarTanh ( jmhqrpuruu ) / opxziaa3t4 .
P_6 ) * opxziaa3t4 . P_6 ; if ( jmhqrpuruu > opxziaa3t4 . P_7 ) { *
bbvg2h3gnt = opxziaa3t4 . P_7 ; } else if ( jmhqrpuruu < opxziaa3t4 . P_8 ) {
* bbvg2h3gnt = opxziaa3t4 . P_8 ; } else { * bbvg2h3gnt = jmhqrpuruu ; } } }
void omytsg1epv ( bjlytd1xlg * const iisf1ii2ef , const real_T * loszxqm0uj ,
ajmlgktm1y * localDW ) { if ( rtmIsMajorTimeStep ( iisf1ii2ef ) ) { if (
memcmp ( iisf1ii2ef -> nonContDerivSignal [ 0 ] . pCurrVal , iisf1ii2ef ->
nonContDerivSignal [ 0 ] . pPrevVal , iisf1ii2ef -> nonContDerivSignal [ 0 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( iisf1ii2ef -> nonContDerivSignal [
0 ] . pPrevVal , iisf1ii2ef -> nonContDerivSignal [ 0 ] . pCurrVal ,
iisf1ii2ef -> nonContDerivSignal [ 0 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( iisf1ii2ef -> _mdlRefSfcnS ) ; } } { real_T * *
uBuffer = ( real_T * * ) & localDW -> kiv1fyua3z . TUbufferPtrs [ 0 ] ; int
numBuffers = 2 ; real_T simTime = rtmGetTaskTime ( iisf1ii2ef , 0 ) ;
boolean_T bufferisfull = false ; localDW -> j3lojak4ph . Head = ( ( localDW
-> j3lojak4ph . Head < ( localDW -> j3lojak4ph . CircularBufSize - 1 ) ) ? (
localDW -> j3lojak4ph . Head + 1 ) : 0 ) ; if ( localDW -> j3lojak4ph . Head
== localDW -> j3lojak4ph . Tail ) { bufferisfull = true ; localDW ->
j3lojak4ph . Tail = ( ( localDW -> j3lojak4ph . Tail < ( localDW ->
j3lojak4ph . CircularBufSize - 1 ) ) ? ( localDW -> j3lojak4ph . Tail + 1 ) :
0 ) ; } ( * uBuffer + localDW -> j3lojak4ph . CircularBufSize ) [ localDW ->
j3lojak4ph . Head ] = simTime ; ( * uBuffer ) [ localDW -> j3lojak4ph . Head
] = ( * loszxqm0uj ) ; if ( bufferisfull ) {
ssSetBlockStateForSolverChangedAtMajorStep ( iisf1ii2ef -> _mdlRefSfcnS ) ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( iisf1ii2ef ->
_mdlRefSfcnS ) ; } } if ( rtmIsMajorTimeStep ( iisf1ii2ef ) && rtmIsSampleHit
( iisf1ii2ef , 1 , 0 ) ) { localDW -> iszg30lazj = ( opxziaa3t4 . P_10 -
opxziaa3t4 . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> k0kjwgalfx ) +
opxziaa3t4 . P_9 ; } } void hyfqougvtg ( fsent1wo35 * localB , dxhrje1sel *
localX , fu3fpyvhq4 * localXdot ) { uint32_T ri ; localXdot -> dguhk1fvsn [ 0
] = 0.0 ; localXdot -> dguhk1fvsn [ 1 ] = 0.0 ; localXdot -> dguhk1fvsn [ 2 ]
= 0.0 ; for ( ri = opxziaa3t4 . P_13 [ 0U ] ; ri < opxziaa3t4 . P_13 [ 1U ] ;
ri ++ ) { localXdot -> dguhk1fvsn [ opxziaa3t4 . P_12 [ ri ] ] += opxziaa3t4
. P_0 [ ri ] * localX -> dguhk1fvsn [ 0U ] ; } for ( ri = opxziaa3t4 . P_13 [
1U ] ; ri < opxziaa3t4 . P_13 [ 2U ] ; ri ++ ) { localXdot -> dguhk1fvsn [
opxziaa3t4 . P_12 [ ri ] ] += opxziaa3t4 . P_0 [ ri ] * localX -> dguhk1fvsn
[ 1U ] ; } for ( ri = opxziaa3t4 . P_13 [ 2U ] ; ri < opxziaa3t4 . P_13 [ 3U
] ; ri ++ ) { localXdot -> dguhk1fvsn [ opxziaa3t4 . P_12 [ ri ] ] +=
opxziaa3t4 . P_0 [ ri ] * localX -> dguhk1fvsn [ 2U ] ; } for ( ri =
opxziaa3t4 . P_15 [ 0U ] ; ri < opxziaa3t4 . P_15 [ 1U ] ; ri ++ ) {
localXdot -> dguhk1fvsn [ opxziaa3t4 . P_14 ] += opxziaa3t4 . P_1 * localB ->
bial3wtagd ; } { } } void cihpeg4vcj ( bjlytd1xlg * const iisf1ii2ef ) { if (
! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( iisf1ii2ef ->
_mdlRefSfcnS , "my_adcRef" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ;
} } void lrfxnug31f ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , int_T mdlref_TID2 , bjlytd1xlg * const iisf1ii2ef , fsent1wo35
* localB , ajmlgktm1y * localDW , dxhrje1sel * localX , void * sysRanPtr ,
int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; ( void ) memset ( ( void * ) iisf1ii2ef , 0 , sizeof
( bjlytd1xlg ) ) ; iisf1ii2ef -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; iisf1ii2ef -> Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ;
iisf1ii2ef -> Timing . mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; iisf1ii2ef ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( iisf1ii2ef -> _mdlRefSfcnS , "my_adcRef" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> ddzqdtpiy3 = 0.0
; localB -> kaelrrneaa = 0.0 ; localB -> bial3wtagd = 0.0 ; } ( void ) memset
( ( void * ) localDW , 0 , sizeof ( ajmlgktm1y ) ) ; localDW -> iszg30lazj =
0.0 ; localDW -> myjvzizrzy . modelTStart = 0.0 ; { int32_T i ; for ( i = 0 ;
i < 2048 ; i ++ ) { localDW -> myjvzizrzy . TUbufferArea [ i ] = 0.0 ; } }
my_adcRef_InitializeDataMapInfo ( iisf1ii2ef , localDW , localX , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
iisf1ii2ef -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( iisf1ii2ef ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
iisf1ii2ef -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } iisf1ii2ef ->
nonContDerivSignal [ 0 ] . pPrevVal = ( char_T * ) iisf1ii2ef ->
NonContDerivMemory . mr_nonContSig0 ; iisf1ii2ef -> nonContDerivSignal [ 0 ]
. sizeInBytes = ( 1 * sizeof ( real_T ) ) ; iisf1ii2ef -> nonContDerivSignal
[ 0 ] . pCurrVal = ( char_T * ) ( & localB -> bial3wtagd ) ; ; } void
mr_my_adcRef_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_my_adcRef , 49 ) ; * retVal = 1 ; } static void
mr_my_adcRef_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_my_adcRef_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_my_adcRef_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_my_adcRef_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_my_adcRef_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_my_adcRef_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_my_adcRef_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_my_adcRef_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_my_adcRef_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_my_adcRef_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_my_adcRef_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_my_adcRef_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_my_adcRef_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_my_adcRef_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_my_adcRef_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_my_adcRef_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_my_adcRef_GetDWork ( const nbwd2lxlw1h * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_my_adcRef_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 4 ] = { "mdlrefDW->rtdw.iszg30lazj" ,
"mdlrefDW->rtdw.myjvzizrzy" , "mdlrefDW->rtdw.k0kjwgalfx" ,
"mdlrefDW->rtdw.j3lojak4ph" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 4 , rtdwDataFieldNames ) ; mr_my_adcRef_cacheDataAsMxArray ( rtdwData
, 0 , 0 , ( const void * ) & ( mdlrefDW -> rtdw . iszg30lazj ) , sizeof (
mdlrefDW -> rtdw . iszg30lazj ) ) ; mr_my_adcRef_cacheDataAsMxArray (
rtdwData , 0 , 1 , ( const void * ) & ( mdlrefDW -> rtdw . myjvzizrzy ) ,
sizeof ( mdlrefDW -> rtdw . myjvzizrzy ) ) ; mr_my_adcRef_cacheDataAsMxArray
( rtdwData , 0 , 2 , ( const void * ) & ( mdlrefDW -> rtdw . k0kjwgalfx ) ,
sizeof ( mdlrefDW -> rtdw . k0kjwgalfx ) ) ; mr_my_adcRef_cacheDataAsMxArray
( rtdwData , 0 , 3 , ( const void * ) & ( mdlrefDW -> rtdw . j3lojak4ph ) ,
sizeof ( mdlrefDW -> rtdw . j3lojak4ph ) ) ; mxSetFieldByNumber ( ssDW , 0 ,
1 , rtdwData ) ; } ( void ) mdlrefDW ; return ssDW ; } void
mr_my_adcRef_SetDWork ( nbwd2lxlw1h * mdlrefDW , const mxArray * ssDW ) { (
void ) ssDW ; ( void ) mdlrefDW ; mr_my_adcRef_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) )
; { const mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_my_adcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
iszg30lazj ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW -> rtdw . iszg30lazj ) )
; mr_my_adcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
myjvzizrzy ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw . myjvzizrzy ) )
; mr_my_adcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
k0kjwgalfx ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . k0kjwgalfx ) )
; mr_my_adcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
j3lojak4ph ) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . j3lojak4ph ) )
; } } void mr_my_adcRef_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 3485244135U , 2027951321U , 3368238626U ,
2495882241U , } ; slmrModelRefRegisterSimStateChecksum ( S , "my_adcRef" , &
chksum [ 0 ] ) ; } mxArray * mr_my_adcRef_GetSimStateDisallowedBlocks ( ) {
return ( NULL ) ; }
#if defined(_MSC_VER)
#pragma warning(disable: 4505) //unreferenced local function has been removed
#endif
