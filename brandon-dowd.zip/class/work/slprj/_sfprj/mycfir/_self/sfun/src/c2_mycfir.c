/* Include files */

#include "mycfir_sfun.h"
#include "c2_mycfir.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;

/* Function Declarations */
static void initialize_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void initialize_params_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void mdl_start_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void mdl_terminate_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance);
static void mdl_cleanup_runtime_resources_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance);
static void enable_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void disable_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void sf_gateway_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void ext_mode_exec_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static void c2_update_jit_animation_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance);
static void c2_do_animation_call_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance);
static const mxArray *get_sim_state_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance);
static void set_sim_state_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_st);
static void initSimStructsc2_mycfir(SFc2_mycfirInstanceStruct *chartInstance);
static real32_T c2_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_b_y, const char_T *c2_identifier);
static real32_T c2_b_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static uint8_T c2_c_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_b_is_active_c2_mycfir, const char_T *c2_identifier);
static uint8_T c2_d_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_slStringInitializeDynamicBuffers(SFc2_mycfirInstanceStruct
  *chartInstance);
static void c2_chart_data_browse_helper(SFc2_mycfirInstanceStruct *chartInstance,
  int32_T c2_ssIdNumber, const mxArray **c2_mxData, uint8_T *c2_isValueTooBig);
static void init_dsm_address_info(SFc2_mycfirInstanceStruct *chartInstance);
static void init_simulink_io_address(SFc2_mycfirInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c2_is_active_c2_mycfir = 0U;
}

static void initialize_params_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_start_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_terminate_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance)
{
  static const uint32_T c2_decisionTxtEndIdx = 0U;
  static const uint32_T c2_decisionTxtStartIdx = 0U;
  setDebuggerFlag(chartInstance->S, true);
  setDataBrowseFcn(chartInstance->S, (void *)&c2_chart_data_browse_helper);
  chartInstance->c2_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c2_RuntimeVar,
    &chartInstance->c2_IsDebuggerActive,
    &chartInstance->c2_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c2_mlFcnLineNumber, &chartInstance->c2_IsHeatMapPresent, 0);
  sim_mode_is_external(chartInstance->S);
  covrtCreateStateflowInstanceData(chartInstance->c2_covrtInstance, 1U, 0U, 1U,
    8U);
  covrtChartInitFcn(chartInstance->c2_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c2_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c2_decisionTxtStartIdx, &c2_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c2_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c2_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c2_covrtInstance, 4U, 0U, 0U,
                     "eML_blk_kernel", 0, -1, 248);
}

static void mdl_cleanup_runtime_resources_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c2_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c2_covrtInstance);
}

static void enable_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  real_T c2_b_coeffs;
  real_T c2_b_in;
  real_T c2_b_ntaps;
  real32_T c2_b_y;
  chartInstance->c2_JITTransitionAnimation[0] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 2U,
                    *chartInstance->c2_coeffs);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 1U,
                    *chartInstance->c2_ntaps);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 0U, *chartInstance->c2_in);
  chartInstance->c2_sfEvent = CALL_EVENT;
  c2_b_in = *chartInstance->c2_in;
  c2_b_ntaps = *chartInstance->c2_ntaps;
  c2_b_coeffs = *chartInstance->c2_coeffs;
  covrtEmlFcnEval(chartInstance->c2_covrtInstance, 4U, 0, 0);
  c2_b_y = fir_filt(c2_b_in, c2_b_ntaps, &c2_b_coeffs);
  *chartInstance->c2_y = c2_b_y;
  c2_do_animation_call_c2_mycfir(chartInstance);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 3U, (real_T)
                    *chartInstance->c2_y);
}

static void ext_mode_exec_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c2_update_jit_animation_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c2_do_animation_call_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static const mxArray *get_sim_state_c2_mycfir(SFc2_mycfirInstanceStruct
  *chartInstance)
{
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_st;
  c2_st = NULL;
  c2_st = NULL;
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_createcellmatrix(2, 1), false);
  c2_c_y = NULL;
  sf_mex_assign(&c2_c_y, sf_mex_create("y", chartInstance->c2_y, 1, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_b_y, 0, c2_c_y);
  c2_d_y = NULL;
  sf_mex_assign(&c2_d_y, sf_mex_create("y",
    &chartInstance->c2_is_active_c2_mycfir, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c2_b_y, 1, c2_d_y);
  sf_mex_assign(&c2_st, c2_b_y, false);
  return c2_st;
}

static void set_sim_state_c2_mycfir(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_st)
{
  const mxArray *c2_u;
  chartInstance->c2_doneDoubleBufferReInit = true;
  c2_u = sf_mex_dup(c2_st);
  *chartInstance->c2_y = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c2_u, 0)), "y");
  chartInstance->c2_is_active_c2_mycfir = c2_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 1)), "is_active_c2_mycfir");
  sf_mex_destroy(&c2_u);
  sf_mex_destroy(&c2_st);
}

static void initSimStructsc2_mycfir(SFc2_mycfirInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

const mxArray *sf_c2_mycfir_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  sf_mex_assign(&c2_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c2_nameCaptureInfo;
}

static real32_T c2_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_b_y, const char_T *c2_identifier)
{
  emlrtMsgIdentifier c2_thisId;
  real32_T c2_c_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_c_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_y), &c2_thisId);
  sf_mex_destroy(&c2_b_y);
  return c2_c_y;
}

static real32_T c2_b_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real32_T c2_b_y;
  real32_T c2_f;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_f, 0, 1, 0U, 0, 0U, 0);
  c2_b_y = c2_f;
  sf_mex_destroy(&c2_u);
  return c2_b_y;
}

static uint8_T c2_c_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_b_is_active_c2_mycfir, const char_T *c2_identifier)
{
  emlrtMsgIdentifier c2_thisId;
  uint8_T c2_b_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_b_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_is_active_c2_mycfir), &c2_thisId);
  sf_mex_destroy(&c2_b_is_active_c2_mycfir);
  return c2_b_y;
}

static uint8_T c2_d_emlrt_marshallIn(SFc2_mycfirInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_b_u;
  uint8_T c2_b_y;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_b_u, 1, 3, 0U, 0, 0U, 0);
  c2_b_y = c2_b_u;
  sf_mex_destroy(&c2_u);
  return c2_b_y;
}

static void c2_slStringInitializeDynamicBuffers(SFc2_mycfirInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c2_chart_data_browse_helper(SFc2_mycfirInstanceStruct *chartInstance,
  int32_T c2_ssIdNumber, const mxArray **c2_mxData, uint8_T *c2_isValueTooBig)
{
  real_T c2_d;
  real_T c2_d1;
  real_T c2_d2;
  real32_T c2_f;
  *c2_mxData = NULL;
  *c2_mxData = NULL;
  *c2_isValueTooBig = 0U;
  switch (c2_ssIdNumber) {
   case 4U:
    c2_d = *chartInstance->c2_in;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_d, 0, 0U, 0U, 0U, 0),
                  false);
    break;

   case 5U:
    c2_f = *chartInstance->c2_y;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_f, 1, 0U, 0U, 0U, 0),
                  false);
    break;

   case 6U:
    c2_d1 = *chartInstance->c2_ntaps;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_d1, 0, 0U, 0U, 0U, 0),
                  false);
    break;

   case 7U:
    c2_d2 = *chartInstance->c2_coeffs;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_d2, 0, 0U, 0U, 0U, 0),
                  false);
    break;
  }
}

static void init_dsm_address_info(SFc2_mycfirInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc2_mycfirInstanceStruct *chartInstance)
{
  chartInstance->c2_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c2_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c2_in = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    0);
  chartInstance->c2_y = (real32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c2_ntaps = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c2_coeffs = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c2_mycfir_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(529481373U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1964478691U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2635875291U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(619907587U);
}

mxArray *sf_c2_mycfir_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c2_mycfir_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("fir_filt");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c2_mycfir_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = sf_mex_decode(
    "eNpjYPT0ZQACPiCWYGRgYAPSHEDMyAABrEh8RiRxkPoXDPjVM6Gpd0BSz4JFPR+SegEoPzElJTi"
    "/tCg51S0zJ7UYIlbAQJo7CdnLg2YviJ+WWRSflplTklqklwwSBwDIQA4H"
    );
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c2_mycfir(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiD+wMjAwAakOYCYiQECWKF8RqgYI1ycBS6uAMQllQWpIPHiomTPFCCdl5gL5ie"
    "WVnjmpeWDzbdgQJjPhsV8RiTzOaHiEPDBnjL9Ig4g/QZI+lkI6BcAsiqh4QILH/LtV3CgTD/Efg"
    "8C7hdGcT+En1kcn5hcklmWGp9sFJ9bmZyWWQQ3DwQARm4XMg=="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_mycfir_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "s9dy3WNbCu0PQaoDkSyVdeD";
}

static void sf_opaque_initialize_c2_mycfir(void *chartInstanceVar)
{
  initialize_params_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
  initialize_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c2_mycfir(void *chartInstanceVar)
{
  enable_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c2_mycfir(void *chartInstanceVar)
{
  disable_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c2_mycfir(void *chartInstanceVar)
{
  sf_gateway_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c2_mycfir(SimStruct* S)
{
  return get_sim_state_c2_mycfir((SFc2_mycfirInstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c2_mycfir(SimStruct* S, const mxArray *st)
{
  set_sim_state_c2_mycfir((SFc2_mycfirInstanceStruct*)sf_get_chart_instance_ptr
    (S), st);
}

static void sf_opaque_cleanup_runtime_resources_c2_mycfir(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_mycfirInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_mycfir_optimization_info();
    }

    mdl_cleanup_runtime_resources_c2_mycfir((SFc2_mycfirInstanceStruct*)
      chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c2_mycfir(void *chartInstanceVar)
{
  mdl_start_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_mdl_terminate_c2_mycfir(void *chartInstanceVar)
{
  mdl_terminate_c2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_mycfir((SFc2_mycfirInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_mycfir(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_mycfir((SFc2_mycfirInstanceStruct*)
      sf_get_chart_instance_ptr(S));
    initSimStructsc2_mycfir((SFc2_mycfirInstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c2_mycfir_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [21] = {
    "eNrtWE+P20QUd9KloqJUEUWCA1J75FKpbIUEEoLs5g8EZbsBZ7eCy2piv8SjjGfc+ZOs+2n4EnD",
    "hwIUPwYfgwLFH3jhOGpyQeBxRWkQkxxl7fvN77837N/FqvTMPP3fwev6+593E+5t41b3F5418XF",
    "u7Fs+PvM/ycfMtz+MmHhBJYuW5fziJ4VtQghlNBe/xsSiPpXwMEniACyRCaideRWPDKJ92DQ8ss",
    "3oS0SDyI2FYeIoLkvCcs/TveBOjB8jYphIC3QUIdSSFmURdRia7rSD1vBVBMFUmdraVAu2bxKqq",
    "zgzTNGHQuYagx5UmaAW1R19fEw0tfe1mZKuv8pdoESeMEl7e1hFRPiToHRoukhC/z41G65XCBhG",
    "R+hQiMgPVp9OMXXAoxU4Vzh5RTrSQlLBOzFp2tZL6DhjqeCZCYK57hPqeSiDTRFCuHQPC76KdO5",
    "yMGLRhZCaOvD48NTYaLinMQbrt77glZiDJBM65m8zZHnWuM6dcxVJJrKYxXBJ5EqDvKgjd8gYGn",
    "fIJuiMMcRknLGQm7qmhpDP0DTdeE/ds+FfKdSZeeL+qhM14OzNw9qsVbzfgLcKYcsMORdKHGbCM",
    "v000qYBd8DuAlaLhUKB32GzjmLEMpxgJObYleEjLe+WsgMoK22MsUiXgNLZhACGaeSX6aqF9cWS",
    "UFnELU0673y/Jt4ntcQ1yTAIoXWMkoQpQ4MyvHHlDqmwgIRqtpDMtS6+wiMFKUE+NDW/PhZyijV",
    "2L2Qtb2UhwQ0M4wcSsIUtyHfTuS8JMSZljNcH4Qfe4UJhl3XgRa+OnEjggQQShrZyUwRnmWVyg7",
    "BYrW/JPUNsZ1WkbVCBpUjaSDCZ0LLrWSsM0gQs+5WLOu1LEft557fArAMwaRHLKJ6dYwmXaReHL",
    "SS3h6TDL7q5NjrUz0YyMrG98CRyrodXVdg0kwKjq8ECEKNAhWJ8+wyaGK6o0Fup0UerDrP9+6L3",
    "ov2+X6L+XffsunLeB81a45f3DNXxtC6+3di/y3ar/df6NAl8dn9RqtQzXXMO9XeA5KuDsvAZeP1",
    "6/8+uDn9o/32t8/Xv/u1+e7eOvbfDXst8W90Pd7XxzJx9/sOxxVhl1tpF07Nyv1uQ62rL+e2vrN",
    "/Kx+jRMHz15PGqZh4NviGhP/fQS83+23h+13fLWC/Iun9+3fRUGXBa/MuiF+RnLjolZ9P52/U/W",
    "5L25xx631vwJJfviMPy7zeI+Hu3BN/BXWvDb6vz3m4fhy+333cJ+38367CtisylcBcdXcRqMqdy",
    "Ix6r+7YrzXjLudZHzf7v88/qVqW83KuKq8nkvGXeofq51+3Wfv6teeIX5jVdYj1353qV/e9X0+s",
    "1z66/u5ePPV2f9VkRZuOW0kb/GA8F429v/iH8/d7Tfsp/sWPvlfwp//+iEE5bi8WJxfMsfD6T9b",
    "2/1SgJR289w/0Y9Wd6be/qp24X4tuM55aGYqwcfHX98fEh9+hOvkQoa",
    ""
  };

  static char newstr [1481] = "";
  newstr[0] = '\0';
  for (i = 0; i < 21; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c2_mycfir(SimStruct *S)
{
  const char* newstr = sf_c2_mycfir_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(3289544885U));
  ssSetChecksum1(S,(3141842477U));
  ssSetChecksum2(S,(3964276767U));
  ssSetChecksum3(S,(2059360588U));
}

static void mdlRTW_c2_mycfir(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c2_mycfir(SimStruct *S)
{
  SFc2_mycfirInstanceStruct *chartInstance;
  chartInstance = (SFc2_mycfirInstanceStruct *)utMalloc(sizeof
    (SFc2_mycfirInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc2_mycfirInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c2_mycfir;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c2_mycfir;
  chartInstance->chartInfo.mdlStart = sf_opaque_mdl_start_c2_mycfir;
  chartInstance->chartInfo.mdlTerminate = sf_opaque_mdl_terminate_c2_mycfir;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c2_mycfir;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c2_mycfir;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c2_mycfir;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c2_mycfir;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c2_mycfir;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c2_mycfir;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_mycfir;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c2_mycfir;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->chartInfo.chartStateSetterFcn = NULL;
  chartInstance->chartInfo.chartStateGetterFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c2_JITStateAnimation,
    chartInstance->c2_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c2_mycfir(chartInstance);
}

void c2_mycfir_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c2_mycfir(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_mycfir(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_mycfir(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_mycfir_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
