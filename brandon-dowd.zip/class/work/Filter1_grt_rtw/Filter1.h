/*
 * Filter1.h
 *
 * Course Support License -- for instructional use for courses.  Not for
 * government, research, commercial, or other organizational use.
 *
 * Code generation for model "Filter1".
 *
 * Model version              : 1.10
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu May 26 11:17:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Filter1_h_
#define RTW_HEADER_Filter1_h_
#ifndef Filter1_COMMON_INCLUDES_
#define Filter1_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* Filter1_COMMON_INCLUDES_ */

#include "Filter1_types.h"
#include <float.h>
#include <string.h>
#include <stddef.h>
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T Delay11_DSTATE;               /* '<S1>/Delay11' */
  real_T Delay21_DSTATE;               /* '<S1>/Delay21' */
  real_T Delay12_DSTATE;               /* '<S1>/Delay12' */
  real_T Delay22_DSTATE;               /* '<S1>/Delay22' */
  real_T Delay13_DSTATE;               /* '<S1>/Delay13' */
  real_T Delay23_DSTATE;               /* '<S1>/Delay23' */
} DW_Filter1_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Input;                        /* '<Root>/Input' */
} ExtU_Filter1_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T Output;                       /* '<Root>/Output' */
} ExtY_Filter1_T;

/* Parameters (default storage) */
struct P_Filter1_T_ {
  real_T s1_Gain;                      /* Expression: 1.19093604248525642
                                        * Referenced by: '<S1>/s(1)'
                                        */
  real_T Delay11_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S1>/Delay11'
                                        */
  real_T a21_Gain;                     /* Expression: 0.789521063010877766
                                        * Referenced by: '<S1>/a(2)(1)'
                                        */
  real_T Delay21_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S1>/Delay21'
                                        */
  real_T a31_Gain;                     /* Expression: 0.785291572668120219
                                        * Referenced by: '<S1>/a(3)(1)'
                                        */
  real_T b21_Gain;                     /* Expression: 1.39967742863683742
                                        * Referenced by: '<S1>/b(2)(1)'
                                        */
  real_T s2_Gain;                      /* Expression: 4.52611908589140821
                                        * Referenced by: '<S1>/s(2)'
                                        */
  real_T Delay12_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S1>/Delay12'
                                        */
  real_T a22_Gain;                     /* Expression: -0.0739415086412789635
                                        * Referenced by: '<S1>/a(2)(2)'
                                        */
  real_T Delay22_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S1>/Delay22'
                                        */
  real_T a32_Gain;                     /* Expression: 0.243260766726613953
                                        * Referenced by: '<S1>/a(3)(2)'
                                        */
  real_T b22_Gain;                     /* Expression: 1.86711993617404026
                                        * Referenced by: '<S1>/b(2)(2)'
                                        */
  real_T s3_Gain;                      /* Expression: 0.0354467065196260658
                                        * Referenced by: '<S1>/s(3)'
                                        */
  real_T Delay13_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S1>/Delay13'
                                        */
  real_T a23_Gain;                     /* Expression: 1.05157141688081657
                                        * Referenced by: '<S1>/a(2)(3)'
                                        */
  real_T Delay23_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S1>/Delay23'
                                        */
  real_T a33_Gain;                     /* Expression: 0.960628340932030089
                                        * Referenced by: '<S1>/a(3)(3)'
                                        */
  real_T b23_Gain;                     /* Expression: 1.21770959050639371
                                        * Referenced by: '<S1>/b(2)(3)'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_Filter1_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_Filter1_T Filter1_P;

/* Block states (default storage) */
extern DW_Filter1_T Filter1_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_Filter1_T Filter1_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_Filter1_T Filter1_Y;

/* Model entry point functions */
extern void Filter1_initialize(void);
extern void Filter1_step(void);
extern void Filter1_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Filter1_T *const Filter1_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('colornoise/Filter1')    - opens subsystem colornoise/Filter1
 * hilite_system('colornoise/Filter1/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'colornoise'
 * '<S1>'   : 'colornoise/Filter1'
 */
#endif                                 /* RTW_HEADER_Filter1_h_ */
