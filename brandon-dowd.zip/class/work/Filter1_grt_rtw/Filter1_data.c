/*
 * Filter1_data.c
 *
 * Course Support License -- for instructional use for courses.  Not for
 * government, research, commercial, or other organizational use.
 *
 * Code generation for model "Filter1".
 *
 * Model version              : 1.10
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu May 26 11:17:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Filter1.h"

/* Block parameters (default storage) */
P_Filter1_T Filter1_P = {
  /* Expression: 1.19093604248525642
   * Referenced by: '<S1>/s(1)'
   */
  1.1909360424852564,

  /* Expression: 0
   * Referenced by: '<S1>/Delay11'
   */
  0.0,

  /* Expression: 0.789521063010877766
   * Referenced by: '<S1>/a(2)(1)'
   */
  0.78952106301087777,

  /* Expression: 0
   * Referenced by: '<S1>/Delay21'
   */
  0.0,

  /* Expression: 0.785291572668120219
   * Referenced by: '<S1>/a(3)(1)'
   */
  0.78529157266812022,

  /* Expression: 1.39967742863683742
   * Referenced by: '<S1>/b(2)(1)'
   */
  1.3996774286368374,

  /* Expression: 4.52611908589140821
   * Referenced by: '<S1>/s(2)'
   */
  4.5261190858914082,

  /* Expression: 0
   * Referenced by: '<S1>/Delay12'
   */
  0.0,

  /* Expression: -0.0739415086412789635
   * Referenced by: '<S1>/a(2)(2)'
   */
  -0.073941508641278963,

  /* Expression: 0
   * Referenced by: '<S1>/Delay22'
   */
  0.0,

  /* Expression: 0.243260766726613953
   * Referenced by: '<S1>/a(3)(2)'
   */
  0.24326076672661395,

  /* Expression: 1.86711993617404026
   * Referenced by: '<S1>/b(2)(2)'
   */
  1.8671199361740403,

  /* Expression: 0.0354467065196260658
   * Referenced by: '<S1>/s(3)'
   */
  0.035446706519626066,

  /* Expression: 0
   * Referenced by: '<S1>/Delay13'
   */
  0.0,

  /* Expression: 1.05157141688081657
   * Referenced by: '<S1>/a(2)(3)'
   */
  1.0515714168808166,

  /* Expression: 0
   * Referenced by: '<S1>/Delay23'
   */
  0.0,

  /* Expression: 0.960628340932030089
   * Referenced by: '<S1>/a(3)(3)'
   */
  0.96062834093203009,

  /* Expression: 1.21770959050639371
   * Referenced by: '<S1>/b(2)(3)'
   */
  1.2177095905063937
};
