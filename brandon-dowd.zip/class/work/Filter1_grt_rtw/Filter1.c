/*
 * Filter1.c
 *
 * Course Support License -- for instructional use for courses.  Not for
 * government, research, commercial, or other organizational use.
 *
 * Code generation for model "Filter1".
 *
 * Model version              : 1.10
 * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
 * C source code generated on : Thu May 26 11:17:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Filter1.h"
#include "rtwtypes.h"
#include "Filter1_private.h"
#include "rt_nonfinite.h"

/* Block states (default storage) */
DW_Filter1_T Filter1_DW;

/* External inputs (root inport signals with default storage) */
ExtU_Filter1_T Filter1_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_Filter1_T Filter1_Y;

/* Real-time model */
static RT_MODEL_Filter1_T Filter1_M_;
RT_MODEL_Filter1_T *const Filter1_M = &Filter1_M_;

/* Model step function */
void Filter1_step(void)
{
  real_T rtb_Delay11;
  real_T rtb_Delay12;
  real_T rtb_Delay13;
  real_T rtb_SumA31;
  real_T rtb_SumA32;
  real_T rtb_SumA33;

  /* Delay: '<S1>/Delay11' */
  rtb_Delay11 = Filter1_DW.Delay11_DSTATE;

  /* Sum: '<S1>/SumA31' incorporates:
   *  Delay: '<S1>/Delay11'
   *  Delay: '<S1>/Delay21'
   *  Gain: '<S1>/a(2)(1)'
   *  Gain: '<S1>/a(3)(1)'
   *  Gain: '<S1>/s(1)'
   *  Inport: '<Root>/Input'
   *  Sum: '<S1>/SumA21'
   */
  rtb_SumA31 = (Filter1_P.s1_Gain * Filter1_U.Input - Filter1_P.a21_Gain *
                Filter1_DW.Delay11_DSTATE) - Filter1_P.a31_Gain *
    Filter1_DW.Delay21_DSTATE;

  /* Delay: '<S1>/Delay12' */
  rtb_Delay12 = Filter1_DW.Delay12_DSTATE;

  /* Sum: '<S1>/SumA32' incorporates:
   *  Delay: '<S1>/Delay11'
   *  Delay: '<S1>/Delay12'
   *  Delay: '<S1>/Delay21'
   *  Delay: '<S1>/Delay22'
   *  Gain: '<S1>/a(2)(2)'
   *  Gain: '<S1>/a(3)(2)'
   *  Gain: '<S1>/b(2)(1)'
   *  Gain: '<S1>/s(2)'
   *  Sum: '<S1>/SumA22'
   *  Sum: '<S1>/SumB21'
   *  Sum: '<S1>/SumB31'
   */
  rtb_SumA32 = (((Filter1_P.b21_Gain * Filter1_DW.Delay11_DSTATE + rtb_SumA31) +
                 Filter1_DW.Delay21_DSTATE) * Filter1_P.s2_Gain -
                Filter1_P.a22_Gain * Filter1_DW.Delay12_DSTATE) -
    Filter1_P.a32_Gain * Filter1_DW.Delay22_DSTATE;

  /* Delay: '<S1>/Delay13' */
  rtb_Delay13 = Filter1_DW.Delay13_DSTATE;

  /* Sum: '<S1>/SumA33' incorporates:
   *  Delay: '<S1>/Delay12'
   *  Delay: '<S1>/Delay13'
   *  Delay: '<S1>/Delay22'
   *  Delay: '<S1>/Delay23'
   *  Gain: '<S1>/a(2)(3)'
   *  Gain: '<S1>/a(3)(3)'
   *  Gain: '<S1>/b(2)(2)'
   *  Gain: '<S1>/s(3)'
   *  Sum: '<S1>/SumA23'
   *  Sum: '<S1>/SumB22'
   *  Sum: '<S1>/SumB32'
   */
  rtb_SumA33 = (((Filter1_P.b22_Gain * Filter1_DW.Delay12_DSTATE + rtb_SumA32) +
                 Filter1_DW.Delay22_DSTATE) * Filter1_P.s3_Gain -
                Filter1_P.a23_Gain * Filter1_DW.Delay13_DSTATE) -
    Filter1_P.a33_Gain * Filter1_DW.Delay23_DSTATE;

  /* Outport: '<Root>/Output' incorporates:
   *  Delay: '<S1>/Delay13'
   *  Delay: '<S1>/Delay23'
   *  Gain: '<S1>/b(2)(3)'
   *  Sum: '<S1>/SumB23'
   *  Sum: '<S1>/SumB33'
   */
  Filter1_Y.Output = (Filter1_P.b23_Gain * Filter1_DW.Delay13_DSTATE +
                      rtb_SumA33) + Filter1_DW.Delay23_DSTATE;

  /* Update for Delay: '<S1>/Delay11' */
  Filter1_DW.Delay11_DSTATE = rtb_SumA31;

  /* Update for Delay: '<S1>/Delay21' */
  Filter1_DW.Delay21_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S1>/Delay12' */
  Filter1_DW.Delay12_DSTATE = rtb_SumA32;

  /* Update for Delay: '<S1>/Delay22' */
  Filter1_DW.Delay22_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S1>/Delay13' */
  Filter1_DW.Delay13_DSTATE = rtb_SumA33;

  /* Update for Delay: '<S1>/Delay23' */
  Filter1_DW.Delay23_DSTATE = rtb_Delay13;

  /* Matfile logging */
  rt_UpdateTXYLogVars(Filter1_M->rtwLogInfo, (&Filter1_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                             /* Sample time: [0.046439909297052155s, 0.0s] */
    if ((rtmGetTFinal(Filter1_M)!=-1) &&
        !((rtmGetTFinal(Filter1_M)-Filter1_M->Timing.taskTime0) >
          Filter1_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(Filter1_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Filter1_M->Timing.clockTick0)) {
    ++Filter1_M->Timing.clockTickH0;
  }

  Filter1_M->Timing.taskTime0 = Filter1_M->Timing.clockTick0 *
    Filter1_M->Timing.stepSize0 + Filter1_M->Timing.clockTickH0 *
    Filter1_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Filter1_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Filter1_M, 0,
                sizeof(RT_MODEL_Filter1_T));
  rtmSetTFinal(Filter1_M, 9.9845804988662135);
  Filter1_M->Timing.stepSize0 = 0.046439909297052155;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    Filter1_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Filter1_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Filter1_M->rtwLogInfo, (NULL));
    rtliSetLogT(Filter1_M->rtwLogInfo, "tout");
    rtliSetLogX(Filter1_M->rtwLogInfo, "");
    rtliSetLogXFinal(Filter1_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Filter1_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Filter1_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(Filter1_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(Filter1_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &Filter1_Y.Output
      };

      rtliSetLogYSignalPtrs(Filter1_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0
      };

      static RTWPreprocessingFcnPtr rt_LoggingPreprocessingFcnPtrs[] = {
        (NULL)
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "Filter1/Output" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          1,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),
          rt_LoggingPreprocessingFcnPtrs,

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(Filter1_M->rtwLogInfo, rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
    }

    rtliSetLogY(Filter1_M->rtwLogInfo, "yout");
  }

  /* states (dwork) */
  (void) memset((void *)&Filter1_DW, 0,
                sizeof(DW_Filter1_T));

  /* external inputs */
  Filter1_U.Input = 0.0;

  /* external outputs */
  Filter1_Y.Output = 0.0;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Filter1_M->rtwLogInfo, 0.0, rtmGetTFinal
    (Filter1_M), Filter1_M->Timing.stepSize0, (&rtmGetErrorStatus(Filter1_M)));

  /* InitializeConditions for Delay: '<S1>/Delay11' */
  Filter1_DW.Delay11_DSTATE = Filter1_P.Delay11_InitialCondition;

  /* InitializeConditions for Delay: '<S1>/Delay21' */
  Filter1_DW.Delay21_DSTATE = Filter1_P.Delay21_InitialCondition;

  /* InitializeConditions for Delay: '<S1>/Delay12' */
  Filter1_DW.Delay12_DSTATE = Filter1_P.Delay12_InitialCondition;

  /* InitializeConditions for Delay: '<S1>/Delay22' */
  Filter1_DW.Delay22_DSTATE = Filter1_P.Delay22_InitialCondition;

  /* InitializeConditions for Delay: '<S1>/Delay13' */
  Filter1_DW.Delay13_DSTATE = Filter1_P.Delay13_InitialCondition;

  /* InitializeConditions for Delay: '<S1>/Delay23' */
  Filter1_DW.Delay23_DSTATE = Filter1_P.Delay23_InitialCondition;
}

/* Model terminate function */
void Filter1_terminate(void)
{
  /* (no terminate code required) */
}
