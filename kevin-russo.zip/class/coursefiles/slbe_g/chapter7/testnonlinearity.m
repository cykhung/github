%% Test script to show the effect of attenuating input signal amplitude
%  to reduce nonlinear distortion.
%  Input --> [Gain] --> tanh --> [1/Gain] --> Nonlinear Output
%  Use [Gain] < 1 for attenuating input.
%
fs = 1000;
t = 0:1/fs:1-1/fs;
G1 = 0.5;
G2 = 0.1;
s = sin(2*pi*1*t);
% Compute outputs of the nonlinear distortion algorithm for gains G1 and G2
out1 = tanh(G1*s)/G1;
out2 = tanh(G2*s)/G2;
% Plot results
plot(s,'LineWidth',1.5); hold on;
plot(out1,'r','LineWidth',1.5);
plot(out2,'g','LineWidth',1.5);
axis([0 fs -1.2 1.2]); grid on; hold off;
legend('Input',['Output with gain = ',num2str(G1)],['Output with gain = ',num2str(G2)])
title('Plots showing different output nonlinearities');
% Text placement depends on the X-axis, i.e., fs
text(0.45*fs,0.4,'\leftarrow The green and blue lines are');
text(0.49*fs,0.3,'almost overlapping with each other');
%% Compute mean squared errors of the outputs compared to a sine wave with
%  same amplitude
a1 = max(out1); % Get the amplitude of out1
a2 = max(out2); % Get the amplitude of out2
s1 = a1*sin(2*pi*1*t); % Form sine wave with amplitude a1
s2 = a2*sin(2*pi*1*t); % Form sine wave with amplitude a2
e1 = sum((out1 - s1).^2); % Compute MSE when gain G1 is used
e2 = sum((out2 - s2).^2); % Compute MSE when gain G2 is used
disp(['Mean Squared Error for G1 = ',num2str(e1)]);
disp(['Mean Squared Error for G2 = ',num2str(e2)]);
