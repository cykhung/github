function y = kalman_filter_fcn(z,N0,f0,dt)
%#eml
% Kalman filter initialization
% State transition Matrix
A = [cos(2*pi*f0*dt) -sin(2*pi*f0*dt);
     sin(2*pi*f0*dt) cos(2*pi*f0*dt)];

% Measurement Matrix
H = [1 0];

% Process noise variance
Q = 0;
% Measurement noise variance
R = N0 ;

persistent x_est p_est
if isempty(x_est)
    % Estimated state
    x_est = [0; 1];
    % Estimated error covariance
    p_est = N0 * eye(2, 2);
end

    % Kalman algorithm
% Predicted state and covariance
x_prd = A * x_est;
p_prd = A * p_est * A' + Q;

% Estimation
S = H * p_prd' * H' + R;
B = H * p_prd';
klm_gain = (S \ B)';

% Estimated state and covariance
x_est = x_prd + klm_gain * (z - H * x_prd);
p_est = p_prd - klm_gain * H * p_prd;

% Compute the estimated measurements
y = H * x_est;


