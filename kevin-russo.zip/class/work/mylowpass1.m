function Hd = mylowpass1
%Design a low pass filter
%   Pass band edge = 4000 Hz
%   Stop band edge = 5000 Hz
%   Passband ripple = 0.1 dB
%   Stopband ripple = 50 dB
%   Sampling freequency = 22050 Hz

d = fdesign.lowpass('Fp,Fst,Ap,Ast', ...
    4000, 5000, 0.1, 50, 22050);
Hd = design(d, 'cheby1');
end