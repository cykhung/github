/* Include files */

#include "ceval_testbench_sfun.h"
#include "c2_ceval_testbench.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;

/* Function Declarations */
static void initialize_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);
static void initialize_params_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static void mdl_start_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);
static void mdl_terminate_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance);
static void mdl_setup_runtime_resources_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static void enable_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);
static void disable_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);
static void sf_gateway_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);
static void ext_mode_exec_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance);
static void c2_update_jit_animation_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static void c2_do_animation_call_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static void set_sim_state_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance, const mxArray *c2_st);
static void initSimStructsc2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance);
static real32_T c2_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_b_y, const char_T *c2_identifier);
static real32_T c2_b_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static uint8_T c2_c_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_b_is_active_c2_ceval_testbench, const char_T
  *c2_identifier);
static uint8_T c2_d_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_slStringInitializeDynamicBuffers
  (SFc2_ceval_testbenchInstanceStruct *chartInstance);
static void c2_chart_data_browse_helper(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, int32_T c2_ssIdNumber, const mxArray **c2_mxData, uint8_T
  *c2_isValueTooBig);
static void init_dsm_address_info(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc2_ceval_testbenchInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c2_is_active_c2_ceval_testbench = 0U;
}

static void initialize_params_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  real_T c2_dv[9];
  real_T c2_d;
  int32_T c2_i;
  sf_mex_import_named("coeffs", sf_mex_get_sfun_param(chartInstance->S, 0U, 0U),
                      c2_dv, 0, 0, 0U, 1, 0U, 2, 1, 9);
  for (c2_i = 0; c2_i < 9; c2_i++) {
    chartInstance->c2_coeffs[c2_i] = (real32_T)c2_dv[c2_i];
  }

  sf_mex_import_named("ntaps", sf_mex_get_sfun_param(chartInstance->S, 1U, 0U),
                      &c2_d, 0, 0, 0U, 0, 0U, 0);
  chartInstance->c2_ntaps = c2_d;
}

static void mdl_start_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void mdl_terminate_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  static const uint32_T c2_decisionTxtEndIdx = 0U;
  static const uint32_T c2_decisionTxtStartIdx = 0U;
  setDebuggerFlag(chartInstance->S, true);
  setDataBrowseFcn(chartInstance->S, (void *)&c2_chart_data_browse_helper);
  chartInstance->c2_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c2_RuntimeVar,
    &chartInstance->c2_IsDebuggerActive,
    &chartInstance->c2_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c2_mlFcnLineNumber, &chartInstance->c2_IsHeatMapPresent, 0);
  sim_mode_is_external(chartInstance->S);
  covrtCreateStateflowInstanceData(chartInstance->c2_covrtInstance, 1U, 0U, 1U,
    8U);
  covrtChartInitFcn(chartInstance->c2_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c2_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c2_decisionTxtStartIdx, &c2_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c2_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c2_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c2_covrtInstance, 4U, 0U, 0U,
                     "eML_blk_kernel", 0, -1, 214);
}

static void mdl_cleanup_runtime_resources_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c2_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c2_covrtInstance);
}

static void enable_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  real_T c2_b_ntaps;
  real32_T c2_b_in;
  real32_T c2_b_y;
  chartInstance->c2_JITTransitionAnimation[0] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 0U, (real_T)
                    *chartInstance->c2_in);
  chartInstance->c2_sfEvent = CALL_EVENT;
  c2_b_in = *chartInstance->c2_in;
  c2_b_ntaps = chartInstance->c2_ntaps;
  covrtEmlFcnEval(chartInstance->c2_covrtInstance, 4U, 0, 0);
  c2_b_y = fir_filt(c2_b_in, c2_b_ntaps, &chartInstance->c2_coeffs[0]);
  *chartInstance->c2_y = c2_b_y;
  c2_do_animation_call_c2_ceval_testbench(chartInstance);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 1U, (real_T)
                    *chartInstance->c2_y);
}

static void ext_mode_exec_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance)
{
  (void)chartInstance;
}

static void c2_update_jit_animation_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c2_do_animation_call_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static const mxArray *get_sim_state_c2_ceval_testbench
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_st;
  c2_st = NULL;
  c2_st = NULL;
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_createcellmatrix(2, 1), false);
  c2_c_y = NULL;
  sf_mex_assign(&c2_c_y, sf_mex_create("y", chartInstance->c2_y, 1, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_b_y, 0, c2_c_y);
  c2_d_y = NULL;
  sf_mex_assign(&c2_d_y, sf_mex_create("y",
    &chartInstance->c2_is_active_c2_ceval_testbench, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c2_b_y, 1, c2_d_y);
  sf_mex_assign(&c2_st, c2_b_y, false);
  return c2_st;
}

static void set_sim_state_c2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance, const mxArray *c2_st)
{
  const mxArray *c2_u;
  chartInstance->c2_doneDoubleBufferReInit = true;
  c2_u = sf_mex_dup(c2_st);
  *chartInstance->c2_y = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c2_u, 0)), "y");
  chartInstance->c2_is_active_c2_ceval_testbench = c2_c_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 1)),
     "is_active_c2_ceval_testbench");
  sf_mex_destroy(&c2_u);
  sf_mex_destroy(&c2_st);
}

static void initSimStructsc2_ceval_testbench(SFc2_ceval_testbenchInstanceStruct *
  chartInstance)
{
  (void)chartInstance;
}

const mxArray *sf_c2_ceval_testbench_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  sf_mex_assign(&c2_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c2_nameCaptureInfo;
}

static real32_T c2_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_b_y, const char_T *c2_identifier)
{
  emlrtMsgIdentifier c2_thisId;
  real32_T c2_c_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_c_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_y), &c2_thisId);
  sf_mex_destroy(&c2_b_y);
  return c2_c_y;
}

static real32_T c2_b_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real32_T c2_b_y;
  real32_T c2_f;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_f, 0, 1, 0U, 0, 0U, 0);
  c2_b_y = c2_f;
  sf_mex_destroy(&c2_u);
  return c2_b_y;
}

static uint8_T c2_c_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_b_is_active_c2_ceval_testbench, const char_T
  *c2_identifier)
{
  emlrtMsgIdentifier c2_thisId;
  uint8_T c2_b_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_b_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_is_active_c2_ceval_testbench), &c2_thisId);
  sf_mex_destroy(&c2_b_is_active_c2_ceval_testbench);
  return c2_b_y;
}

static uint8_T c2_d_emlrt_marshallIn(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_b_u;
  uint8_T c2_b_y;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_b_u, 1, 3, 0U, 0, 0U, 0);
  c2_b_y = c2_b_u;
  sf_mex_destroy(&c2_u);
  return c2_b_y;
}

static void c2_slStringInitializeDynamicBuffers
  (SFc2_ceval_testbenchInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c2_chart_data_browse_helper(SFc2_ceval_testbenchInstanceStruct
  *chartInstance, int32_T c2_ssIdNumber, const mxArray **c2_mxData, uint8_T
  *c2_isValueTooBig)
{
  real32_T c2_f;
  real32_T c2_f1;
  *c2_mxData = NULL;
  *c2_mxData = NULL;
  *c2_isValueTooBig = 0U;
  switch (c2_ssIdNumber) {
   case 4U:
    c2_f = *chartInstance->c2_in;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_f, 1, 0U, 0U, 0U, 0),
                  false);
    break;

   case 5U:
    c2_f1 = *chartInstance->c2_y;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_f1, 1, 0U, 0U, 0U, 0),
                  false);
    break;

   case 6U:
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", chartInstance->c2_coeffs, 1,
      0U, 1U, 0U, 2, 1, 9), false);
    break;

   case 7U:
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &chartInstance->c2_ntaps, 0,
      0U, 0U, 0U, 0), false);
    break;
  }
}

static void init_dsm_address_info(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc2_ceval_testbenchInstanceStruct
  *chartInstance)
{
  chartInstance->c2_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c2_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c2_in = (real32_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c2_y = (real32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c2_ceval_testbench_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(163917536U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3252793613U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(712965653U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2540538565U);
}

mxArray *sf_c2_ceval_testbench_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c2_ceval_testbench_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("fir_filt");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c2_ceval_testbench_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = sf_mex_decode(
    "eNpjYPT0ZQACPiCWYGRgYAPSHEDMyAABrEh8RiRxkPoXDPjVM6Gpd0BSz4JFPR+SegEoPzElJTi"
    "/tCg51S0zJ7UYIlbAQJo7CdnLg2YviJ+WWRSflplTklqklwwSBwDIQA4H"
    );
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c2_ceval_testbench(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiD+wcjAwAakOYCYiQECWKF8RqgYI1ycBS6uAMQllQWpIPHiomTPFCCdl5gL5ie"
    "WVnjmpeWDzbdgQJjPhsV8RiTzOaHiEPDBnjL9Ig4g/QZI+lkI6BcAsiqh4QILH/LtV3CgTD/E/g"
    "AC7pdBcT+En1kcn5hcklmWGp9sFJ+cWpaYE1+SWlySlJqXnMGA5D8AUwQa9A=="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_ceval_testbench_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sIpEYwX1Xd7gAnvR6ExYEHB";
}

static void sf_opaque_initialize_c2_ceval_testbench(void *chartInstanceVar)
{
  initialize_params_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
  initialize_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c2_ceval_testbench(void *chartInstanceVar)
{
  enable_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c2_ceval_testbench(void *chartInstanceVar)
{
  disable_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c2_ceval_testbench(void *chartInstanceVar)
{
  sf_gateway_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c2_ceval_testbench(SimStruct* S)
{
  return get_sim_state_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c2_ceval_testbench(SimStruct* S, const
  mxArray *st)
{
  set_sim_state_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_cleanup_runtime_resources_c2_ceval_testbench(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_ceval_testbenchInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_ceval_testbench_optimization_info();
    }

    mdl_cleanup_runtime_resources_c2_ceval_testbench
      ((SFc2_ceval_testbenchInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c2_ceval_testbench(void *chartInstanceVar)
{
  mdl_start_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_mdl_terminate_c2_ceval_testbench(void *chartInstanceVar)
{
  mdl_terminate_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_ceval_testbench(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
      sf_get_chart_instance_ptr(S));
    initSimStructsc2_ceval_testbench((SFc2_ceval_testbenchInstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c2_ceval_testbench_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [21] = {
    "eNrtWN2O20QUdqKlompZ7QUSqrQSveQGqV3EzwWC3SROG2mXjers0nKzTOyTeJTxjDs/TsIVD4H",
    "EK3DJg/AAiKfgspecsb1p5A2JJxFLi7CUOGPPN985Z87fxGv0zjy89u3XA8+7g7d38dP0iuudct",
    "xY+hTP97wvy/HxPc/jJukTSRLluV+cJPAMlGBGU8F7fCTqYykfgQQe4gKpkNqJV9HEMMonXcNDy",
    "6y+jWkYB7EwLGrhgiQ652z+d7yp0X1k7FAJoe4CRDqWwozjLiPj9VaQetqOIZwokzjbSoEOTGpV",
    "VWeGaZoy8GcQ9rjSBK2gNugbaKKhrWduRrb6quAaLZKUUcLr2zomKoAUvUPDRRrh97nRaL1a2DA",
    "mUrcgJhmoUzrJ2QWHWuxU4ewh5UQLSQnzE9a2q9XUt89QxzMRAXPdI9S3JYFMUkG5dgyIoIt29j",
    "kZMujA0IwdeQN4aWw0XFKYgnTb31FbZCDJGM65m8z5Hvmz3CkXsVQTq2kCl0SehOi7CiK3vIFBp",
    "wKC7ggDXMYJC7mJe2ogaYa+4cZrkp4N/61ynUkK71dbYXNePwNnv1rwdkPeJowpN+xApKeQAcv5",
    "O0STLbAFvwNYKRoNBHqHzTaOGctwipFQYtuCR7S+V2YVVF7YvsEiVQNOExsGEKGZF6IvFtoUR0Z",
    "pkbQx5XROT2vy3cT2uAY5IiHUrjGSUAUocO5XjrwRVTaQEI1W0rmWtVcoYnArqKdGhnemQk7Qxq",
    "7F7LWtbCS4oSEaY2LWkCc5H737kjBTU+ZEjTF+0D0uFGZZN17E2vjZChySMIbIVk7K4AzzLC5Qd",
    "4uVLfknqG1G9bwDKpQ0rRtJBhM6Fl1rpcE8hQs+4WLKu1IkQdl5rfErAMwaRHLKxy0s4XLeReHr",
    "SS3h5SDP7q5NjrUz0YwMrW88AY7V0OpquwYSYlT5PBQRCrQLNqA/YBPDFVUaC/W8KPVR3n8/8l7",
    "33/dr9N/Nsm9fh/Nu4Iprf+n+0RK+sYLXW7pX+e4218vZxF+NEne8hHuvwrNXwdl5B/b9T4ffz8",
    "2jPx78ePnz7LdfzS78vzTdzjf75fjwusdZZNTsRtKxc58uybW3Yv0PltY/KMeql/ovps8fP48+H",
    "5/w7Nln/uyF/7SVr/eqsV7eZkXe6+cPbV+FAZfHrwx7UXnGsmNiit7frv/Fkrx3Ntjj7pI/ed6f",
    "X++Gf/+4uo97G/AH+Gte8dvt+R8e74Yv+Psb5D+s7Pdh3mdfEZtN4So8ugohI+xKg9JDzAVxNS6",
    "39XNXnHfLuLdFzv/t8s/rV6fO3TbOu2Xcrvq51u+3ff66uuFV5h+8wXqsy/cufdybptfvnluf9W",
    "E5/mpx5m/HlEUrTh3lazwYjFa9/Y/49ytH+133lb61X/nn8HefnHDC5njMKI5x5eO+tP/xLV5JI",
    "Gr1We7fqCfeinPCqr7qfiW+7XhKeSSm6uPHR58e7VKf/gKUwgx1",
    ""
  };

  static char newstr [1477] = "";
  newstr[0] = '\0';
  for (i = 0; i < 21; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c2_ceval_testbench(SimStruct *S)
{
  const char* newstr = sf_c2_ceval_testbench_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(1612485637U));
  ssSetChecksum1(S,(3660608889U));
  ssSetChecksum2(S,(2539028505U));
  ssSetChecksum3(S,(1974520952U));
}

static void mdlRTW_c2_ceval_testbench(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c2_ceval_testbench(SimStruct *S)
{
  SFc2_ceval_testbenchInstanceStruct *chartInstance;
  chartInstance = (SFc2_ceval_testbenchInstanceStruct *)utMalloc(sizeof
    (SFc2_ceval_testbenchInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc2_ceval_testbenchInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c2_ceval_testbench;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c2_ceval_testbench;
  chartInstance->chartInfo.mdlStart = sf_opaque_mdl_start_c2_ceval_testbench;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c2_ceval_testbench;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c2_ceval_testbench;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c2_ceval_testbench;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c2_ceval_testbench;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c2_ceval_testbench;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c2_ceval_testbench;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c2_ceval_testbench;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_ceval_testbench;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c2_ceval_testbench;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->chartInfo.chartStateSetterFcn = NULL;
  chartInstance->chartInfo.chartStateGetterFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c2_JITStateAnimation,
    chartInstance->c2_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c2_ceval_testbench(chartInstance);
}

void c2_ceval_testbench_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c2_ceval_testbench(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_ceval_testbench(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_ceval_testbench(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_ceval_testbench_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
