%% Setup PWM

%% Source
source = struct;
source.fs = 250e3;
source.f1 = source.fs/100;
source.f2 = source.fs/70;
source.a1 = 0.3;
source.a2 = 0.15;
source.offset = 0.35;
source.variance = 0.001;

%% PWM
pwm = struct;
pwm.TimePerCount = 10e-9;
pwm.Period = 4E-6;
pwm.CounterMax = 200;
pwm.CountPerPeriod = 400;

%% PWM_FSM
sys_clk = 1/pwm.TimePerCount;
pwm_freq = 1/pwm.Period;
bits_resolution = 10;
phases = 3;
period = sys_clk/pwm_freq;

%% Filter
load('FilterCoeffs.mat')