function status = slbegselftest(varargin)

%%
%       SYNTAX: status = slbegselftest;
%               status = slbegselftest(machineType);
%               status = slbegselftest(machineType, useCkhSlxSim);
%
%  DESCRIPTION: Go through all MATLAB and Simulink files in the SLBE-G course.
%
%               The function assumes that user has already added SLBE-G course
%               folders into MATLAB search path.
%
%        INPUT: - machineType (string)
%                   Machine type. Valid types are:
%                       'trainer' - Trainer PC. 
%                       'student' - Student PC. Default.
%
%               - useCkhSlxSim (logical)
%                   Use Kevin Hung version of the MATLAB function sim(). 
%                   Default = 0. Valid values are:
%                       0 - Do not use Kevin version. Use built-in MATLAB sim().
%                       1 - Use Kevin version.
%
%       OUTPUT: - status (logical)
%                   Status. Valid values are:
%                       0 - Fail.
%                       1 - Pass.


%% Assign input arguments.
machineType = 'student';
useCkhSlxSim   = 0;
switch nargin
case 0
    % Do nothing.
case 1
    machineType = varargin{1};
case 2
    [machineType, useCkhSlxSim] = deal(varargin{:});
otherwise
    error('Invalid number of input arguments.');
end


%% Initialize status.
status = 1;


%% Run a subset of files. Student machine only.
if strcmp(machineType, 'student')
    filenames = { ...
        'dspddc.slx',               ...     % Chapter 2
        'c2f.slx',                  ...     % Chapter 3
        'sample_time.slx',          ...     % Chapter 4
        'simpleComparisons.slx',    ...     % Chapter 5
        'agc1_envelope.slx',        ...     % Chapter 6
        'simplesub.slx',            ...     % Chapter 9
        'agc1_enabled.slx',         ...     % Chapter 10
        'spectscope_start.slx',     ...     % Chapter 11
        'sigID.slx',                ...     % Chapter 12
        'setspeed.slx',             ...     % Exercise. Chapter 3.
        'lopass.slx',               ...     % Exercise. Chapter 4.
        'synth.slx',                ...     % Exercise. Chapter 5.
        'DRCPart1dB.slx',           ...     % Exercise. Chapter 6.
        'Sigmadelta_ex_soln.slx',   ...     % Exercise. Chapter 7.
        'DRCMask.slx',              ...     % Exercise. Chapter 9.
        'Engine_power_soln.slx',    ...     % Exercise. Chapter 10.
        'powerspect.slx',           ...     % Exercise. Chapter 11.
        'B5ViewSpectrum.slx',       ...     % Exercise. Chapter 12.
        'SigmadeltaMR_ex_soln.slx', ...     % Exercise. Chapter 13.
        'noisy_sin.slx',            ...     % Exercise. Chapter 14.
        'CommSystem.slx',           ...     % Exercise. Chapter 15.
        'Sigmadelta_command.slx',   ...     % Exercise. Chapter 16.
        };
%         'adc_basic.slx',            ...     % Chapter 7
%         'solverNoStates.slx',       ...     % Chapter 8
%         'indepRates.slx',           ...     % Chapter 13
%         'agc_eml.slx',              ...     % Chapter 14
%         'adcRef.slx',               ...     % Chapter 15
%         'adc1_cmd.slx',             ...     % Chapter 16
%         'local_mins.slx',           ...     % Appendix A.
%         'fixedPointRule.slx',       ...     % Appendix C.
    for n = 1:length(filenames)
        status = status & runfile(filenames{n}, useCkhSlxSim);
    end
end


%% Run all *.slx/*.mdl/*.m files in each chapter. Trainer machine only.
if strcmp(machineType, 'trainer')
    filenames = getAllFiles;
    for n = 1:length(filenames)
        status = status & runfile(filenames{n}, useCkhSlxSim);
    end
end


%% Test sinequanterror.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    fprintf('Running %s ...\n', which('sinequanterror'));
    slbegSelftestEnableWarning;
    sinequanterror(8);
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    slbegSelftestDisableWarning;
end


%% Test amp2dbm.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    fprintf('Running %s ...\n', which('amp2dbm'));
    slbegSelftestEnableWarning;
    amp2dbm([0.1 0.4 1 0.5], 2);
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    slbegSelftestDisableWarning;
end


%% Test adc1_paramSweepFcn.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    fprintf('Running %s ...\n', which('adc1_paramSweepFcn'));
    bdclose all
    close all
    slbegSelftestEnableWarning;
    adc1_paramSweepFcn(-3, 3, 10);
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    slbegSelftestDisableWarning;
    bdclose all
    close all
end


%% Test exploreFix.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    fprintf('Running %s ...\n', which('exploreFix'));
    bdclose all
    close all
    slbegSelftestEnableWarning;
    exploreFix;
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    slbegSelftestDisableWarning;
    bdclose all
    close all
end


% %% Test fpt_script.m. Trainer machine only.     Crash !!!!!!!!!!
% if strcmp(machineType, 'trainer')
%     fprintf('Running %s ...\n', which('fpt_script'));
%     warnStruct = warning;
%     warning('off', 'SimulinkFixedPoint:util:fxpParameterPrecisionLoss');
%     warning('off', 'SimulinkFixedPoint:util:Overflowoccurred');
%     bdclose all
%     close all
%     slbegSelftestEnableWarning;
%     fpt_script;
%     c = slsvWarningListener('get');
%     if ~isempty(c)
%         status = 0;
%     end
%     slbegSelftestDisableWarning;
%     warning(warnStruct);
%     bdclose all
%     close all
%     Simulink.sdi.close;
%     delete('.\firfilter_double2_fxpt1.slx');
%     fprintf('Delete file .\\firfilter_double2_fxpt1.slx\n');
% end


%% Test fpt_multiple_script.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    fprintf('Running %s ...\n', which('fpt_multiple_script'));
    warnStruct = warning;
    warning('off', 'SimulinkFixedPoint:util:fxpParameterPrecisionLoss');
    warning('off', 'SimulinkFixedPoint:util:Overflowoccurred');
    bdclose all
    close all
    slbegSelftestEnableWarning;
    fpt_multiple_script;
    % if ~isempty(lastwarn)
    %     status = 0;
    % end
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    slbegSelftestDisableWarning;
    warning(warnStruct);
    bdclose all
    close all
    delete('.\firfilter_double2_fxpt2.slx');
    fprintf('Delete file .\\firfilter_double2_fxpt2.slx\n');
end


%% Remove folder "slprj".
folder = fullfile(pwd, 'slprj');
if exist(folder, 'dir') ~= 0
    fprintf('Remove folder "%s".\n', folder);
    rmdir(folder, 's');
end


%% Delete files (*.mexw64 *.exp *.lib).
delete *.mexw64 *.exp *.lib *.slxc
fprintf('Delete files *.mexw64 *.exp *.lib\n');


end



function status = runfile(filename, useCkhSlxSim)


%% Initialize status.
status = 1;


%% Skip these slx files in case of using CkhSlxSim.m. Early exit.
skipFilenames = {'c2f_callback.slx', 'c2f_twochannel.slx', ...
    'subsystemDecisions.slx', 'agc3.slx', 'adc1_ads6229.slx', ...
    'fixedvsvari.slx', 'engine_control.slx', 'engine_control_fxp.slx'};
if useCkhSlxSim == 1
    if ismember(filename, skipFilenames)
        fprintf('Skipping %s ...\n', which(filename));
        return;
    end
end


%% Set stopTime.
switch filename
case {'adcRef.slx', 'myAdcRef.slx', 'adcRef2.slx'}
    stopTime = '0.01';    
case {'adc1.slx', 'adc_interleaved.slx', 'adc1_sub_start.slx'}
    stopTime = '1e-3';
case {'dspsdadc.slx', 'AcousticNoiseCanceler.slx', ...
        'sldemo_mdlref_depgraph.slx'}
    stopTime = '1';
case {'simple_filt_frames.slx', 'simple_filt_multichannel.slx'}
    stopTime = '5';
case {'simple_filt.slx', 'simple_filt_probed.slx', 'freqrespLTI1.slx' ...
        'simple_filt_viewer_frame.slx', 'simple_filt_framescope.slx', ...
        'spectscope.slx', 'oversampled.slx', 'oversampledFs.slx', ...
        'resampleSine.slx', 'resampleSineDigfilt.slx', ...
        'resampleSineFIR.slx', 'resampleSineFinal.slx', 'setspeed.slx', ...
        'stopfilt.slx', 'synth.slx', 'synthws.slx', 'AudioEq.slx', ...
        'dat2CDfloat.slx', 'dat2CDfix.slx', 'synthvec2.slx'}
    stopTime = '10';
otherwise
    stopTime = '';
end


%% Temporarily turn off certain warning messages.
warnStruct = warning;
switch filename
case {'c2f.slx', ...
        'c2f_blockparams.slx', 'c2f_blocks.slx', 'c2f_workspace.slx', ...
        'c2f_matFile.slx', 'c2f_callback.slx', 'c2f_twochannel.slx', ...
        'simpleLogic.slx', ...
        'simpleVector.slx', 'mars_para_matlab.slx', ...
        'solverNoStates.slx', 'enabledGain.slx', 'testRootEnable.slx', ...
        'solverContStates.slx', 'simplesub.slx', 'dynamic_mask_example.slx'}
    flag = 1;
case {'simple_filt_multichannel.slx'}
    flag = 2;
case {'agc1.slx', 'agc1_2.slx'}
    flag = 3;
case {'adc1.slx'}
    flag = 4;
    if useCkhSlxSim == 1
        flag = [flag, 8];
    end
case {'algLoopRemodel.slx'}
    flag = [1 5];
case {'simpleAlgLoop.slx'}
    flag = 5;
case {'adc_lib2.slx'}
    flag = 6;
    if useCkhSlxSim == 1
        flag = [flag, 8];
    end
case {'virtualOptim.slx'}
    flag = 7;
case {'simpleComparisons.slx', 'simpleSwitch.slx', 'mars_para_g.slx', ...
        'simpleStiffSystem.slx'}
    flag = 1;
    if useCkhSlxSim == 1
        flag = [flag, 8];
    end
case {'multiportSwitchDecisions.slx', 'adc_basic.slx', ...
        'flamepropagation.slx', 'adc_interleaved.slx', ...
        'adc_nonlinconfig.slx', 'adc1_sub.slx', 'adc1_sub_start.slx', ...
        'adc1_sub2.slx', 'adc1_sub2_masked.slx', 'enabled.slx', ...
        'adc1_sub2_masked_checkboxes.slx', 'zc_detection.slx', ...
        'adc1_sub2_masked_checkboxes2.slx', 'adc1_sub2_masked_init.slx', ...
        'adc1_sub2_masked2.slx', 'solverMultipleRate.slx', ...
        'triggered_and_enabled.slx', 'adc_interleaved_start.slx', ...
        'adcInterleaved_modref2.slx', 'myAdc_modref.slx', ...
        'myAdc_modref2.slx', 'adc1_cmd.slx', 'controller_flt.slx', ...
        'controller_fxp.slx', 'DRCPart2_sub.slx', 'CommSystem.slx', ...
        'CommSystem_soln.slx', 'mars_para.slx', 'sol_mars_para.slx', ...
        'checkFreqRespAnalog.slx'}
    if useCkhSlxSim == 1
        flag = 8;
    else
        flag = [];
    end
case {'notchfilt1_fix.slx', 'notchfilt1_fixcomp.slx'}
    flag = [9, 15];
case {'ctr_poor_scale.slx'}
    if useCkhSlxSim == 1
        flag = [8, 10];
    else
        flag = 10;
    end
case {'engine_control.slx', 'engine_control_fxp.slx'}
    flag = [11 12];
case 'dat2CDfloat.slx'
    flag = 13;
case 'dat2CDfix.slx'
    flag = [10 13 14];
case 'fixedPointRule.slx'
    flag = [7, 13];
case 'scaling_inheritance.slx'
    flag = 7;
case 'firfilter_fix8bits2.slx'
    flag = 13;
case {'notchfilt2.slx', 'notchfilt3.slx', 'notchfilt1_double.slx'}
    flag = 15;
otherwise
    flag = [];
end
if ~isempty(flag)
    if any(flag == 1)
        warning('off', 'Simulink:Engine:UsingDefaultMaxStepSize');
    end
    if any(flag == 2)
        warning('off', 'Simulink:blocks:ExceedDisplayBlockLimit');
    end
    if any(flag == 3)
        warning('off', 'Simulink:blocks:DivideByZero');
    end
    if any(flag == 4)
        warning('off', 'Simulink:Engine:VerySmallMaxStepSize');
    end
    if any(flag == 5)
        warning('off', 'Simulink:Engine:WarnAlgLoopsFound');
    end
    if any(flag == 6)
        warning('off', 'Simulink:blocks:TDelayOverMaximumDelay');
    end
    if any(flag == 7)
        warning('off', 'Simulink:SampleTime:FixedStepSizeHeuristicWarn');
    end
    if any(flag == 8)
        warning('off', 'ckhsim:SignalNotPeriodicSampling');
    end
    if any(flag == 9)
        warning('off', 'SimulinkFixedPoint:util:fxpParameterPrecisionLoss');
    end
    if any(flag == 10)
        warning('off', 'SimulinkFixedPoint:util:Overflowoccurred');
    end
    if any(flag == 11)
        str = ['Simulink:blocks:BlockWithExplicitICFeedingEmptyOutport', ...
            'ConsistentOutportInit'];
        warning('off', str);
    end
    if any(flag == 12)
        warning('off', ...
            'Simulink:blocks:MultipleWarningsBlkWithExpICFeedingEmptyOutport');
    end
    if any(flag == 13)
        warning('off', 'SimulinkFixedPoint:util:fxpParameterPrecisionLoss');
                       
    end
    if any(flag == 14)
        warning('off', 'SimulinkFixedPoint:util:Saturationoccurred');
    end
    if any(flag == 15)
        warning('off', 'Simulink:Engine:StopTimeCorrected');
    end
end


%% Run file.
fprintf('Running %s ...\n', which(filename));
slbegSelftestEnableWarning;
evalin('base', 'clear')     % Clear base workspace.
close all
switch filename
case 'c2f.slx'
    evalin('base', 't = (1:365)'';');
    evalin('base', 'load(''bangaloreTempsC.mat'');');
case {'dat2CDfloat.slx', 'dat2CDfix.slx'}
    evalin('base', 'load(''dat2CDfilt.mat'');');
case 'hilo2.slx'
    evalin('base', 't = (0:1/2e3:4)'';');
    evalin('base', 's1 = 0.9*sin(2*pi*50*t);');
    evalin('base', 's2 = 0.05*sin(2*pi*950*t);');
case 'synthvec2.slx'
    evalin('base', 'u = repelem(0:7, 8000);');
case {'powerspect.slx', 'powerspect2.slx'}
    evalin('base', 'load(''mtlb.mat'');');        
end
[~, ~, ext] = fileparts(filename);
switch ext
case {'.mdl', '.slx'}
    open_system(filename);
    if ~isempty(stopTime)
        set_param(bdroot, 'StopTime', stopTime);
    end    
    if useCkhSlxSim == 1
        setmodel(bdroot);
        evalin('base', 'simout = ckhsim(bdroot);');
    else
        evalin('base', 'sim(bdroot);');
    end
    % close_system(bdroot);
    % bdclose(bdroot); Cannot close testRootEnable.slx.
    bdclose all
case {'.m'}
    % run(filename);
    evalin('base', strrep(filename, '.m', ''));
otherwise
    error('Unsupported file extension.');
end
c = slsvWarningListener('get');
if ~isempty(c)
    status = 0;
end
close all
evalin('base', 'clear')     % Clear base workspace.
slbegSelftestDisableWarning;


%% Delete simulation output file.
switch filename
case 'c2f_matFile.slx'
    matfilename = fullfile(pwd, 'fahrenheit.mat');
    if exist(matfilename, 'file') == 0
        error('Simulation output file not found.');
    end
    fprintf('Remove file "%s".\n', matfilename);
    delete(matfilename);
end


%% Restore saved warning state.
warning(warnStruct);


end



function slbegSelftestEnableWarning

slsvWarningListener('enable');
slsvWarningListener('skip_disabled_warnings', true);
slsvWarningListener('clear');

end



function slbegSelftestDisableWarning

slsvWarningListener('disable');

end



function filenames = getAllFiles
 
%% Initialize filenames.
filenames = {};

%% files\chapter2.
filenames{end+1} = 'dspddc.slx';
% %filenames{end+1} = 'dsplpc.mdl';
filenames{end+1} = 'dspsdadc.slx';
filenames{end+1} = 'AcousticNoiseCanceler.slx';

%% files\chapter3.
filenames{end+1} = 'c2f.slx';
filenames{end+1} = 'c2f_blocks.slx';
filenames{end+1} = 'c2f_workspace.slx';
filenames{end+1} = 'c2f_blockparams.slx';
filenames{end+1} = 'c2f_callback.slx';
filenames{end+1} = 'c2f_matFile.slx';
filenames{end+1} = 'c2f_twochannel.slx';

%% files\chapter4.
filenames{end+1} = 'sample_time.slx';
filenames{end+1} = 'simple_filt.slx';
filenames{end+1} = 'simple_filt_probed.slx';
filenames{end+1} = 'simple_filt_viewer_frame.slx';
filenames{end+1} = 'bufdelay.slx';
filenames{end+1} = 'simple_filt_framescope.slx';
filenames{end+1} = 'timescopetest.slx';
filenames{end+1} = 'simple_filt_frames.slx';
filenames{end+1} = 'simple_filt_multichannel.slx';

%% files\chapter5.
filenames{end+1} = 'simpleComparisons.slx';
filenames{end+1} = 'simpleLogic.slx';
filenames{end+1} = 'simpleSwitch.slx';
filenames{end+1} = 'multiportSwitchDecisions.slx';
filenames{end+1} = 'mars_para_g.slx';
filenames{end+1} = 'mars_para_matlab.slx';
filenames{end+1} = 'simpleVector.slx';

%% files\chapter6.
filenames{end+1} = 'agc1_envelope.slx';
filenames{end+1} = 'agc1_envelope2.slx';
filenames{end+1} = 'agc1.slx';
filenames{end+1} = 'agc1_2.slx';
filenames{end+1} = 'agc1_nowarning.slx';
filenames{end+1} = 'agc2.slx';
filenames{end+1} = 'agc2_alternative.slx';
filenames{end+1} = 'agc3.slx';

% %% files\chapter7.
% filenames{end+1} = 'adc_basic.slx';
% filenames{end+1} = 'adc1.slx';
% filenames{end+1} = 'adc1_ads6229.slx';
% filenames{end+1} = 'testnonlinearity.m';
% 
% %% files\chapter8.
% filenames{end+1} = 'solverNoStates.slx';
% filenames{end+1} = 'solverDiscStates.slx';
% filenames{end+1} = 'solverMultipleRate.slx';
% filenames{end+1} = 'fixedvsvari.slx';
% filenames{end+1} = 'solverContStates.slx';
% filenames{end+1} = 'flamepropagation.slx';
% filenames{end+1} = 'simpleStiffSystem.slx';
% filenames{end+1} = 'zc_detection.slx';
% filenames{end+1} = 'simpleAlgLoop.slx';
% filenames{end+1} = 'algLoopRemodel.slx';

%% files\chapter9.
filenames{end+1} = 'simplesub.slx';
filenames{end+1} = 'adc1_sub.slx';
filenames{end+1} = 'adc1_sub2.slx';
filenames{end+1} = 'virtualVsAtomic.slx';
filenames{end+1} = 'adc1_sub2_masked.slx';
filenames{end+1} = 'adc_interleaved.slx';
filenames{end+1} = 'adc1_sub2_masked_checkboxes.slx';
filenames{end+1} = 'adc1_sub2_masked_checkboxes2.slx';
filenames{end+1} = 'adc_lib2.slx';
filenames{end+1} = 'adc_nonlinconfig.slx';
filenames{end+1} = 'adc_power_inl.slx';
filenames{end+1} = 'adc1_sub_start.slx';
filenames{end+1} = 'adc1_sub2_masked_init.slx';
filenames{end+1} = 'adc1_sub2_masked2.slx';
filenames{end+1} = 'atomicVsVirtual.slx';
filenames{end+1} = 'dynamic_mask_example.slx';
filenames{end+1} = 'dynamic_mask_example2.slx';
filenames{end+1} = 'popup_mask_example.slx';
filenames{end+1} = 'virtualOptim.slx';

%% files\chapter10.
filenames{end+1} = 'agc1_enabled.slx';
filenames{end+1} = 'agc1_sub.slx';
filenames{end+1} = 'enabled.slx';
filenames{end+1} = 'enabledGain.slx';
filenames{end+1} = 'testRootEnable.slx';
filenames{end+1} = 'triggered.slx';
filenames{end+1} = 'triggered_and_enabled.slx';
filenames{end+1} = 'subsystemDecisions.slx';

%% files\chapter11.
filenames{end+1} = 'spectscope_start.slx';
filenames{end+1} = 'motorspect.slx';
filenames{end+1} = 'simple_classifier.slx';
filenames{end+1} = 'simple_classifier_masked.slx';
filenames{end+1} = 'freqrespLTI1.slx';
filenames{end+1} = 'freqrespLTI2.slx';
filenames{end+1} = 'spectanal.m';
filenames{end+1} = 'spectscope.slx';

%% files\chapter12.
filenames{end+1} = 'sigID.slx';
filenames{end+1} = 'toneremove1.slx';
filenames{end+1} = 'mynotch.m';
filenames{end+1} = 'toneremove2.slx';
filenames{end+1} = 'notchfilt2.slx';
filenames{end+1} = 'notchfilt3.slx';
filenames{end+1} = 'colornoise.slx';
filenames{end+1} = 'lowpass4.slx';
filenames{end+1} = 'notchfilt1_double.slx';
filenames{end+1} = 'notchfilt1_fix.slx';
filenames{end+1} = 'notchfilt1_fixcomp.slx';
filenames{end+1} = 'mylowpass.m';
filenames{end+1} = 'notch_biquad.slx';

% %% files\chapter13.
% filenames{end+1} = 'indepRates.slx';
% filenames{end+1} = 'derivedRates.slx';
% filenames{end+1} = 'multiModes.slx';
% filenames{end+1} = 'multiModesFrame.slx';
% filenames{end+1} = 'oversampled.slx';
% filenames{end+1} = 'oversampledFs.slx';
% filenames{end+1} = 'resampleSine.slx';
% filenames{end+1} = 'resampleSineDigfilt.slx';
% filenames{end+1} = 'resampleSineFIR.slx';
% filenames{end+1} = 'resampleSineFinal.slx';
% filenames{end+1} = 'dat2CDfloat.slx';
% filenames{end+1} = 'dat2CDfix.slx';
% % filenames{end+1} = 'dat2CDtb.slx';        % Not meant to run as is.
% % filenames{end+1} = 'dat2CDRate.slx';      % Not meant to run as is.
% 
% %% files\chapter14.
% filenames{end+1} = 'agc_eml.slx';
% filenames{end+1} = 'agc_eml2.slx';
% filenames{end+1} = 'agc_eml_envelope.slx';
% filenames{end+1} = 'ceval_test.slx';
% filenames{end+1} = 'ceval_dynamicFir.slx';
% filenames{end+1} = 'ceval_test_masked.slx';
% 
% %% files\chapter15.
% filenames{end+1} = 'adcRef.slx';
% filenames{end+1} = 'myAdcRef.slx';
% filenames{end+1} = 'adc_interleaved_start.slx';
% filenames{end+1} = 'myAdc_modref.slx';
% filenames{end+1} = 'adcInterleaved_modref2.slx';
% filenames{end+1} = 'adcRef2.slx';
% filenames{end+1} = 'myAdc_modref2.slx';
% % filenames{end+1} = 'sldemo_mdlref_depgraph.slx';
%  
% %% files\chapter16.
% filenames{end+1} = 'adc1_cmd.slx';
% filenames{end+1} = 'c2f_cmd.slx';
% filenames{end+1} = 'c2f_sim.m';
% filenames{end+1} = 'agc1_cmd.slx';
% filenames{end+1} = 'adc1_testscript.m';
% filenames{end+1} = 'constructExample.m';
% 
% %% files\appendix_debug.
% filenames{end+1} = 'local_mins.slx';
% 
% %% files\appendix_fixedpt.
% % filenames{end+1} = 'prec_range.slx';
% % filenames{end+1} = 'fltpt_filter.slx';
% % filenames{end+1} = 'fixpt_filter.slx';
% % filenames{end+1} = 'scaling_inheritance.slx';
% % filenames{end+1} = 'controller_flt.slx';
% % filenames{end+1} = 'controller_fxp.slx';
% % filenames{end+1} = 'ctr_poor_scale.slx';
% % filenames{end+1} = 'engine_control.slx';
% % filenames{end+1} = 'engine_control_fxp.slx';
% % % filenames{end+1} = 'ctr_poor_scale_fa.slx';   % Mentioned in pp. C-37 but
% %                                                 % file not found.
% filenames{end+1} = 'fixedPointRule.slx';
% filenames{end+1} = 'scaling_inheritance.slx';
% filenames{end+1} = 'firfilter_double.slx';
% filenames{end+1} = 'firfilter_double_DTC.slx';
% filenames{end+1} = 'firfilter_fix8bits2.slx';

%% files\exercises\chapter3.
filenames{end+1} = 'setspeed.slx';
filenames{end+1} = 'hilo1.slx';
filenames{end+1} = 'hilo2.slx';
filenames{end+1} = 'hilo3unif.slx';
filenames{end+1} = 'hilo3norm.slx';
filenames{end+1} = 'powerDiode.slx';

% %% files\exercises\chapter4.
% filenames{end+1} = 'lopass.slx';
% filenames{end+1} = 'hipass.slx';
% filenames{end+1} = 'spike.slx';
% filenames{end+1} = 'spikeavg.slx';
% filenames{end+1} = 'spikemed.slx';
% filenames{end+1} = 'stopfilt.slx';
% filenames{end+1} = 'population.slx';
% 
% %% files\exercises\chapter5.
% filenames{end+1} = 'synth.slx';
% filenames{end+1} = 'synthvec.slx';
% filenames{end+1} = 'ode2joy.m';
% filenames{end+1} = 'synthvec2.slx';
% filenames{end+1} = 'synthws.slx';
% 
% %% files\exercises\chapter6.
% filenames{end+1} = 'DRCPart1dB.slx';
% filenames{end+1} = 'DRCPart1Final.slx';
% filenames{end+1} = 'DRCPart2.slx';
% filenames{end+1} = 'DRCPart2_sub.slx';
% 
% %% files\exercises\chapter7.
% filenames{end+1} = 'Sigmadelta_ex_soln.slx';
% 
% %% files\exercises\chapter9.
% filenames{end+1} = 'DRCPart2_sub.slx';
% filenames{end+1} = 'DRCMask.slx';
% 
% %% files\exercises\chapter10.
% filenames{end+1} = 'Engine_power_soln.slx';
% filenames{end+1} = 'mars_para.slx';
% filenames{end+1} = 'sol_mars_para.slx';
% 
% %% files\exercises\chapter11.
% filenames{end+1} = 'powerspect.slx';
% filenames{end+1} = 'powerspect2.slx';
% 
% %% files\exercises\chapter12.
% filenames{end+1} = 'B5ViewSpectrum.slx';
% filenames{end+1} = 'B5DFD.slx';
% filenames{end+1} = 'B5FiltDesign.slx';
% filenames{end+1} = 'AudioEq.slx';
% 
% %% files\exercises\chapter13.
% filenames{end+1} = 'SigmadeltaMR_ex_soln.slx';
% filenames{end+1} = 'checkFreqRespAnalog.slx';
% 
% %% files\exercises\chapter14.
% filenames{end+1} = 'kalman_filter.m';
% filenames{end+1} = 'noisy_sin.slx';
% filenames{end+1} = 'noisy_sin_fcn_call.slx';
% % filenames{end+1} = 'pythagoras_lct.m';    % Need C compiler.
% % filenames{end+1} = 'pythagoras.slx';      % Need pythagoras_lct.m to run.
% 
% %% files\exercises\chapter15.
% filenames{end+1} = 'CommSystem.slx';
% filenames{end+1} = 'CommSystem_soln.slx';
% 
% %% files\exercises\chapter16.
% filenames{end+1} = 'Sigmadelta_command.slx';

end





