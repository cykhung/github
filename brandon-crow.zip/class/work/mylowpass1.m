function Hd = mylowpass1
% Desgin a low pass filter
%   Pass band edge      = 4000Hz
%   Stop band edge      = 5000 Hz
%   Passband ripple     = 0.1 dB
%   Stopband attenuation = 50 dB
%   Sampling Frequency  = 22050 Hz

d = fdesign.lowpass('Fp,Fst,Ap,Ast', ...
                    4000,5000,0.1,50,22050);
%d = fdesign.lowpass('Fp,Fst,Ap,Ast', ...
%                    5000,6000,0.1,50,22050);
Hd = design(d, 'cheby1');
end