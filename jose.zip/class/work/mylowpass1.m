function Hd= mylowpass1
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
d= fdesign.lowpass('Fp,Fst,Ap,Ast',4000,5000,0.1,50,22050);
Hd = design(d,'cheby1');


endc