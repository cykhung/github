#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "my_AdcRef_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
#else
#include "builtin_typeid_types.h"
#include "my_AdcRef.h"
#include "my_AdcRef_capi.h"
#include "my_AdcRef_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 1 , TARGET_STRING (
"my_AdcRef/Ideal ADC" ) , TARGET_STRING ( "ideal ADC" ) , 0 , 0 , 0 , 0 , 0 }
, { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static
rtwCAPI_States rtBlockStates [ ] = { { 1 , 0 , TARGET_STRING (
"my_AdcRef/Shape the jitter\n noise spectrum. " ) , TARGET_STRING ( "" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 1 , 1 , - 1 , 0 } , { 0 , - 1 , ( NULL
) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1 , 0 } } ; static int_T
rt_LoggedStateIdxList [ ] = { 0 } ;
#ifndef HOST_CAPI_BUILD
static void my_AdcRef_InitializeDataAddr ( void * dataAddr [ ] , hyhhzloqby *
localB , jmxh3fcoxr * localDW , haxhbr00m1 * localX ) { dataAddr [ 0 ] = (
void * ) ( & localB -> j042m2ofjv ) ; dataAddr [ 1 ] = ( void * ) ( & localX
-> j55ibddnvz [ 0 ] ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void my_AdcRef_InitializeVarDimsAddr ( int32_T * vardimsAddr [ ] ) {
vardimsAddr [ 0 ] = ( NULL ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void my_AdcRef_InitializeLoggingFunctions ( RTWLoggingFcnPtr
loggingPtrs [ ] ) { loggingPtrs [ 0 ] = ( NULL ) ; loggingPtrs [ 1 ] = ( NULL
) ; }
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , ( uint8_T ) SS_DOUBLE , 0 , 0 , 0 } }
;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } } ; static
uint_T rtDimensionArray [ ] = { 1 , 1 , 3 , 1 } ; static const real_T
rtcapiStoredFloats [ ] = { 1.0E-8 , 0.0 } ; static rtwCAPI_FixPtMap
rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , (
boolean_T ) 0 } , } ; static rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { {
( const void * ) & rtcapiStoredFloats [ 0 ] , ( const void * ) &
rtcapiStoredFloats [ 1 ] , ( int8_T ) 2 , ( uint8_T ) 0 } , { ( const void *
) & rtcapiStoredFloats [ 1 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] ,
( int8_T ) 0 , ( uint8_T ) 0 } } ; static int_T rtContextSystems [ 2 ] ;
static rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ] = { { 0 , 0 ,
"my_AdcRef/Ideal ADC" , 0 , 0 } } ; static rtwCAPI_ModelMapLoggingStaticInfo
mmiStaticInfoLogging = { 2 , rtContextSystems , loggingMetaInfo , 0 , ( NULL
) , { 0 , ( NULL ) , ( NULL ) } , 0 , ( NULL ) } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 1 , ( NULL )
, 0 , ( NULL ) , 0 } , { ( NULL ) , 0 , ( NULL ) , 0 } , { rtBlockStates , 1
} , { rtDataTypeMap , rtDimensionMap , rtFixPtMap , rtElementMap ,
rtSampleTimeMap , rtDimensionArray } , "float" , { 3611650351U , 3417990460U
, 1595872450U , 3293593514U } , & mmiStaticInfoLogging , 0 , ( boolean_T ) 0
, rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
my_AdcRef_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void my_AdcRef_InitializeSystemRan ( izu2pbwlzy * const bqydw0bvlo ,
sysRanDType * systemRan [ ] , jmxh3fcoxr * localDW , int_T systemTid [ ] ,
void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER ( bqydw0bvlo ) ;
UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType * )
rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemTid [ 1 ] = bqydw0bvlo ->
Timing . mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ;
rtContextSystems [ 0 ] = 0 ; rtContextSystems [ 1 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void my_AdcRef_InitializeDataMapInfo ( izu2pbwlzy * const bqydw0bvlo ,
hyhhzloqby * localB , jmxh3fcoxr * localDW , haxhbr00m1 * localX , void *
sysRanPtr , int contextTid ) { rtwCAPI_SetVersion ( bqydw0bvlo -> DataMapInfo
. mmi , 1 ) ; rtwCAPI_SetStaticMap ( bqydw0bvlo -> DataMapInfo . mmi , &
mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( bqydw0bvlo -> DataMapInfo . mmi ,
& mmiStaticInfoLogging ) ; my_AdcRef_InitializeDataAddr ( bqydw0bvlo ->
DataMapInfo . dataAddress , localB , localDW , localX ) ;
rtwCAPI_SetDataAddressMap ( bqydw0bvlo -> DataMapInfo . mmi , bqydw0bvlo ->
DataMapInfo . dataAddress ) ; my_AdcRef_InitializeVarDimsAddr ( bqydw0bvlo ->
DataMapInfo . vardimsAddress ) ; rtwCAPI_SetVarDimsAddressMap ( bqydw0bvlo ->
DataMapInfo . mmi , bqydw0bvlo -> DataMapInfo . vardimsAddress ) ;
rtwCAPI_SetPath ( bqydw0bvlo -> DataMapInfo . mmi , ( NULL ) ) ;
rtwCAPI_SetFullPath ( bqydw0bvlo -> DataMapInfo . mmi , ( NULL ) ) ;
my_AdcRef_InitializeLoggingFunctions ( bqydw0bvlo -> DataMapInfo .
loggingPtrs ) ; rtwCAPI_SetLoggingPtrs ( bqydw0bvlo -> DataMapInfo . mmi ,
bqydw0bvlo -> DataMapInfo . loggingPtrs ) ; rtwCAPI_SetInstanceLoggingInfo (
bqydw0bvlo -> DataMapInfo . mmi , & bqydw0bvlo -> DataMapInfo .
mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray ( bqydw0bvlo -> DataMapInfo .
mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArrayLen ( bqydw0bvlo -> DataMapInfo .
mmi , 0 ) ; my_AdcRef_InitializeSystemRan ( bqydw0bvlo , bqydw0bvlo ->
DataMapInfo . systemRan , localDW , bqydw0bvlo -> DataMapInfo . systemTid ,
sysRanPtr , contextTid ) ; rtwCAPI_SetSystemRan ( bqydw0bvlo -> DataMapInfo .
mmi , bqydw0bvlo -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid (
bqydw0bvlo -> DataMapInfo . mmi , bqydw0bvlo -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( bqydw0bvlo -> DataMapInfo . mmi , & bqydw0bvlo ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void my_AdcRef_host_InitializeDataMapInfo ( my_AdcRef_host_DataMapInfo_T *
dataMap , const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ; rtwCAPI_SetPath
( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
