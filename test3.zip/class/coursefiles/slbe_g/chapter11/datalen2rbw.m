function rbw = datalen2rbw(N, NENBW, fs)
% Function to compute the RBW for a given data length, N, window type
% (characterized by its NENBW), and the sampling rate, fs.
%
rbw = (fs/N) * NENBW;
