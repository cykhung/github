/*-----------------------------------------------------------------
 *
 *	pythagoras_lct.c
 *	2006_10_11
 *
 *  Function to compute length of hypotenuse of right
 *  triangle, given the length of the other two sides
 *
 *-----------------------------------------------------------------
 */
#include <math.h>
float pythagoras_lct(float* a, float* b)
{
    float c;

    c = sqrt((pow(*a,2) + pow(*b,2)));
    
    return c;
}