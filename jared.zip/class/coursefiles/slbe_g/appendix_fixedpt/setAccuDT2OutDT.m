function setAccuDT2OutDT(sud)
if nargin < 1
    sud = gcb;
end
sumBlocks = find_system(sud,'BlockType','Sum');
for i = 1:length(sumBlocks)
    outdt = get_param(sumBlocks{i},'OutDataTypeStr');
    accudt = get_param(sumBlocks{i},'AccumDataTypeStr');
    set_param(sumBlocks{i},'AccumDataTypeStr',outdt)
    fprintf('Accumulator Data Type of block %s was changed from %s to %s\n',...
        sumBlocks{i},accudt,outdt)
end
