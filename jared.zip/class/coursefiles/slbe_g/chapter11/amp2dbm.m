function dbm = amp2dbm(A, sided)
% amp2dbm(A,sided) computes the power in a sinusoid of amplitude A in dBm 
% for a reference load of 1 ohm. 'sided' is 1 for a one-sided spectrum and 
% 2 for a two-sided spectrum. 'A' can be an array of amplitudes.

if nargin < 2
    sided = 1;
end
power = A.^2/(2*sided);
dbm = 10*log10(1000*power);
