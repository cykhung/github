function adc1_paramSweepFcn( Nonlinstart, Nonlinend, numtests)

load_system('adc1_cmd'); % This will trigger Preloadfcn calback
Non_lin_vector = linspace(Nonlinstart, Nonlinend, numtests );
msq_error =  zeros(size( Non_lin_vector ) );
for indx = 1: length( Non_lin_vector)
    NonLinFactor = Non_lin_vector(indx); 
    assignin('base','NonLinFactor',NonLinFactor);
    simOut = sim('adc1_cmd','StopTime','10e-5');
    msq_error(indx) = mean( (simOut.yout).^2 ) ;
end
plot(Non_lin_vector, msq_error,'r*--' ); grid on;
xlabel('Non linearity Factor'); ylabel('Mean squared ADC error');
close_system('adc1_cmd'); % Unload model from memory
