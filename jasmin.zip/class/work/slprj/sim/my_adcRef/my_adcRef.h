#ifndef RTW_HEADER_my_adcRef_h_
#define RTW_HEADER_my_adcRef_h_
#ifndef my_adcRef_COMMON_INCLUDES_
#define my_adcRef_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "my_adcRef_types.h"
#include <stddef.h>
#include <string.h>
#include "model_reference_types.h"
#include "rtw_modelmap_simtarget.h"
#include "rt_nonfinite.h"
typedef struct { real_T ddzqdtpiy3 ; real_T kaelrrneaa ; real_T hesw5aysrs ;
real_T bial3wtagd ; } fsent1wo35 ; typedef struct { real_T iszg30lazj ;
struct { real_T modelTStart ; real_T TUbufferArea [ 2048 ] ; } myjvzizrzy ;
struct { void * TUbufferPtrs [ 2 ] ; } kiv1fyua3z ; uint32_T k0kjwgalfx ;
struct { int_T Tail ; int_T Head ; int_T Last ; int_T CircularBufSize ; }
j3lojak4ph ; } ajmlgktm1y ; typedef struct { real_T dguhk1fvsn [ 3 ] ; }
dxhrje1sel ; typedef struct { real_T dguhk1fvsn [ 3 ] ; } fu3fpyvhq4 ;
typedef struct { boolean_T dguhk1fvsn [ 3 ] ; } n5zb3fbs4l ; typedef struct {
real_T dguhk1fvsn [ 3 ] ; } mub4wh4g4h ; typedef struct { real_T dguhk1fvsn [
3 ] ; } pmnxfkyklv ; typedef struct { real_T dguhk1fvsn [ 3 ] ; } ldkkuytuw0
; struct opxziaa3t4j_ { real_T P_0 [ 5 ] ; real_T P_1 ; real_T P_2 ; real_T
P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T
P_9 ; real_T P_10 ; real_T P_11 ; uint32_T P_12 [ 5 ] ; uint32_T P_13 [ 4 ] ;
uint32_T P_14 ; uint32_T P_15 [ 2 ] ; uint32_T P_16 ; uint32_T P_17 [ 4 ] ; }
; struct h1gikt1jue { struct SimStruct_tag * _mdlRefSfcnS ; struct { real_T
mr_nonContSig0 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 1 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 2 ] ; int32_T * vardimsAddress [ 2
] ; RTWLoggingFcnPtr loggingPtrs [ 2 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 3 ]
; } Timing ; } ; typedef struct { fsent1wo35 rtb ; ajmlgktm1y rtdw ;
bjlytd1xlg rtm ; } nbwd2lxlw1h ; extern void lrfxnug31f ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 ,
bjlytd1xlg * const iisf1ii2ef , fsent1wo35 * localB , ajmlgktm1y * localDW ,
dxhrje1sel * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_my_adcRef_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_my_adcRef_GetDWork ( const nbwd2lxlw1h
* mdlrefDW ) ; extern void mr_my_adcRef_SetDWork ( nbwd2lxlw1h * mdlrefDW ,
const mxArray * ssDW ) ; extern void mr_my_adcRef_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_my_adcRef_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * my_adcRef_GetCAPIStaticMap
( void ) ; extern void nqancyxefq ( ajmlgktm1y * localDW , dxhrje1sel *
localX ) ; extern void bumnuthb1a ( ajmlgktm1y * localDW , dxhrje1sel *
localX ) ; extern void iaigp1d3np ( bjlytd1xlg * const iisf1ii2ef ,
ajmlgktm1y * localDW ) ; extern void hyfqougvtg ( fsent1wo35 * localB ,
dxhrje1sel * localX , fu3fpyvhq4 * localXdot ) ; extern void omytsg1epv (
bjlytd1xlg * const iisf1ii2ef , const real_T * loszxqm0uj , ajmlgktm1y *
localDW ) ; extern void my_adcRef ( bjlytd1xlg * const iisf1ii2ef , const
real_T * loszxqm0uj , real_T * bbvg2h3gnt , real_T rtp_nonlingain ,
fsent1wo35 * localB , ajmlgktm1y * localDW , dxhrje1sel * localX ) ; extern
void cihpeg4vcj ( bjlytd1xlg * const iisf1ii2ef ) ;
#endif
