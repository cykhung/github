#ifndef __c1_ceval_testbench_h__
#define __c1_ceval_testbench_h__

/* Forward Declarations */

/* Type Definitions */
#ifndef typedef_SFc1_ceval_testbenchInstanceStruct
#define typedef_SFc1_ceval_testbenchInstanceStruct

typedef struct {
  boolean_T c1_doneDoubleBufferReInit;
  uint8_T c1_is_active_c1_ceval_testbench;
  uint8_T c1_JITStateAnimation[1];
  real32_T c1_coeffs[9];
  real_T c1_ntaps;
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c1_JITTransitionAnimation[1];
  int32_T c1_sfEvent;
  int32_T c1_IsDebuggerActive;
  int32_T c1_IsSequenceViewerPresent;
  int32_T c1_SequenceViewerOptimization;
  int32_T c1_IsHeatMapPresent;
  void *c1_RuntimeVar;
  uint32_T c1_mlFcnLineNumber;
  void *c1_fcnDataPtrs[4];
  char_T *c1_dataNames[4];
  uint32_T c1_numFcnVars;
  uint32_T c1_ssIds[4];
  uint32_T c1_statuses[4];
  void *c1_outMexFcns[4];
  void *c1_inMexFcns[4];
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  real32_T *c1_in;
  real32_T *c1_y;
} SFc1_ceval_testbenchInstanceStruct;

#endif                                 /* typedef_SFc1_ceval_testbenchInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_ceval_testbench_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c1_ceval_testbench_get_check_sum(mxArray *plhs[]);
extern void c1_ceval_testbench_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
