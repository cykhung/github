#include "my_adcref.h"
#include "rtwtypes.h"
#include "my_adcref_private.h"
#include "mwmathutil.h"
#include "rt_urand_Upu32_Yd_f_pw_snf.h"
#include "rt_TDelayInterpolate.h"
#include "my_adcref_capi.h"
#include "rt_nonfinite.h"
static RegMdlInfo rtMdlInfo_my_adcref [ 49 ] = { { "aqytzsjzw2h" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "my_adcref" } , {
"dqrknpkjmp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "ms4k50ctip" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "otvmoddsd1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcref" } , { "lthb3t3iuo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"jg3ufmfuey" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "eb3zlj5x41" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "bbu3dgx45w" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcref" } , { "ieyrgueyx0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"jdzebtussq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "cuxtuiy3rs" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "fdzjw5n4sl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcref" } , { "indmjxehax" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"pddmy0l44k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "kzvmmng1wt" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "mjh2zeubnh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcref" } , { "lxryosqkj2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"btsi0nn0sa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "mxg3n33p5u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "olqmccl1bi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcref" } , { "ca23ef00yc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"i1zg2h2lbg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "or0zpl2mqm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "gcwbyxrb2k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "my_adcref" } , { "nynxsvh0oz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"my_adcref" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"awsba2fs01" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "lnl1z25lo3h" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "my_adcref" } , { "lnl1z25lo3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "my_adcref" } , {
"dowhzb0yot" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"my_adcref" } , { "kbs0ahhqra" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "my_adcref" } , { "cuint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , -
1 , ( void * ) "uint64" } , { "uint64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "cint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void * )
"int64" } , { "int64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_my_adcref_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "my_adcref" } , { "mr_my_adcref_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "my_adcref" } , { "mr_my_adcref_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_RegisterSimStateChecksum" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "my_adcref" } , { "mr_my_adcref_SetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "my_adcref" } , {
"mr_my_adcref_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"my_adcref" } , { "my_adcref.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL
) } , { "my_adcref.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"my_adcref" } } ; pltxtobirxy pltxtobirx = { { - 2.5132741228718344E+7 ,
2.5132741228718344E+7 , - 2.5132741228718333E+7 , 2.513274122871834E+7 , -
2.5132741228718344E+7 } , 2.5132741228718344E+7 , 1.0 , 0.0 , 3.0E-11 , 0.0 ,
0.00390625 , 0.5 , - 0.5 , 0.0 , 1.5E-11 , 1234.0 , { 0U , 1U , 1U , 2U , 1U
} , { 0U , 2U , 4U , 5U } , 0U , { 0U , 1U } , 0U , { 0U , 0U , 0U , 1U } } ;
void i1zg2h2lbg ( indmjxehax * localDW , bbu3dgx45w * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> igfpcjpzgt [ 0 ] =
pltxtobirx . P_3 ; localX -> igfpcjpzgt [ 1 ] = pltxtobirx . P_3 ; localX ->
igfpcjpzgt [ 2 ] = pltxtobirx . P_3 ; tmp = muDoubleScalarFloor ( pltxtobirx
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> kpu2io5ipm = tseed ;
localDW -> iqub2suurt = ( pltxtobirx . P_10 - pltxtobirx . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> kpu2io5ipm ) + pltxtobirx . P_9 ; }
void ca23ef00yc ( indmjxehax * localDW , bbu3dgx45w * localX ) { real_T tmp ;
int32_T r ; int32_T t ; uint32_T tseed ; localX -> igfpcjpzgt [ 0 ] =
pltxtobirx . P_3 ; localX -> igfpcjpzgt [ 1 ] = pltxtobirx . P_3 ; localX ->
igfpcjpzgt [ 2 ] = pltxtobirx . P_3 ; tmp = muDoubleScalarFloor ( pltxtobirx
. P_11 ) ; if ( muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) )
{ tmp = 0.0 ; } else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; }
tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : (
uint32_T ) tmp ; r = ( int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed &
32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) r << 16U ) ) + t ) << 16U )
+ t ) + r ; if ( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed >
2147483646U ) { tseed = 2147483646U ; } localDW -> kpu2io5ipm = tseed ;
localDW -> iqub2suurt = ( pltxtobirx . P_10 - pltxtobirx . P_9 ) *
rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> kpu2io5ipm ) + pltxtobirx . P_9 ; }
void gcwbyxrb2k ( kbs0ahhqra * const jrt5vqr2xj , indmjxehax * localDW ) { {
real_T * pBuffer = & localDW -> c5n3hkcki1 . TUbufferArea [ 0 ] ; int_T j ;
char ptrKey [ 1024 ] ; localDW -> pfylsoybct . Tail = 0 ; localDW ->
pfylsoybct . Head = 0 ; localDW -> pfylsoybct . Last = 0 ; localDW ->
pfylsoybct . CircularBufSize = 1024 ; for ( j = 0 ; j < 1024 ; j ++ ) {
pBuffer [ j ] = pltxtobirx . P_5 ; pBuffer [ 1024 + j ] = rtmGetTaskTime (
jrt5vqr2xj , 0 ) ; } localDW -> kxvp11xoac . TUbufferPtrs [ 0 ] = ( void * )
& pBuffer [ 0 ] ; sprintf ( ptrKey , "my_adcref/Variable\nDelay_TUbuffer%d" ,
0 ) ; slsaSaveRawMemoryForSimTargetOP ( jrt5vqr2xj -> _mdlRefSfcnS , ptrKey ,
( void * * ) ( & localDW -> kxvp11xoac . TUbufferPtrs [ 0 ] ) , 2 * 1024 *
sizeof ( real_T ) , ( NULL ) , ( NULL ) ) ; } } void my_adcref ( kbs0ahhqra *
const jrt5vqr2xj , const real_T * krjrxaxbao , real_T * k2alkzafct , real_T
rtp_nonlingain , pddmy0l44k * localB , indmjxehax * localDW , bbu3dgx45w *
localX ) { real_T ob4hloqdph ; uint32_T ri ; localB -> eu0fj4jw11 = 0.0 ; for
( ri = pltxtobirx . P_17 [ 0U ] ; ri < pltxtobirx . P_17 [ 1U ] ; ri ++ ) {
localB -> eu0fj4jw11 += pltxtobirx . P_2 * localX -> igfpcjpzgt [ 0U ] ; }
for ( ri = pltxtobirx . P_17 [ 1U ] ; ri < pltxtobirx . P_17 [ 2U ] ; ri ++ )
{ localB -> eu0fj4jw11 += pltxtobirx . P_2 * localX -> igfpcjpzgt [ 1U ] ; }
for ( ri = pltxtobirx . P_17 [ 2U ] ; ri < pltxtobirx . P_17 [ 3U ] ; ri ++ )
{ localB -> eu0fj4jw11 += pltxtobirx . P_2 * localX -> igfpcjpzgt [ 2U ] ; }
{ real_T * * uBuffer = ( real_T * * ) & localDW -> kxvp11xoac . TUbufferPtrs
[ 0 ] ; real_T simTime = rtmGetTaskTime ( jrt5vqr2xj , 0 ) ; real_T
appliedDelay ; appliedDelay = localB -> eu0fj4jw11 ; if ( appliedDelay >
pltxtobirx . P_4 ) { appliedDelay = pltxtobirx . P_4 ; } if ( appliedDelay <
0.0 ) { appliedDelay = 0.0 ; } if ( appliedDelay == 0.0 ) { localB ->
kqchyfhac4 = ( * krjrxaxbao ) ; } else { localB -> kqchyfhac4 =
rt_TDelayInterpolate ( simTime - appliedDelay , 0.0 , * uBuffer , localDW ->
pfylsoybct . CircularBufSize , & localDW -> pfylsoybct . Last , localDW ->
pfylsoybct . Tail , localDW -> pfylsoybct . Head , pltxtobirx . P_5 , 0 , (
boolean_T ) ( rtmIsMinorTimeStep ( jrt5vqr2xj ) && ( ( * uBuffer + localDW ->
pfylsoybct . CircularBufSize ) [ localDW -> pfylsoybct . Head ] ==
rtmGetTaskTime ( jrt5vqr2xj , 0 ) ) ) ) ; } } if ( rtmIsMajorTimeStep (
jrt5vqr2xj ) && rtmIsSampleHit ( jrt5vqr2xj , 1 , 0 ) ) { localB ->
cm1ezopzjv = localDW -> iqub2suurt ; } if ( rtmIsMajorTimeStep ( jrt5vqr2xj )
&& rtmIsSampleHit ( jrt5vqr2xj , 2 , 0 ) ) { ob4hloqdph = rtp_nonlingain *
localB -> kqchyfhac4 ; ob4hloqdph = rtp_nonlingain * muDoubleScalarTanh (
ob4hloqdph ) ; ob4hloqdph = muDoubleScalarRound ( ob4hloqdph / pltxtobirx .
P_6 ) * pltxtobirx . P_6 ; if ( ob4hloqdph > pltxtobirx . P_7 ) { *
k2alkzafct = pltxtobirx . P_7 ; } else if ( ob4hloqdph < pltxtobirx . P_8 ) {
* k2alkzafct = pltxtobirx . P_8 ; } else { * k2alkzafct = ob4hloqdph ; } } }
void olqmccl1bi ( kbs0ahhqra * const jrt5vqr2xj , const real_T * krjrxaxbao ,
indmjxehax * localDW ) { if ( rtmIsMajorTimeStep ( jrt5vqr2xj ) ) { if (
memcmp ( jrt5vqr2xj -> nonContDerivSignal [ 0 ] . pCurrVal , jrt5vqr2xj ->
nonContDerivSignal [ 0 ] . pPrevVal , jrt5vqr2xj -> nonContDerivSignal [ 0 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( jrt5vqr2xj -> nonContDerivSignal [
0 ] . pPrevVal , jrt5vqr2xj -> nonContDerivSignal [ 0 ] . pCurrVal ,
jrt5vqr2xj -> nonContDerivSignal [ 0 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( jrt5vqr2xj -> _mdlRefSfcnS ) ; } } { real_T * *
uBuffer = ( real_T * * ) & localDW -> kxvp11xoac . TUbufferPtrs [ 0 ] ; int
numBuffers = 2 ; real_T simTime = rtmGetTaskTime ( jrt5vqr2xj , 0 ) ;
boolean_T bufferisfull = false ; localDW -> pfylsoybct . Head = ( ( localDW
-> pfylsoybct . Head < ( localDW -> pfylsoybct . CircularBufSize - 1 ) ) ? (
localDW -> pfylsoybct . Head + 1 ) : 0 ) ; if ( localDW -> pfylsoybct . Head
== localDW -> pfylsoybct . Tail ) { bufferisfull = true ; localDW ->
pfylsoybct . Tail = ( ( localDW -> pfylsoybct . Tail < ( localDW ->
pfylsoybct . CircularBufSize - 1 ) ) ? ( localDW -> pfylsoybct . Tail + 1 ) :
0 ) ; } ( * uBuffer + localDW -> pfylsoybct . CircularBufSize ) [ localDW ->
pfylsoybct . Head ] = simTime ; ( * uBuffer ) [ localDW -> pfylsoybct . Head
] = ( * krjrxaxbao ) ; if ( bufferisfull ) {
ssSetBlockStateForSolverChangedAtMajorStep ( jrt5vqr2xj -> _mdlRefSfcnS ) ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( jrt5vqr2xj ->
_mdlRefSfcnS ) ; } } if ( rtmIsMajorTimeStep ( jrt5vqr2xj ) && rtmIsSampleHit
( jrt5vqr2xj , 1 , 0 ) ) { localDW -> iqub2suurt = ( pltxtobirx . P_10 -
pltxtobirx . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( & localDW -> kpu2io5ipm ) +
pltxtobirx . P_9 ; } } void mxg3n33p5u ( pddmy0l44k * localB , bbu3dgx45w *
localX , eb3zlj5x41 * localXdot ) { uint32_T ri ; localXdot -> igfpcjpzgt [ 0
] = 0.0 ; localXdot -> igfpcjpzgt [ 1 ] = 0.0 ; localXdot -> igfpcjpzgt [ 2 ]
= 0.0 ; for ( ri = pltxtobirx . P_13 [ 0U ] ; ri < pltxtobirx . P_13 [ 1U ] ;
ri ++ ) { localXdot -> igfpcjpzgt [ pltxtobirx . P_12 [ ri ] ] += pltxtobirx
. P_0 [ ri ] * localX -> igfpcjpzgt [ 0U ] ; } for ( ri = pltxtobirx . P_13 [
1U ] ; ri < pltxtobirx . P_13 [ 2U ] ; ri ++ ) { localXdot -> igfpcjpzgt [
pltxtobirx . P_12 [ ri ] ] += pltxtobirx . P_0 [ ri ] * localX -> igfpcjpzgt
[ 1U ] ; } for ( ri = pltxtobirx . P_13 [ 2U ] ; ri < pltxtobirx . P_13 [ 3U
] ; ri ++ ) { localXdot -> igfpcjpzgt [ pltxtobirx . P_12 [ ri ] ] +=
pltxtobirx . P_0 [ ri ] * localX -> igfpcjpzgt [ 2U ] ; } for ( ri =
pltxtobirx . P_15 [ 0U ] ; ri < pltxtobirx . P_15 [ 1U ] ; ri ++ ) {
localXdot -> igfpcjpzgt [ pltxtobirx . P_14 ] += pltxtobirx . P_1 * localB ->
cm1ezopzjv ; } { } } void mjh2zeubnh ( kbs0ahhqra * const jrt5vqr2xj ) { if (
! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( jrt5vqr2xj ->
_mdlRefSfcnS , "my_adcref" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ;
} } void or0zpl2mqm ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , int_T mdlref_TID2 , kbs0ahhqra * const jrt5vqr2xj , pddmy0l44k
* localB , indmjxehax * localDW , bbu3dgx45w * localX , void * sysRanPtr ,
int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; ( void ) memset ( ( void * ) jrt5vqr2xj , 0 , sizeof
( kbs0ahhqra ) ) ; jrt5vqr2xj -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; jrt5vqr2xj -> Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ;
jrt5vqr2xj -> Timing . mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; jrt5vqr2xj ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( jrt5vqr2xj -> _mdlRefSfcnS , "my_adcref" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> eu0fj4jw11 = 0.0
; localB -> kqchyfhac4 = 0.0 ; localB -> cm1ezopzjv = 0.0 ; } ( void ) memset
( ( void * ) localDW , 0 , sizeof ( indmjxehax ) ) ; localDW -> iqub2suurt =
0.0 ; localDW -> c5n3hkcki1 . modelTStart = 0.0 ; { int32_T i ; for ( i = 0 ;
i < 2048 ; i ++ ) { localDW -> c5n3hkcki1 . TUbufferArea [ i ] = 0.0 ; } }
my_adcref_InitializeDataMapInfo ( jrt5vqr2xj , localDW , localX , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
jrt5vqr2xj -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( jrt5vqr2xj ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
jrt5vqr2xj -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } jrt5vqr2xj ->
nonContDerivSignal [ 0 ] . pPrevVal = ( char_T * ) jrt5vqr2xj ->
NonContDerivMemory . mr_nonContSig0 ; jrt5vqr2xj -> nonContDerivSignal [ 0 ]
. sizeInBytes = ( 1 * sizeof ( real_T ) ) ; jrt5vqr2xj -> nonContDerivSignal
[ 0 ] . pCurrVal = ( char_T * ) ( & localB -> cm1ezopzjv ) ; ; } void
mr_my_adcref_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_my_adcref , 49 ) ; * retVal = 1 ; } static void
mr_my_adcref_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_my_adcref_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_my_adcref_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_my_adcref_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_my_adcref_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_my_adcref_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_my_adcref_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) ; static uint_T
mr_my_adcref_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex
i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_my_adcref_cacheDataToMxArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_my_adcref_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_my_adcref_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_my_adcref_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_my_adcref_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_my_adcref_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_my_adcref_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_my_adcref_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_my_adcref_GetDWork ( const aqytzsjzw2h * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" ,
} ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_my_adcref_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & (
mdlrefDW -> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 4 ] = { "mdlrefDW->rtdw.iqub2suurt" ,
"mdlrefDW->rtdw.c5n3hkcki1" , "mdlrefDW->rtdw.kpu2io5ipm" ,
"mdlrefDW->rtdw.pfylsoybct" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 4 , rtdwDataFieldNames ) ; mr_my_adcref_cacheDataAsMxArray ( rtdwData
, 0 , 0 , ( const void * ) & ( mdlrefDW -> rtdw . iqub2suurt ) , sizeof (
mdlrefDW -> rtdw . iqub2suurt ) ) ; mr_my_adcref_cacheDataAsMxArray (
rtdwData , 0 , 1 , ( const void * ) & ( mdlrefDW -> rtdw . c5n3hkcki1 ) ,
sizeof ( mdlrefDW -> rtdw . c5n3hkcki1 ) ) ; mr_my_adcref_cacheDataAsMxArray
( rtdwData , 0 , 2 , ( const void * ) & ( mdlrefDW -> rtdw . kpu2io5ipm ) ,
sizeof ( mdlrefDW -> rtdw . kpu2io5ipm ) ) ; mr_my_adcref_cacheDataAsMxArray
( rtdwData , 0 , 3 , ( const void * ) & ( mdlrefDW -> rtdw . pfylsoybct ) ,
sizeof ( mdlrefDW -> rtdw . pfylsoybct ) ) ; mxSetFieldByNumber ( ssDW , 0 ,
1 , rtdwData ) ; } ( void ) mdlrefDW ; return ssDW ; } void
mr_my_adcref_SetDWork ( aqytzsjzw2h * mdlrefDW , const mxArray * ssDW ) { (
void ) ssDW ; ( void ) mdlrefDW ; mr_my_adcref_restoreDataFromMxArray ( (
void * ) & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) )
; { const mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_my_adcref_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
iqub2suurt ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW -> rtdw . iqub2suurt ) )
; mr_my_adcref_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
c5n3hkcki1 ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw . c5n3hkcki1 ) )
; mr_my_adcref_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
kpu2io5ipm ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . kpu2io5ipm ) )
; mr_my_adcref_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
pfylsoybct ) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . pfylsoybct ) )
; } } void mr_my_adcref_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 1852563486U , 2697950296U , 488581355U ,
1584893718U , } ; slmrModelRefRegisterSimStateChecksum ( S , "my_adcref" , &
chksum [ 0 ] ) ; } mxArray * mr_my_adcref_GetSimStateDisallowedBlocks ( ) {
return ( NULL ) ; }
#if defined(_MSC_VER)
#pragma warning(disable: 4505) //unreferenced local function has been removed
#endif
