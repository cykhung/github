#ifndef RTW_HEADER_my_adcref_capi_h_
#define RTW_HEADER_my_adcref_capi_h_
#include "my_adcref.h"
extern void my_adcref_InitializeDataMapInfo ( kbs0ahhqra * const jrt5vqr2xj ,
indmjxehax * localDW , bbu3dgx45w * localX , void * sysRanPtr , int
contextTid ) ;
#endif
