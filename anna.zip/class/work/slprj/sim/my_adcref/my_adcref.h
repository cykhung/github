#ifndef RTW_HEADER_my_adcref_h_
#define RTW_HEADER_my_adcref_h_
#ifndef my_adcref_COMMON_INCLUDES_
#define my_adcref_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "my_adcref_types.h"
#include <stddef.h>
#include <string.h>
#include "model_reference_types.h"
#include "rtw_modelmap_simtarget.h"
#include "rt_nonfinite.h"
typedef struct { real_T eu0fj4jw11 ; real_T kqchyfhac4 ; real_T cm1ezopzjv ;
} pddmy0l44k ; typedef struct { real_T iqub2suurt ; struct { real_T
modelTStart ; real_T TUbufferArea [ 2048 ] ; } c5n3hkcki1 ; struct { void *
TUbufferPtrs [ 2 ] ; } kxvp11xoac ; uint32_T kpu2io5ipm ; struct { int_T Tail
; int_T Head ; int_T Last ; int_T CircularBufSize ; } pfylsoybct ; }
indmjxehax ; typedef struct { real_T igfpcjpzgt [ 3 ] ; } bbu3dgx45w ;
typedef struct { real_T igfpcjpzgt [ 3 ] ; } eb3zlj5x41 ; typedef struct {
boolean_T igfpcjpzgt [ 3 ] ; } jg3ufmfuey ; typedef struct { real_T
igfpcjpzgt [ 3 ] ; } lthb3t3iuo ; typedef struct { real_T igfpcjpzgt [ 3 ] ;
} otvmoddsd1 ; typedef struct { real_T igfpcjpzgt [ 3 ] ; } ms4k50ctip ;
struct pltxtobirxy_ { real_T P_0 [ 5 ] ; real_T P_1 ; real_T P_2 ; real_T P_3
; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9
; real_T P_10 ; real_T P_11 ; uint32_T P_12 [ 5 ] ; uint32_T P_13 [ 4 ] ;
uint32_T P_14 ; uint32_T P_15 [ 2 ] ; uint32_T P_16 ; uint32_T P_17 [ 4 ] ; }
; struct dowhzb0yot { struct SimStruct_tag * _mdlRefSfcnS ; struct { real_T
mr_nonContSig0 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 1 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 1 ] ; int32_T * vardimsAddress [ 1
] ; RTWLoggingFcnPtr loggingPtrs [ 1 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 3 ]
; } Timing ; } ; typedef struct { pddmy0l44k rtb ; indmjxehax rtdw ;
kbs0ahhqra rtm ; } aqytzsjzw2h ; extern void or0zpl2mqm ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 ,
kbs0ahhqra * const jrt5vqr2xj , pddmy0l44k * localB , indmjxehax * localDW ,
bbu3dgx45w * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_my_adcref_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_my_adcref_GetDWork ( const aqytzsjzw2h
* mdlrefDW ) ; extern void mr_my_adcref_SetDWork ( aqytzsjzw2h * mdlrefDW ,
const mxArray * ssDW ) ; extern void mr_my_adcref_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_my_adcref_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * my_adcref_GetCAPIStaticMap
( void ) ; extern void i1zg2h2lbg ( indmjxehax * localDW , bbu3dgx45w *
localX ) ; extern void ca23ef00yc ( indmjxehax * localDW , bbu3dgx45w *
localX ) ; extern void gcwbyxrb2k ( kbs0ahhqra * const jrt5vqr2xj ,
indmjxehax * localDW ) ; extern void mxg3n33p5u ( pddmy0l44k * localB ,
bbu3dgx45w * localX , eb3zlj5x41 * localXdot ) ; extern void olqmccl1bi (
kbs0ahhqra * const jrt5vqr2xj , const real_T * krjrxaxbao , indmjxehax *
localDW ) ; extern void my_adcref ( kbs0ahhqra * const jrt5vqr2xj , const
real_T * krjrxaxbao , real_T * k2alkzafct , real_T rtp_nonlingain ,
pddmy0l44k * localB , indmjxehax * localDW , bbu3dgx45w * localX ) ; extern
void mjh2zeubnh ( kbs0ahhqra * const jrt5vqr2xj ) ;
#endif
