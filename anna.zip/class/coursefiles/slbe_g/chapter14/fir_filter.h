/* 
 * Legacy FIR Filter
 */

#include "filter_types.h"

/* Function prototype of fir_filt */
extern mytype fir_filt(mytype, int, mytype *);
