plot([0,1,1,2,2,3,3,4,4],[0,0,1,1,2,2,3,3,4]);
plot([0,4],[2,2]);
plot([2,2],[0,4]);
% Note that you don't need to specify 'hold on' 
% to keep plotting on the same axis for the icon.
text(0.3,3,'ADC');
