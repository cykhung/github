%% load signal to send in the communication system
load mtlb
Ts = 1/Fs;
%% define parameters of the Uniform Encoder and Uniform Decoder block
Peak = max(mtlb);
numEncBits = 8;
BlockSize = 512;
%% define constellation order
ConstOrder = 16;
numBitsPerSymbol = log2(ConstOrder);
%% define signal to noise ratio
SNR = 20;
