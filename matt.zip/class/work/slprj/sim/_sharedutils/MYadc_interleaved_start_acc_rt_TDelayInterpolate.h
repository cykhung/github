

                /*
            * MYadc_interleaved_start_acc_rt_TDelayInterpolate.h
            *
                    * Course Support License -- for instructional use for courses.  Not for
* government, research, commercial, or other organizational use.
        *
    * Code generation for model "MYadc_interleaved_start_acc".
    *
    * Model version              : 6.0
    * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
        * C source code generated on : Thu May 26 15:51:06 2022
            * Created for block: <Root>/B_0_1
            */


    #ifndef RTW_HEADER_MYadc_interleaved_start_acc_rt_TDelayInterpolate_h_
    #define RTW_HEADER_MYadc_interleaved_start_acc_rt_TDelayInterpolate_h_



    
                    #include "rtwtypes.h"

                #include "multiword_types.h"



    

    

    

    

    

    

    

    

    

    

    

    

    

    

                                            real_T MYadc_interleaved_start_acc_rt_TDelayInterpolate(
        real_T     tMinusDelay,           /* tMinusDelay = currentSimTime - delay */
        real_T     tStart,
        real_T     *uBuf,
        int_T      bufSz,
        int_T      *lastIdx,
        int_T      oldestIdx,
        int_T      newIdx,
        real_T     initOutput,
        boolean_T  discrete,
        boolean_T  minorStepAndTAtLastMajorOutput)
;

            

    

    

    

    

    

    #endif /* RTW_HEADER_MYadc_interleaved_start_acc_rt_TDelayInterpolate_h_ */
