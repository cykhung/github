

                /*
            * MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf.h
            *
                    * Course Support License -- for instructional use for courses.  Not for
* government, research, commercial, or other organizational use.
        *
    * Code generation for model "MYadc_interleaved_start_acc".
    *
    * Model version              : 6.0
    * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
        * C source code generated on : Thu May 26 15:51:06 2022
            * Created for block: <Root>/B_0_1
            */


    #ifndef RTW_HEADER_MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf_h_
    #define RTW_HEADER_MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf_h_



    
                    #include "rtwtypes.h"

                #include "multiword_types.h"



    

    

    

    

    

    

    

    

    

    

    

    

    

    

                                    boolean_T  MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf(
int_T       *bufSzPtr,        /* in/out - circular buffer size                 */
int_T       *tailPtr,         /* in/out - tail of circular buffer              */
int_T       *headPtr,         /* in/out - head of circular buffer              */
int_T       *lastPtr,         /* in/out - same logical 'last' referenced index */
real_T      tMinusDelay,      /* in     - last point we are looking at   */
real_T      **uBufPtr,        /* in/out - larger buffer for input        */
boolean_T   isfixedbuf,       /* in     - fixed buffer size enable       */
boolean_T istransportdelay,   /* in     - block acts as transport dela y */
int_T     *maxNewBufSzPtr);

            

    

    

    

    

    

    #endif /* RTW_HEADER_MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf_h_ */
