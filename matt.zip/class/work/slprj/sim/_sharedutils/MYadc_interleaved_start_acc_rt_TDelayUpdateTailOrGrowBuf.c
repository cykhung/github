

                /*
            * MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf.c
            *
                    * Course Support License -- for instructional use for courses.  Not for
* government, research, commercial, or other organizational use.
        *
    * Code generation for model "MYadc_interleaved_start_acc".
    *
    * Model version              : 6.0
    * Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
        * C source code generated on : Thu May 26 15:51:06 2022
            * Created for block: <Root>/B_0_1
            */




    
#include "MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf.h"

#include <stddef.h>

#include "rtwtypes.h"

#include "multiword_types.h"


    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

                            
            #ifndef __RTW_UTFREE__  
            extern void * utMalloc(size_t);
            extern void   utFree(void *);
            #endif



        /* Buffer management routine for variable delay block */
        boolean_T  MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf(
int_T       *bufSzPtr,        /* in/out - circular buffer size                 */
int_T       *tailPtr,         /* in/out - tail of circular buffer              */
int_T       *headPtr,         /* in/out - head of circular buffer              */
int_T       *lastPtr,         /* in/out - same logical 'last' referenced index */
real_T      tMinusDelay,      /* in     - last point we are looking at   */
real_T      **uBufPtr,        /* in/out - larger buffer for input        */
boolean_T   isfixedbuf,       /* in     - fixed buffer size enable       */
boolean_T istransportdelay,   /* in     - block acts as transport dela y */
int_T     *maxNewBufSzPtr)
        {

            int_T  testIdx;
            int_T  tail  = *tailPtr;
            int_T  bufSz = *bufSzPtr;
            real_T *tBuf = *uBufPtr + bufSz;
            real_T *xBuf = (NULL);

            int_T    numBuffer = 2;
            if (istransportdelay){
                numBuffer =3 ;
                xBuf= *uBufPtr + 2 * bufSz;
            }

            /*    Get testIdx, the index of the second oldest data point and
            *    see if this is older than current sim time minus applied delay,
            *    used to see if we can move tail forward
            */
            testIdx = (tail < (bufSz - 1)) ? (tail + 1) : 0;

            if ( (tMinusDelay <= tBuf[testIdx]) && !isfixedbuf) {
                int_T  j;
                real_T *tempT;
                real_T *tempU;
                real_T *tempX = (NULL);

                real_T *uBuf     = *uBufPtr;
                int_T  newBufSz  = bufSz + 1024;

                if (newBufSz > *maxNewBufSzPtr) {
                    *maxNewBufSzPtr = newBufSz; /* save for warning*/
                }

                tempU = (real_T*)utMalloc(numBuffer*newBufSz*sizeof(real_T));

                if (tempU == (NULL)){
                    return (false);
                }
                tempT = tempU + newBufSz;
                if(istransportdelay) tempX = tempT + newBufSz;

                for (j = tail; j < bufSz; j++) {
                    tempT[j - tail] = tBuf[j];
                    tempU[j - tail] = uBuf[j];
                    if (istransportdelay)
                    tempX[j - tail] = xBuf[j];
                }
                for (j = 0; j < tail; j++) {
                    tempT[j + bufSz - tail] = tBuf[j];
                    tempU[j + bufSz - tail] = uBuf[j];
                    if (istransportdelay)
                    tempX[j + bufSz - tail] = xBuf[j];
                }

                if (*lastPtr> tail)
                {
                    *lastPtr -= tail;
                } else {
                    *lastPtr += (bufSz - tail);
                }
                *tailPtr= 0;
                *headPtr = bufSz;

                utFree(uBuf);

                *bufSzPtr = newBufSz;
                *uBufPtr  = tempU;

            }else {
                *tailPtr = testIdx; /* move tail forward */
            }

            return(true);


        }
            


    

    

    

    
