#ifndef RTW_HEADER_adcRef2_h_
#define RTW_HEADER_adcRef2_h_
#ifndef adcRef2_COMMON_INCLUDES_
#define adcRef2_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "adcRef2_types.h"
#include <stddef.h>
#include <string.h>
#include "model_reference_types.h"
#include "rtw_modelmap_simtarget.h"
#include "rt_nonfinite.h"
typedef struct { real_T nuflylbnoz ; real_T h41i2tej22 ; real_T a2wq3qn3kc ;
real_T dksgr5b4my ; real_T istv4rlpl2 ; } aqhwilkdpr ; typedef struct {
real_T oxtt4ezvyj ; struct { real_T modelTStart ; real_T TUbufferArea [ 2048
] ; } o0kqxv2uqs ; struct { void * TUbufferPtrs [ 2 ] ; } j5ferbg1nk ;
uint32_T fs4e1xgjld ; struct { int_T Tail ; int_T Head ; int_T Last ; int_T
CircularBufSize ; } nfl1qdj5jx ; } erwcrwoqga ; typedef struct { real_T
awfrz2klqr [ 3 ] ; } p0xt21di20 ; typedef struct { real_T awfrz2klqr [ 3 ] ;
} ceqijwlkbi ; typedef struct { boolean_T awfrz2klqr [ 3 ] ; } mywjid1o3l ;
typedef struct { real_T awfrz2klqr [ 3 ] ; } k5nyjkwwmo ; typedef struct {
real_T awfrz2klqr [ 3 ] ; } ehvyhtqejv ; typedef struct { real_T awfrz2klqr [
3 ] ; } cec1vaf0po ; struct bgth3rll15z_ { real_T P_0 [ 5 ] ; real_T P_1 ;
real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ;
real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; uint32_T P_12 [ 5 ] ;
uint32_T P_13 [ 4 ] ; uint32_T P_14 ; uint32_T P_15 [ 2 ] ; uint32_T P_16 ;
uint32_T P_17 [ 4 ] ; } ; struct duop1owunb { struct SimStruct_tag *
_mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 1 ] ; } NonContDerivMemory ;
ssNonContDerivSigInfo nonContDerivSignal [ 1 ] ; const rtTimingBridge *
timingBridge ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; void * dataAddress [
3 ] ; int32_T * vardimsAddress [ 3 ] ; RTWLoggingFcnPtr loggingPtrs [ 3 ] ;
sysRanDType * systemRan [ 2 ] ; int_T systemTid [ 2 ] ; } DataMapInfo ;
struct { int_T mdlref_GlobalTID [ 3 ] ; } Timing ; } ; typedef struct {
aqhwilkdpr rtb ; erwcrwoqga rtdw ; estj3w2p3r rtm ; } hkcgqaaszhy ; extern
void nkhqhltizm ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , int_T mdlref_TID2 , estj3w2p3r * const bcszd0h5ah , aqhwilkdpr
* localB , erwcrwoqga * localDW , p0xt21di20 * localX , void * sysRanPtr ,
int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_adcRef2_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_adcRef2_GetDWork ( const hkcgqaaszhy *
mdlrefDW ) ; extern void mr_adcRef2_SetDWork ( hkcgqaaszhy * mdlrefDW , const
mxArray * ssDW ) ; extern void mr_adcRef2_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_adcRef2_GetSimStateDisallowedBlocks ( )
; extern const rtwCAPI_ModelMappingStaticInfo * adcRef2_GetCAPIStaticMap (
void ) ; extern void jf5srk2pfv ( erwcrwoqga * localDW , p0xt21di20 * localX
) ; extern void bw2iziwjm4 ( erwcrwoqga * localDW , p0xt21di20 * localX ) ;
extern void brtvyumc4y ( estj3w2p3r * const bcszd0h5ah , erwcrwoqga * localDW
) ; extern void nu0hpmbqkd ( aqhwilkdpr * localB , p0xt21di20 * localX ,
ceqijwlkbi * localXdot ) ; extern void pznyn1a4is ( estj3w2p3r * const
bcszd0h5ah , const real_T * or1edqrrlx , erwcrwoqga * localDW ) ; extern void
adcRef2 ( estj3w2p3r * const bcszd0h5ah , const real_T * or1edqrrlx , real_T
* gp44vqrifb , real_T rtp_nonlingain , aqhwilkdpr * localB , erwcrwoqga *
localDW , p0xt21di20 * localX ) ; extern void efdrd5alw5 ( estj3w2p3r * const
bcszd0h5ah ) ;
#endif
