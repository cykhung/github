#ifndef RTW_HEADER_my_AdcRef_capi_h_
#define RTW_HEADER_my_AdcRef_capi_h_
#include "my_AdcRef.h"
extern void my_AdcRef_InitializeDataMapInfo ( izu2pbwlzy * const bqydw0bvlo ,
jmxh3fcoxr * localDW , haxhbr00m1 * localX , void * sysRanPtr , int
contextTid ) ;
#endif
