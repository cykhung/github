#include "MYadc_interleaved_start_acc.h"
#include "rtwtypes.h"
#include "mwmathutil.h"
#include "MYadc_interleaved_start_acc_private.h"
#include <string.h>
#include "MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf.h"
#include "MYadc_interleaved_start_acc_rt_TDelayInterpolate.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simtarget/slSimTgtMdlrefSfcnBridge.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
void rt_ssGetBlockPath ( SimStruct * S , int_T sysIdx , int_T blkIdx , char_T
* * path ) { _ssGetBlockPath ( S , sysIdx , blkIdx , path ) ; } void
rt_ssSet_slErrMsg ( void * S , void * diag ) { SimStruct * castedS = (
SimStruct * ) S ; if ( ! _ssIsErrorStatusAslErrMsg ( castedS ) ) {
_ssSet_slErrMsg ( castedS , diag ) ; } else { _ssDiscardDiagnostic ( castedS
, diag ) ; } } void rt_ssReportDiagnosticAsWarning ( void * S , void * diag )
{ _ssReportDiagnosticAsWarning ( ( SimStruct * ) S , diag ) ; } void
rt_ssReportDiagnosticAsInfo ( void * S , void * diag ) {
_ssReportDiagnosticAsInfo ( ( SimStruct * ) S , diag ) ; } static void
mdlOutputs ( SimStruct * S , int_T tid ) { B_MYadc_interleaved_start_T * _rtB
; DW_MYadc_interleaved_start_T * _rtDW ; P_MYadc_interleaved_start_T * _rtP ;
X_MYadc_interleaved_start_T * _rtX ; real_T tmp ; int32_T isHit ; uint32_T ri
; uint8_T rtb_B_0_3_0 ; _rtDW = ( ( DW_MYadc_interleaved_start_T * )
ssGetRootDWork ( S ) ) ; _rtX = ( ( X_MYadc_interleaved_start_T * )
ssGetContStates ( S ) ) ; _rtP = ( ( P_MYadc_interleaved_start_T * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( B_MYadc_interleaved_start_T * )
_ssGetModelBlockIO ( S ) ) ; isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit
!= 0 ) { ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; } _rtB ->
B_0_1_0 = 0.0 ; for ( isHit = 0 ; isHit < 8 ; isHit ++ ) { for ( ri = _rtP ->
P_17 [ ( uint32_T ) isHit ] ; ri < _rtP -> P_17 [ isHit + 1U ] ; ri ++ ) {
_rtB -> B_0_1_0 += _rtP -> P_2 * _rtX -> AntialiasFilter_CSTATE [ ( uint32_T
) isHit ] ; } } ssCallAccelRunBlock ( S , 0 , 2 , SS_CALL_MDL_OUTPUTS ) ;
isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { rtb_B_0_3_0 = _rtDW
-> Output_DSTATE ; } { real_T * * uBuffer = ( real_T * * ) & _rtDW ->
u2PeriodDelay_PWORK . TUbufferPtrs [ 0 ] ; real_T simTime = ssGetT ( S ) ;
real_T tMinusDelay = simTime - _rtP -> P_5 ; _rtB -> B_0_4_0 =
MYadc_interleaved_start_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0 , *
uBuffer , _rtDW -> u2PeriodDelay_IWORK . CircularBufSize , & _rtDW ->
u2PeriodDelay_IWORK . Last , _rtDW -> u2PeriodDelay_IWORK . Tail , _rtDW ->
u2PeriodDelay_IWORK . Head , _rtP -> P_6 , 0 , ( boolean_T ) (
ssIsMinorTimeStep ( S ) && ( ( * uBuffer + _rtDW -> u2PeriodDelay_IWORK .
CircularBufSize ) [ _rtDW -> u2PeriodDelay_IWORK . Head ] == ssGetT ( S ) ) )
) ; } ssCallAccelRunBlock ( S , 0 , 5 , SS_CALL_MDL_OUTPUTS ) ; isHit =
ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { if ( rtb_B_0_3_0 >= _rtP ->
P_19 ) { _rtB -> B_0_6_0 = _rtB -> B_0_2_0 ; } else { _rtB -> B_0_6_0 = _rtB
-> B_0_5_0 ; } ssCallAccelRunBlock ( S , 0 , 7 , SS_CALL_MDL_OUTPUTS ) ; }
tmp = ssGetTaskTime ( S , 0 ) ; _rtB -> B_0_9_0 = ( muDoubleScalarSin ( _rtP
-> P_10 [ 0 ] * tmp + _rtP -> P_11 ) * _rtP -> P_8 + _rtP -> P_9 ) + (
muDoubleScalarSin ( _rtP -> P_10 [ 1 ] * tmp + _rtP -> P_11 ) * _rtP -> P_8 +
_rtP -> P_9 ) ; isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) {
rtb_B_0_3_0 += _rtB -> B_0_0_0 ; if ( rtb_B_0_3_0 > _rtP -> P_20 ) { _rtB ->
B_0_11_0 = _rtB -> B_0_1_0_m ; } else { _rtB -> B_0_11_0 = rtb_B_0_3_0 ; } }
UNUSED_PARAMETER ( tid ) ; } static void mdlOutputsTID4 ( SimStruct * S ,
int_T tid ) { B_MYadc_interleaved_start_T * _rtB ;
P_MYadc_interleaved_start_T * _rtP ; _rtP = ( ( P_MYadc_interleaved_start_T *
) ssGetModelRtp ( S ) ) ; _rtB = ( ( B_MYadc_interleaved_start_T * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> B_0_0_0 = _rtP -> P_21 ; _rtB ->
B_0_1_0_m = _rtP -> P_22 ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) {
B_MYadc_interleaved_start_T * _rtB ; DW_MYadc_interleaved_start_T * _rtDW ;
P_MYadc_interleaved_start_T * _rtP ; int32_T isHit ; _rtDW = ( (
DW_MYadc_interleaved_start_T * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
P_MYadc_interleaved_start_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_MYadc_interleaved_start_T * ) _ssGetModelBlockIO ( S ) ) ; isHit =
ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { ssCallAccelRunBlock ( S , 0
, 0 , SS_CALL_MDL_UPDATE ) ; } ssCallAccelRunBlock ( S , 0 , 2 ,
SS_CALL_MDL_UPDATE ) ; isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0
) { _rtDW -> Output_DSTATE = _rtB -> B_0_11_0 ; } { real_T * * uBuffer = (
real_T * * ) & _rtDW -> u2PeriodDelay_PWORK . TUbufferPtrs [ 0 ] ; real_T
simTime = ssGetT ( S ) ; _rtDW -> u2PeriodDelay_IWORK . Head = ( ( _rtDW ->
u2PeriodDelay_IWORK . Head < ( _rtDW -> u2PeriodDelay_IWORK . CircularBufSize
- 1 ) ) ? ( _rtDW -> u2PeriodDelay_IWORK . Head + 1 ) : 0 ) ; if ( _rtDW ->
u2PeriodDelay_IWORK . Head == _rtDW -> u2PeriodDelay_IWORK . Tail ) { if ( !
MYadc_interleaved_start_acc_rt_TDelayUpdateTailOrGrowBuf ( & _rtDW ->
u2PeriodDelay_IWORK . CircularBufSize , & _rtDW -> u2PeriodDelay_IWORK . Tail
, & _rtDW -> u2PeriodDelay_IWORK . Head , & _rtDW -> u2PeriodDelay_IWORK .
Last , simTime - _rtP -> P_5 , uBuffer , ( boolean_T ) 0 , false , & _rtDW ->
u2PeriodDelay_IWORK . MaxNewBufSize ) ) { ssSetErrorStatus ( S ,
"tdelay memory allocation error" ) ; return ; } } ( * uBuffer + _rtDW ->
u2PeriodDelay_IWORK . CircularBufSize ) [ _rtDW -> u2PeriodDelay_IWORK . Head
] = simTime ; ( * uBuffer ) [ _rtDW -> u2PeriodDelay_IWORK . Head ] = _rtB ->
B_0_1_0 ; } ssCallAccelRunBlock ( S , 0 , 5 , SS_CALL_MDL_UPDATE ) ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID4 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { B_MYadc_interleaved_start_T *
_rtB ; DW_MYadc_interleaved_start_T * _rtDW ; P_MYadc_interleaved_start_T *
_rtP ; XDot_MYadc_interleaved_start_T * _rtXdot ; X_MYadc_interleaved_start_T
* _rtX ; int_T is ; uint32_T ri ; _rtDW = ( ( DW_MYadc_interleaved_start_T *
) ssGetRootDWork ( S ) ) ; _rtXdot = ( ( XDot_MYadc_interleaved_start_T * )
ssGetdX ( S ) ) ; _rtX = ( ( X_MYadc_interleaved_start_T * ) ssGetContStates
( S ) ) ; _rtP = ( ( P_MYadc_interleaved_start_T * ) ssGetModelRtp ( S ) ) ;
_rtB = ( ( B_MYadc_interleaved_start_T * ) _ssGetModelBlockIO ( S ) ) ;
memset ( & _rtXdot -> AntialiasFilter_CSTATE [ 0 ] , 0 , sizeof ( real_T ) <<
3U ) ; for ( is = 0 ; is < 8 ; is ++ ) { for ( ri = _rtP -> P_13 [ ( uint32_T
) is ] ; ri < _rtP -> P_13 [ is + 1U ] ; ri ++ ) { _rtXdot ->
AntialiasFilter_CSTATE [ _rtP -> P_12 [ ri ] ] += _rtP -> P_0 [ ri ] * _rtX
-> AntialiasFilter_CSTATE [ ( uint32_T ) is ] ; } } for ( ri = _rtP -> P_15 [
0U ] ; ri < _rtP -> P_15 [ 1U ] ; ri ++ ) { _rtXdot -> AntialiasFilter_CSTATE
[ _rtP -> P_14 ] += _rtP -> P_1 * _rtB -> B_0_9_0 ; } ssCallAccelRunBlock ( S
, 0 , 2 , SS_CALL_MDL_DERIVATIVES ) ; ssCallAccelRunBlock ( S , 0 , 5 ,
SS_CALL_MDL_DERIVATIVES ) ; } static void mdlInitializeSizes ( SimStruct * S
) { ssSetChecksumVal ( S , 0 , 955843877U ) ; ssSetChecksumVal ( S , 1 ,
1001564281U ) ; ssSetChecksumVal ( S , 2 , 3248541535U ) ; ssSetChecksumVal (
S , 3 , 3968680160U ) ; { mxArray * slVerStructMat = ( NULL ) ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == ( NULL ) ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "10.5" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
DW_MYadc_interleaved_start_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( B_MYadc_interleaved_start_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
P_MYadc_interleaved_start_T ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & MYadc_interleaved_start_DefaultP ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID4 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
