#ifndef RTW_HEADER_MYadc_interleaved_start_acc_h_
#define RTW_HEADER_MYadc_interleaved_start_acc_h_
#ifndef MYadc_interleaved_start_acc_COMMON_INCLUDES_
#define MYadc_interleaved_start_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn
#define S_FUNCTION_LEVEL 2
#ifndef RTW_GENERATED_S_FUNCTION
#define RTW_GENERATED_S_FUNCTION
#endif
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "MYadc_interleaved_start_acc_types.h"
#include "my_AdcRef.h"
#include "model_reference_types.h"
#include "rt_defines.h"
#include <stddef.h>
typedef struct { real_T B_0_1_0 ; real_T B_0_2_0 ; real_T B_0_4_0 ; real_T
B_0_5_0 ; real_T B_0_6_0 ; real_T B_0_9_0 ; uint8_T B_0_11_0 ; uint8_T
B_0_0_0 ; uint8_T B_0_1_0_m ; char_T pad_B_0_1_0_m [ 5 ] ; }
B_MYadc_interleaved_start_T ; typedef struct { struct { real_T modelTStart ;
} u2PeriodDelay_RWORK ; struct { void * TUbufferPtrs [ 2 ] ; }
u2PeriodDelay_PWORK ; void * TimeScope_PWORK ; struct { int_T Tail ; int_T
Head ; int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
u2PeriodDelay_IWORK ; uint8_T Output_DSTATE ; char_T pad_Output_DSTATE [ 3 ]
; okzntuxvuz5 Model_InstanceData ; okzntuxvuz5 Model1_InstanceData ; }
DW_MYadc_interleaved_start_T ; typedef struct { real_T AntialiasFilter_CSTATE
[ 8 ] ; haxhbr00m1 Model_CSTATE ; haxhbr00m1 Model1_CSTATE ; }
X_MYadc_interleaved_start_T ; typedef struct { real_T AntialiasFilter_CSTATE
[ 8 ] ; jy53cvkvuq Model_CSTATE ; jy53cvkvuq Model1_CSTATE ; }
XDot_MYadc_interleaved_start_T ; typedef struct { boolean_T
AntialiasFilter_CSTATE [ 8 ] ; kgdbsuwrmw Model_CSTATE ; kgdbsuwrmw
Model1_CSTATE ; } XDis_MYadc_interleaved_start_T ; typedef struct { real_T
AntialiasFilter_CSTATE [ 8 ] ; d0yscc03is Model_CSTATE ; d0yscc03is
Model1_CSTATE ; } CStateAbsTol_MYadc_interleaved_start_T ; typedef struct {
real_T AntialiasFilter_CSTATE [ 8 ] ; l12fvf03ll Model_CSTATE ; l12fvf03ll
Model1_CSTATE ; } CXPtMin_MYadc_interleaved_start_T ; typedef struct { real_T
AntialiasFilter_CSTATE [ 8 ] ; hohkrpqpj3 Model_CSTATE ; hohkrpqpj3
Model1_CSTATE ; } CXPtMax_MYadc_interleaved_start_T ; struct
P_MYadc_interleaved_start_T_ { real_T P_0 [ 15 ] ; real_T P_1 ; real_T P_2 ;
real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ;
real_T P_9 ; real_T P_10 [ 2 ] ; real_T P_11 ; uint32_T P_12 [ 15 ] ;
uint32_T P_13 [ 9 ] ; uint32_T P_14 ; uint32_T P_15 [ 2 ] ; uint32_T P_16 ;
uint32_T P_17 [ 9 ] ; uint8_T P_18 ; uint8_T P_19 ; uint8_T P_20 ; uint8_T
P_21 ; uint8_T P_22 ; char_T pad_P_22 [ 7 ] ; } ; extern
P_MYadc_interleaved_start_T MYadc_interleaved_start_DefaultP ;
#endif
