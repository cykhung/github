#ifndef RTW_HEADER_my_AdcRef_acc_h_
#define RTW_HEADER_my_AdcRef_acc_h_
#ifndef my_AdcRef_acc_COMMON_INCLUDES_
#define my_AdcRef_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn
#define S_FUNCTION_LEVEL 2
#ifndef RTW_GENERATED_S_FUNCTION
#define RTW_GENERATED_S_FUNCTION
#endif
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "my_AdcRef_acc_types.h"
#include <stddef.h>
#include <float.h>
#include "mwmathutil.h"
#include "rt_defines.h"
typedef struct { real_T B_0_0_0 ; real_T B_0_1_0 ; real_T B_0_2_0 ; real_T
B_0_6_0 ; real_T B_0_7_0 ; real_T B_0_9_0 ; } B_my_AdcRef_T ; typedef struct
{ real_T UniformRandomNumber_NextOutput ; struct { real_T modelTStart ; }
VariableDelay_RWORK ; struct { void * TUbufferPtrs [ 2 ] ; }
VariableDelay_PWORK ; uint32_T RandSeed ; struct { int_T Tail ; int_T Head ;
int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
VariableDelay_IWORK ; } DW_my_AdcRef_T ; typedef struct { real_T
Shapethejitternoisespectrum_CSTATE [ 3 ] ; } X_my_AdcRef_T ; typedef struct {
real_T Shapethejitternoisespectrum_CSTATE [ 3 ] ; } XDot_my_AdcRef_T ;
typedef struct { boolean_T Shapethejitternoisespectrum_CSTATE [ 3 ] ; }
XDis_my_AdcRef_T ; typedef struct { real_T Shapethejitternoisespectrum_CSTATE
[ 3 ] ; } CStateAbsTol_my_AdcRef_T ; typedef struct { real_T
Shapethejitternoisespectrum_CSTATE [ 3 ] ; } CXPtMin_my_AdcRef_T ; typedef
struct { real_T Shapethejitternoisespectrum_CSTATE [ 3 ] ; }
CXPtMax_my_AdcRef_T ; typedef struct { real_T Analog ; }
ExternalUPtrs_my_AdcRef_T ; typedef struct { real_T * B_0_1 ; }
ExtY_my_AdcRef_T ; struct P_my_AdcRef_T_ { real_T P_0 [ 5 ] ; real_T P_1 ;
real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ;
real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T
P_13 ; uint32_T P_14 [ 5 ] ; uint32_T P_15 [ 4 ] ; uint32_T P_16 ; uint32_T
P_17 [ 2 ] ; uint32_T P_18 ; uint32_T P_19 [ 4 ] ; char_T pad_P_19 [ 4 ] ; }
; extern P_my_AdcRef_T my_AdcRef_rtDefaultP ;
#endif
