#ifndef RTW_HEADER_my_AdcRef_acc_types_h_
#define RTW_HEADER_my_AdcRef_acc_types_h_
typedef struct P_my_AdcRef_T_ P_my_AdcRef_T ;
#endif
