function gain = fcn(level, loudness);

y = u;

persistent envelope;
attack_rate = 0.8;
decay_rate = 0.01;
if isempty(envelope)
    envelope = eps;
end

level_diff = level - envelope;
if level_diff > 0
    envelope = envelope + attack_rate*level_diff;
else
    envelope = envelope + decay_rate*level_diff;
end

gain = loudness/envelope;

