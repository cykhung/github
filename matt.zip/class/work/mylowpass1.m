function Hd = mylowpass1

d = fdesign.lowpass('Fp,Fst,Ap,Ast', 4e3, 5e3, 3, 50, 22050);
Hd = design(d, 'cheby1');
end
