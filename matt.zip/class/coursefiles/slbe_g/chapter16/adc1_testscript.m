%% Parameter sweep using SIM command

bdclose all;  % Make sure the model is NOT already loaded in memory
load_system('adc1_cmd'); % This will trigger Preloadfcn calback
Non_lin_vector = [0.1, 0.5, 1.0, 1.5, 3, 5, 7];
msq_error =  zeros(size( Non_lin_vector ) );
for indx = 1:length(Non_lin_vector)
    NonLinFactor = Non_lin_vector(indx);
    simOut = sim('adc1_cmd','StopTime','10e-5');
    msq_error(indx) = mean( (simOut.yout).^2 ) ;
end
plot(Non_lin_vector, msq_error,'r*--' ); grid on;
xlabel('Nonlinearity Factor'); ylabel('Mean squared ADC error');
close_system('adc1_cmd'); % Unload model from memory
