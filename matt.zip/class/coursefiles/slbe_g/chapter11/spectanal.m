%% Script showing different spectral analysis functions
f = [200 320 560 1000];
a = [0.1 0.4 1.0 0.5];
% f = [1000];
% a = [1.0];
% phi = [0 0 0 0];
fs = 8192;
ndft = 2048;
t = 0:1/fs:2-1/fs; % Time base for 2 seconds of signal
s = a*sin(2*pi*f'*t);
ss = s(1:ndft);
SS = abs(fft(ss,ndft));
freq = fs*[0:ndft-1]/ndft;
freqshift = freq - fs/2; % For plots with fftshift
%% Generate two-sided plots
watts = (SS/ndft).^2; % Power in a 1 ohm resistor
wattsShift = fftshift(watts); % Rearrange for nice plots
wattsPerHz = wattsShift/(fs/ndft); % Divide by FFT bin width
dbWatts = 10*log10(wattsShift);
% dbWattsPerHz = dbWatts/(fs/ndft); % This is how I think it should be computed
dbWattsPerHz = 10*log10(wattsPerHz); % This is how Spectrum Scope computes it
dBm = dbWatts + 30;
mwPerHz = wattsPerHz*1000;
% dBmPerHz = dBm/(fs/ndft); % This is how I think it should be computed
dBmPerHz = 10*log10(mwPerHz); % This is how Spectrum Scope computes it
figure(1); plot(freqshift,wattsShift); grid on; title('Spectrum Plot (Watts)');
figure(2); plot(freqshift,dbWatts); grid on; title('Spectrum Plot (dBW)');
figure(3); plot(freqshift,wattsPerHz); grid on; title('Spectrum Plot (Watts/Hz)');
figure(4); plot(freqshift,dbWattsPerHz); grid on; title('Spectrum Plot (dBW/Hz)');
figure(5); plot(freqshift,dBm); grid on; title('Spectrum Plot (dBm)');
figure(6); plot(freqshift,dBmPerHz); grid on; title('Spectrum Plot (dBm/Hz)');
xlabel('Freq (Hz)');
ylabel('Power (dB)');
sigTotPwr = sum(ss.^2)/ndft
dftTotPwr = sum((SS/ndft).^2)
% Two-sided powers for each frequency
sinpowers = (a.^2/2.0)/2.0
sinpowersDB = 10*log10(sinpowers)