% Specify the Sampling Frequency and base time for "ode to joy"

% Initialize sampling freq, and the Notes that make up the song
fs = 8000/1000; c = 0; d = 1; e = 2; f = 3; g = 4; ns = 8; % No Sound
s = [e,e,f,g,g,f,e,d,c,c,d,e,e,d,d,e,e,f,g,g,f,e,d,c,c,d,e,d,c,c,...
    d,d,e,c,d,e,f,e,c,d,e,f,e,d,c,d,g,e,e,f,g,g,f,e,d,c,c,d,e,d,c,c];
n = length(s);
% The Time Duration of each Note
dur = [1,1,1,1,1,1,1,1,1,1,1,1,1.5,.5,2,1,1,1,1,1,1,1,1,1,1,1,1,1.5,.5,2, ...
    1,1,1,1,1,.5,.5,1,1,1,.5,.5,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1.5,.5,2];
speedup = 0.5; dur = dur*speedup;
% Add a short break after each note
s = [s; ns+zeros(1,n)]; s = reshape(s,1,2*n);
dur = reshape([0.9*dur; 0.1*ones(1,n)],1,2*n);

% Replicate the data sequence
trep = round(dur*fs); % How many times to repeat each note
u = zeros(1,sum(trep));
tcount = 0;
for m = 1:length(s)
    u(tcount+1:tcount+trep(m)) = s(m);
    tcount = tcount+trep(m);
end
clear fs c d e f g ns s n dur speedup trep tcount m