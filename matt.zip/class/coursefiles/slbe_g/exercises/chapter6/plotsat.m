clear
figure(1)
clf

%% No saturation.
input_dBm = -20:0.1:-10;
output_dBm = input_dBm;
plot(input_dBm, output_dBm, 'k.');
set(gca, 'XTick', [-20 -15 -10])
set(gca, 'YTick', [-20 -15 -10])
xlabel('Input (dB)');
ylabel('Output (dB)');
text(-12.2, -10.5685, 'Ratio 1:1');

%% Saturation.
threshold_dBm = -15;
ratiovalue = 4;
output_dBm = NaN(size(input_dBm));
for n = 1:length(output_dBm)    
    if (input_dBm(n) > threshold_dBm)
        amountOver_dBm = input_dBm(n) - threshold_dBm;
        output_dBm(n)  = threshold_dBm + amountOver_dBm/ratiovalue;
    else
        output_dBm(n) = input_dBm(n);
    end
end
hold on
plot(input_dBm, output_dBm, 'k', 'LineWidth', 2);
text(-11.58175, -13.4549, 'Ratio 4:1');
