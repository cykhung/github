%% clean-up section
clear all
close all

%% create a noisy sinusoidal signal at 200 Hz
f0 = 200;
t = 0:1/1e4:0.25;
dt = 1/1e4;
N0 = 0.1;
z = sin(2*pi*f0*t)+N0*randn(size(t));

%% Kalman filter initialization
% State transition Matrix
A = [cos(2*pi*f0*dt), -sin(2*pi*f0*dt);
     sin(2*pi*f0*dt), cos(2*pi*f0*dt)];

% Measurement Matrix
H = [1 0];

% Process noise variance
Q = 0;
% Measurement noise variance
R = N0 ;

% Estimated state
x_est = [0; 1];
% Estimated error covariance
p_est = N0 * eye(2, 2);

%% Run Kalman filter
y = zeros(size(z));
for k = 1:length(z)
    % Kalman algorithm
% Predicted state and covariance
x_prd = A * x_est;
p_prd = A * p_est * A' + Q;

% Estimation
S = H * p_prd' * H' + R;
B = H * p_prd';
klm_gain = (S \ B)';

% Estimated state and covariance
x_est = x_prd + klm_gain * (z(k) - H * x_prd);
p_est = p_prd - klm_gain * H * p_prd;

% Compute the estimated measurements
y(k) = H * x_est;

end

%% Plot section
figure, hold on
plot(t,z)
plot(t,y,'r','LineWidth',2)
grid on
legend('Noisy signal','Estimated signal')
