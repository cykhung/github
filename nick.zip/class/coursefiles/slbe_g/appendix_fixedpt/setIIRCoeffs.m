function setIIRCoeffs(sys,SOS,G)
load tableContentIIR
annotations = find_system(sys,'FindAll','on','Type','annotation');
annotationNames = get_param(annotations,'Name');
tableSOS = annotations(cellfun(@(x) ~isempty(x),strfind(annotationNames,'<!--SOS-->')));
tableG   = annotations(cellfun(@(x) ~isempty(x),strfind(annotationNames,'<!--G-->')));

tableSOSName = char(strjoin(reshape([tableSOSBasic,[string(reshape(SOS',[],1));""]]',[],1)));
set_param(tableSOS,'Name',tableSOSName)

tableGName = char(strjoin(reshape([tableGBasic,[string(G');""]]',[],1)));
set_param(tableG,'Name',tableGName)

