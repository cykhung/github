#include "myAdcRef.h"
#include "rtwtypes.h"
#include "myAdcRef_private.h"
#include "mwmathutil.h"
#include "rt_urand_Upu32_Yd_f_pw_snf.h"
#include "rt_TDelayInterpolate.h"
#include "myAdcRef_capi.h"
#include "rt_nonfinite.h"
static RegMdlInfo rtMdlInfo_myAdcRef [ 49 ] = { { "jo4dnl2tvxq" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "myAdcRef" } , {
"i2twm4abrr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "llg3cf3lgx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "bwdwgdvgz4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "foqysqk3qn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"e1v3dlfe51" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "ktp4t1dufk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "cuk0vnaths" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "lcwdsf3m0o" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"kxcuzflaap" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "jzzagfm43u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "aqmh50nq5n" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "a1jtauijn3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"m33ibcx3yc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "nqzpzewbnj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "ial4inrtvv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "hizkdadztf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"errngbuish" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "nlz4nouxac" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "adod515mu1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "cdgk2alihy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"hu2yg43klw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "ie1foih4rh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "iic525th4z" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "jtzbpxjxmk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"myAdcRef" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , {
"an5nrsqy4z" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "lwgiddcetov" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "myAdcRef" } , { "lwgiddceto" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "myAdcRef" } , { "kaiyxbgdxv" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "myAdcRef" } , {
"neilaysvxs" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"myAdcRef" } , { "cuint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void *
) "uint64" } , { "uint64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"cint64" , MDL_INFO_ID_CMPLX_DATA_TYPE , 0 , - 1 , ( void * ) "int64" } , {
"int64" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_myAdcRef_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_cacheBitFieldToCellArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "myAdcRef" } , { "mr_myAdcRef_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "myAdcRef" } , { "mr_myAdcRef_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "myAdcRef" } , { "mr_myAdcRef_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "myAdcRef" } , {
"mr_myAdcRef_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"myAdcRef" } , { "mr_myAdcRef_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "myAdcRef" } , { "myAdcRef.h" , MDL_INFO_MODEL_FILENAME , 0 ,
- 1 , ( NULL ) } , { "myAdcRef.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , (
void * ) "myAdcRef" } } ; m1fhuzqrwih m1fhuzqrwi = { { -
2.5132741228718344E+7 , 2.5132741228718344E+7 , - 2.5132741228718333E+7 ,
2.513274122871834E+7 , - 2.5132741228718344E+7 } , 2.5132741228718344E+7 ,
1.0 , 0.0 , 3.0E-11 , 0.0 , 0.00390625 , 0.5 , - 0.5 , 0.0 , 1.5E-11 , 1234.0
, { 0U , 1U , 1U , 2U , 1U } , { 0U , 2U , 4U , 5U } , 0U , { 0U , 1U } , 0U
, { 0U , 0U , 0U , 1U } } ; void hu2yg43klw ( a1jtauijn3 * localDW ,
cuk0vnaths * localX ) { real_T tmp ; int32_T r ; int32_T t ; uint32_T tseed ;
localX -> j23rdm4haq [ 0 ] = m1fhuzqrwi . P_3 ; localX -> j23rdm4haq [ 1 ] =
m1fhuzqrwi . P_3 ; localX -> j23rdm4haq [ 2 ] = m1fhuzqrwi . P_3 ; tmp =
muDoubleScalarFloor ( m1fhuzqrwi . P_11 ) ; if ( muDoubleScalarIsNaN ( tmp )
|| muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp =
muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T
) - ( int32_T ) ( uint32_T ) - tmp : ( uint32_T ) tmp ; r = ( int32_T ) (
tseed >> 16U ) ; t = ( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed -
( ( uint32_T ) r << 16U ) ) + t ) << 16U ) + t ) + r ; if ( tseed < 1U ) {
tseed = 1144108930U ; } else if ( tseed > 2147483646U ) { tseed = 2147483646U
; } localDW -> bsjenfd3ic = tseed ; localDW -> f2l0xczpyf = ( m1fhuzqrwi .
P_10 - m1fhuzqrwi . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( & localDW ->
bsjenfd3ic ) + m1fhuzqrwi . P_9 ; } void cdgk2alihy ( a1jtauijn3 * localDW ,
cuk0vnaths * localX ) { real_T tmp ; int32_T r ; int32_T t ; uint32_T tseed ;
localX -> j23rdm4haq [ 0 ] = m1fhuzqrwi . P_3 ; localX -> j23rdm4haq [ 1 ] =
m1fhuzqrwi . P_3 ; localX -> j23rdm4haq [ 2 ] = m1fhuzqrwi . P_3 ; tmp =
muDoubleScalarFloor ( m1fhuzqrwi . P_11 ) ; if ( muDoubleScalarIsNaN ( tmp )
|| muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp =
muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T
) - ( int32_T ) ( uint32_T ) - tmp : ( uint32_T ) tmp ; r = ( int32_T ) (
tseed >> 16U ) ; t = ( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed -
( ( uint32_T ) r << 16U ) ) + t ) << 16U ) + t ) + r ; if ( tseed < 1U ) {
tseed = 1144108930U ; } else if ( tseed > 2147483646U ) { tseed = 2147483646U
; } localDW -> bsjenfd3ic = tseed ; localDW -> f2l0xczpyf = ( m1fhuzqrwi .
P_10 - m1fhuzqrwi . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( & localDW ->
bsjenfd3ic ) + m1fhuzqrwi . P_9 ; } void iic525th4z ( neilaysvxs * const
fghva1yhce , a1jtauijn3 * localDW ) { { real_T * pBuffer = & localDW ->
dgkaskfmoh . TUbufferArea [ 0 ] ; int_T j ; char ptrKey [ 1024 ] ; localDW ->
jy103drueb . Tail = 0 ; localDW -> jy103drueb . Head = 0 ; localDW ->
jy103drueb . Last = 0 ; localDW -> jy103drueb . CircularBufSize = 1024 ; for
( j = 0 ; j < 1024 ; j ++ ) { pBuffer [ j ] = m1fhuzqrwi . P_5 ; pBuffer [
1024 + j ] = rtmGetTaskTime ( fghva1yhce , 0 ) ; } localDW -> hjp30kivru .
TUbufferPtrs [ 0 ] = ( void * ) & pBuffer [ 0 ] ; sprintf ( ptrKey ,
"myAdcRef/Variable\nDelay_TUbuffer%d" , 0 ) ; slsaSaveRawMemoryForSimTargetOP
( fghva1yhce -> _mdlRefSfcnS , ptrKey , ( void * * ) ( & localDW ->
hjp30kivru . TUbufferPtrs [ 0 ] ) , 2 * 1024 * sizeof ( real_T ) , ( NULL ) ,
( NULL ) ) ; } } void myAdcRef ( neilaysvxs * const fghva1yhce , const real_T
* m54tqlzif5 , real_T * aijd1szk1g , real_T rtp_nonlingain , m33ibcx3yc *
localB , a1jtauijn3 * localDW , cuk0vnaths * localX ) { real_T m0pkt4jsxt ;
real_T tmp ; uint32_T ri ; localB -> onp1jgq2sp = 0.0 ; for ( ri = m1fhuzqrwi
. P_17 [ 0U ] ; ri < m1fhuzqrwi . P_17 [ 1U ] ; ri ++ ) { localB ->
onp1jgq2sp += m1fhuzqrwi . P_2 * localX -> j23rdm4haq [ 0U ] ; } for ( ri =
m1fhuzqrwi . P_17 [ 1U ] ; ri < m1fhuzqrwi . P_17 [ 2U ] ; ri ++ ) { localB
-> onp1jgq2sp += m1fhuzqrwi . P_2 * localX -> j23rdm4haq [ 1U ] ; } for ( ri
= m1fhuzqrwi . P_17 [ 2U ] ; ri < m1fhuzqrwi . P_17 [ 3U ] ; ri ++ ) { localB
-> onp1jgq2sp += m1fhuzqrwi . P_2 * localX -> j23rdm4haq [ 2U ] ; } { real_T
* * uBuffer = ( real_T * * ) & localDW -> hjp30kivru . TUbufferPtrs [ 0 ] ;
real_T simTime = rtmGetTaskTime ( fghva1yhce , 0 ) ; real_T appliedDelay ;
appliedDelay = localB -> onp1jgq2sp ; if ( appliedDelay > m1fhuzqrwi . P_4 )
{ appliedDelay = m1fhuzqrwi . P_4 ; } if ( appliedDelay < 0.0 ) {
appliedDelay = 0.0 ; } if ( appliedDelay == 0.0 ) { localB -> izeeasfr35 = (
* m54tqlzif5 ) ; } else { localB -> izeeasfr35 = rt_TDelayInterpolate (
simTime - appliedDelay , 0.0 , * uBuffer , localDW -> jy103drueb .
CircularBufSize , & localDW -> jy103drueb . Last , localDW -> jy103drueb .
Tail , localDW -> jy103drueb . Head , m1fhuzqrwi . P_5 , 0 , ( boolean_T ) (
rtmIsMinorTimeStep ( fghva1yhce ) && ( ( * uBuffer + localDW -> jy103drueb .
CircularBufSize ) [ localDW -> jy103drueb . Head ] == rtmGetTaskTime (
fghva1yhce , 0 ) ) ) ) ; } } if ( rtmIsMajorTimeStep ( fghva1yhce ) &&
rtmIsSampleHit ( fghva1yhce , 1 , 0 ) ) { localB -> jf4zr3ykw2 = localDW ->
f2l0xczpyf ; } if ( rtmIsMajorTimeStep ( fghva1yhce ) && rtmIsSampleHit (
fghva1yhce , 2 , 0 ) ) { m0pkt4jsxt = rtp_nonlingain * localB -> izeeasfr35 ;
tmp = 1.0 / rtp_nonlingain ; m0pkt4jsxt = muDoubleScalarRound ( tmp *
muDoubleScalarTanh ( m0pkt4jsxt ) / m1fhuzqrwi . P_6 ) * m1fhuzqrwi . P_6 ;
if ( m0pkt4jsxt > m1fhuzqrwi . P_7 ) { * aijd1szk1g = m1fhuzqrwi . P_7 ; }
else if ( m0pkt4jsxt < m1fhuzqrwi . P_8 ) { * aijd1szk1g = m1fhuzqrwi . P_8 ;
} else { * aijd1szk1g = m0pkt4jsxt ; } } } void adod515mu1 ( neilaysvxs *
const fghva1yhce , const real_T * m54tqlzif5 , a1jtauijn3 * localDW ) { if (
rtmIsMajorTimeStep ( fghva1yhce ) ) { if ( memcmp ( fghva1yhce ->
nonContDerivSignal [ 0 ] . pCurrVal , fghva1yhce -> nonContDerivSignal [ 0 ]
. pPrevVal , fghva1yhce -> nonContDerivSignal [ 0 ] . sizeInBytes ) != 0 ) {
( void ) memcpy ( fghva1yhce -> nonContDerivSignal [ 0 ] . pPrevVal ,
fghva1yhce -> nonContDerivSignal [ 0 ] . pCurrVal , fghva1yhce ->
nonContDerivSignal [ 0 ] . sizeInBytes ) ; ssSetSolverNeedsReset ( fghva1yhce
-> _mdlRefSfcnS ) ; } } { real_T * * uBuffer = ( real_T * * ) & localDW ->
hjp30kivru . TUbufferPtrs [ 0 ] ; int numBuffers = 2 ; real_T simTime =
rtmGetTaskTime ( fghva1yhce , 0 ) ; boolean_T bufferisfull = false ; localDW
-> jy103drueb . Head = ( ( localDW -> jy103drueb . Head < ( localDW ->
jy103drueb . CircularBufSize - 1 ) ) ? ( localDW -> jy103drueb . Head + 1 ) :
0 ) ; if ( localDW -> jy103drueb . Head == localDW -> jy103drueb . Tail ) {
bufferisfull = true ; localDW -> jy103drueb . Tail = ( ( localDW ->
jy103drueb . Tail < ( localDW -> jy103drueb . CircularBufSize - 1 ) ) ? (
localDW -> jy103drueb . Tail + 1 ) : 0 ) ; } ( * uBuffer + localDW ->
jy103drueb . CircularBufSize ) [ localDW -> jy103drueb . Head ] = simTime ; (
* uBuffer ) [ localDW -> jy103drueb . Head ] = ( * m54tqlzif5 ) ; if (
bufferisfull ) { ssSetBlockStateForSolverChangedAtMajorStep ( fghva1yhce ->
_mdlRefSfcnS ) ; ssSetContTimeOutputInconsistentWithStateAtMajorStep (
fghva1yhce -> _mdlRefSfcnS ) ; } } if ( rtmIsMajorTimeStep ( fghva1yhce ) &&
rtmIsSampleHit ( fghva1yhce , 1 , 0 ) ) { localDW -> f2l0xczpyf = (
m1fhuzqrwi . P_10 - m1fhuzqrwi . P_9 ) * rt_urand_Upu32_Yd_f_pw_snf ( &
localDW -> bsjenfd3ic ) + m1fhuzqrwi . P_9 ; } } void nlz4nouxac ( m33ibcx3yc
* localB , cuk0vnaths * localX , ktp4t1dufk * localXdot ) { uint32_T ri ;
localXdot -> j23rdm4haq [ 0 ] = 0.0 ; localXdot -> j23rdm4haq [ 1 ] = 0.0 ;
localXdot -> j23rdm4haq [ 2 ] = 0.0 ; for ( ri = m1fhuzqrwi . P_13 [ 0U ] ;
ri < m1fhuzqrwi . P_13 [ 1U ] ; ri ++ ) { localXdot -> j23rdm4haq [
m1fhuzqrwi . P_12 [ ri ] ] += m1fhuzqrwi . P_0 [ ri ] * localX -> j23rdm4haq
[ 0U ] ; } for ( ri = m1fhuzqrwi . P_13 [ 1U ] ; ri < m1fhuzqrwi . P_13 [ 2U
] ; ri ++ ) { localXdot -> j23rdm4haq [ m1fhuzqrwi . P_12 [ ri ] ] +=
m1fhuzqrwi . P_0 [ ri ] * localX -> j23rdm4haq [ 1U ] ; } for ( ri =
m1fhuzqrwi . P_13 [ 2U ] ; ri < m1fhuzqrwi . P_13 [ 3U ] ; ri ++ ) {
localXdot -> j23rdm4haq [ m1fhuzqrwi . P_12 [ ri ] ] += m1fhuzqrwi . P_0 [ ri
] * localX -> j23rdm4haq [ 2U ] ; } for ( ri = m1fhuzqrwi . P_15 [ 0U ] ; ri
< m1fhuzqrwi . P_15 [ 1U ] ; ri ++ ) { localXdot -> j23rdm4haq [ m1fhuzqrwi .
P_14 ] += m1fhuzqrwi . P_1 * localB -> jf4zr3ykw2 ; } { } } void ial4inrtvv (
neilaysvxs * const fghva1yhce ) { if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( fghva1yhce -> _mdlRefSfcnS , "myAdcRef" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void ie1foih4rh (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , neilaysvxs * const fghva1yhce , m33ibcx3yc * localB ,
a1jtauijn3 * localDW , cuk0vnaths * localX , void * sysRanPtr , int
contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; ( void ) memset ( ( void * ) fghva1yhce , 0 , sizeof
( neilaysvxs ) ) ; fghva1yhce -> Timing . mdlref_GlobalTID [ 0 ] =
mdlref_TID0 ; fghva1yhce -> Timing . mdlref_GlobalTID [ 1 ] = mdlref_TID1 ;
fghva1yhce -> Timing . mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; fghva1yhce ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( fghva1yhce -> _mdlRefSfcnS , "myAdcRef" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> onp1jgq2sp = 0.0
; localB -> izeeasfr35 = 0.0 ; localB -> jf4zr3ykw2 = 0.0 ; } ( void ) memset
( ( void * ) localDW , 0 , sizeof ( a1jtauijn3 ) ) ; localDW -> f2l0xczpyf =
0.0 ; localDW -> dgkaskfmoh . modelTStart = 0.0 ; { int32_T i ; for ( i = 0 ;
i < 2048 ; i ++ ) { localDW -> dgkaskfmoh . TUbufferArea [ i ] = 0.0 ; } }
myAdcRef_InitializeDataMapInfo ( fghva1yhce , localDW , localX , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
fghva1yhce -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( fghva1yhce ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
fghva1yhce -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } fghva1yhce ->
nonContDerivSignal [ 0 ] . pPrevVal = ( char_T * ) fghva1yhce ->
NonContDerivMemory . mr_nonContSig0 ; fghva1yhce -> nonContDerivSignal [ 0 ]
. sizeInBytes = ( 1 * sizeof ( real_T ) ) ; fghva1yhce -> nonContDerivSignal
[ 0 ] . pCurrVal = ( char_T * ) ( & localB -> jf4zr3ykw2 ) ; ; } void
mr_myAdcRef_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_myAdcRef , 49 ) ; * retVal = 1 ; } static void
mr_myAdcRef_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_myAdcRef_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_myAdcRef_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_myAdcRef_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_myAdcRef_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_myAdcRef_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_myAdcRef_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) ; static uint_T
mr_myAdcRef_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_myAdcRef_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_myAdcRef_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_myAdcRef_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_myAdcRef_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_myAdcRef_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_myAdcRef_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_myAdcRef_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static uint_T
mr_myAdcRef_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) { const uint_T
fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber ( srcArray
, i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u ) ; }
mxArray * mr_myAdcRef_GetDWork ( const jo4dnl2tvxq * mdlrefDW ) { static
const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" , } ;
mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_myAdcRef_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & ( mdlrefDW
-> rtb ) , sizeof ( mdlrefDW -> rtb ) ) ; { static const char *
rtdwDataFieldNames [ 4 ] = { "mdlrefDW->rtdw.f2l0xczpyf" ,
"mdlrefDW->rtdw.dgkaskfmoh" , "mdlrefDW->rtdw.bsjenfd3ic" ,
"mdlrefDW->rtdw.jy103drueb" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 4 , rtdwDataFieldNames ) ; mr_myAdcRef_cacheDataAsMxArray ( rtdwData
, 0 , 0 , ( const void * ) & ( mdlrefDW -> rtdw . f2l0xczpyf ) , sizeof (
mdlrefDW -> rtdw . f2l0xczpyf ) ) ; mr_myAdcRef_cacheDataAsMxArray ( rtdwData
, 0 , 1 , ( const void * ) & ( mdlrefDW -> rtdw . dgkaskfmoh ) , sizeof (
mdlrefDW -> rtdw . dgkaskfmoh ) ) ; mr_myAdcRef_cacheDataAsMxArray ( rtdwData
, 0 , 2 , ( const void * ) & ( mdlrefDW -> rtdw . bsjenfd3ic ) , sizeof (
mdlrefDW -> rtdw . bsjenfd3ic ) ) ; mr_myAdcRef_cacheDataAsMxArray ( rtdwData
, 0 , 3 , ( const void * ) & ( mdlrefDW -> rtdw . jy103drueb ) , sizeof (
mdlrefDW -> rtdw . jy103drueb ) ) ; mxSetFieldByNumber ( ssDW , 0 , 1 ,
rtdwData ) ; } ( void ) mdlrefDW ; return ssDW ; } void mr_myAdcRef_SetDWork
( jo4dnl2tvxq * mdlrefDW , const mxArray * ssDW ) { ( void ) ssDW ; ( void )
mdlrefDW ; mr_myAdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW ->
rtb ) , ssDW , 0 , 0 , sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray *
rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_myAdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
f2l0xczpyf ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW -> rtdw . f2l0xczpyf ) )
; mr_myAdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
dgkaskfmoh ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw . dgkaskfmoh ) )
; mr_myAdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
bsjenfd3ic ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . bsjenfd3ic ) )
; mr_myAdcRef_restoreDataFromMxArray ( ( void * ) & ( mdlrefDW -> rtdw .
jy103drueb ) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . jy103drueb ) )
; } } void mr_myAdcRef_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 2806481843U , 2652244801U , 874763689U ,
1173022817U , } ; slmrModelRefRegisterSimStateChecksum ( S , "myAdcRef" , &
chksum [ 0 ] ) ; } mxArray * mr_myAdcRef_GetSimStateDisallowedBlocks ( ) {
return ( NULL ) ; }
#if defined(_MSC_VER)
#pragma warning(disable: 4505) //unreferenced local function has been removed
#endif
