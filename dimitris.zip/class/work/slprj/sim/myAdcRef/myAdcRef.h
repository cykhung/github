#ifndef RTW_HEADER_myAdcRef_h_
#define RTW_HEADER_myAdcRef_h_
#ifndef myAdcRef_COMMON_INCLUDES_
#define myAdcRef_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "myAdcRef_types.h"
#include <stddef.h>
#include <string.h>
#include "model_reference_types.h"
#include "rtw_modelmap_simtarget.h"
#include "rt_nonfinite.h"
typedef struct { real_T onp1jgq2sp ; real_T izeeasfr35 ; real_T jf4zr3ykw2 ;
} m33ibcx3yc ; typedef struct { real_T f2l0xczpyf ; struct { real_T
modelTStart ; real_T TUbufferArea [ 2048 ] ; } dgkaskfmoh ; struct { void *
TUbufferPtrs [ 2 ] ; } hjp30kivru ; uint32_T bsjenfd3ic ; struct { int_T Tail
; int_T Head ; int_T Last ; int_T CircularBufSize ; } jy103drueb ; }
a1jtauijn3 ; typedef struct { real_T j23rdm4haq [ 3 ] ; } cuk0vnaths ;
typedef struct { real_T j23rdm4haq [ 3 ] ; } ktp4t1dufk ; typedef struct {
boolean_T j23rdm4haq [ 3 ] ; } e1v3dlfe51 ; typedef struct { real_T
j23rdm4haq [ 3 ] ; } foqysqk3qn ; typedef struct { real_T j23rdm4haq [ 3 ] ;
} bwdwgdvgz4 ; typedef struct { real_T j23rdm4haq [ 3 ] ; } llg3cf3lgx ;
struct m1fhuzqrwih_ { real_T P_0 [ 5 ] ; real_T P_1 ; real_T P_2 ; real_T P_3
; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9
; real_T P_10 ; real_T P_11 ; uint32_T P_12 [ 5 ] ; uint32_T P_13 [ 4 ] ;
uint32_T P_14 ; uint32_T P_15 [ 2 ] ; uint32_T P_16 ; uint32_T P_17 [ 4 ] ; }
; struct kaiyxbgdxv { struct SimStruct_tag * _mdlRefSfcnS ; struct { real_T
mr_nonContSig0 [ 1 ] ; } NonContDerivMemory ; ssNonContDerivSigInfo
nonContDerivSignal [ 1 ] ; const rtTimingBridge * timingBridge ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 1 ] ; int32_T * vardimsAddress [ 1
] ; RTWLoggingFcnPtr loggingPtrs [ 1 ] ; sysRanDType * systemRan [ 2 ] ;
int_T systemTid [ 2 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 3 ]
; } Timing ; } ; typedef struct { m33ibcx3yc rtb ; a1jtauijn3 rtdw ;
neilaysvxs rtm ; } jo4dnl2tvxq ; extern void ie1foih4rh ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 ,
neilaysvxs * const fghva1yhce , m33ibcx3yc * localB , a1jtauijn3 * localDW ,
cuk0vnaths * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void mr_myAdcRef_MdlInfoRegFcn
( SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern
mxArray * mr_myAdcRef_GetDWork ( const jo4dnl2tvxq * mdlrefDW ) ; extern void
mr_myAdcRef_SetDWork ( jo4dnl2tvxq * mdlrefDW , const mxArray * ssDW ) ;
extern void mr_myAdcRef_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_myAdcRef_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * myAdcRef_GetCAPIStaticMap ( void ) ; extern
void hu2yg43klw ( a1jtauijn3 * localDW , cuk0vnaths * localX ) ; extern void
cdgk2alihy ( a1jtauijn3 * localDW , cuk0vnaths * localX ) ; extern void
iic525th4z ( neilaysvxs * const fghva1yhce , a1jtauijn3 * localDW ) ; extern
void nlz4nouxac ( m33ibcx3yc * localB , cuk0vnaths * localX , ktp4t1dufk *
localXdot ) ; extern void adod515mu1 ( neilaysvxs * const fghva1yhce , const
real_T * m54tqlzif5 , a1jtauijn3 * localDW ) ; extern void myAdcRef (
neilaysvxs * const fghva1yhce , const real_T * m54tqlzif5 , real_T *
aijd1szk1g , real_T rtp_nonlingain , m33ibcx3yc * localB , a1jtauijn3 *
localDW , cuk0vnaths * localX ) ; extern void ial4inrtvv ( neilaysvxs * const
fghva1yhce ) ;
#endif
