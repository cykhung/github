function Hd = mylowpass1

d = fdesign.lowpass('Fp,Fst,Ap,Ast',4000,5000,0.1,50,22050);
Hd = design(d, 'cheby1');
end